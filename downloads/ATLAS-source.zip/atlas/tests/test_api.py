"""End-to-end API test. Starts ATLAS on a temp data dir, optionally with the
fake LLM, and exercises every department through HTTP."""
import json, os, sys, tempfile, time, threading, urllib.request
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
tmp = tempfile.mkdtemp()
os.environ["ATLAS_DATA"] = tmp
os.environ["HOME"] = tmp  # isolate the secrets vault
if "--fake-llm" in sys.argv:
    os.environ["OLLAMA_HOST"] = "http://127.0.0.1:11500"
import shutil
shutil.copytree(os.path.join(ROOT, "data", "market"), os.path.join(tmp, "market"))
from atlas import db, market
market.DATA = os.path.join(tmp, "market")
from atlas import server
PORT = 8711
httpd = server.serve("127.0.0.1", PORT)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{PORT}"
fails = []

def call(path, body=None, expect=200):
    req = urllib.request.Request(B + path, data=None if body is None else json.dumps(body).encode(),
                                 method="GET" if body is None else "POST", headers={"content-type": "application/json"})
    try:
        r = urllib.request.urlopen(req, timeout=120); code, data = r.status, r.read()
    except urllib.error.HTTPError as e:
        code, data = e.code, e.read()
    out = json.loads(data) if data[:1] in (b"{", b"[") else data
    if code != expect:
        fails.append(f"{path} -> {code} {out}")
    return out

def job(j, timeout=300):
    if isinstance(j, dict): j = j.get("job")
    t = time.time()
    while time.time() - t < timeout:
        r = call(f"/api/jobs/{j}")
        if r["status"] in ("done", "error", "cancelled"):
            if r["status"] != "done":
                fails.append(f"job {j} {r['status']} {str(r['result'])[:1500]}"); print("JOB FAILED", j, str(r["result"])[:1500]); return {}
            return r["result"]
        time.sleep(0.3)
    fails.append(f"job {j} timeout")

def check(name, cond, info=""):
    print(("PASS " if cond else "FAIL ") + name, info if not cond else "")
    if not cond: fails.append(name + " " + str(info))

o = call("/api/overview"); check("overview", "agents" in o and o["agents"] >= 5, o.get("agents"))
check("static index", b"ATLAS" in call("/"))
check("static js", b"export" in call("/js/core.js"))
check("path traversal blocked", call("/../atlas/db.py", expect=404) is not None)
models = call("/api/models"); llm = [m["id"] for m in models if m["available"] and m["provider"] != "local"]
print("LLMs available:", llm)
# knowledge
d = call("/api/knowledge/docs", {"title": "Crash notes", "content": "The 2008 financial crisis began with the collapse of Lehman Brothers. Subprime mortgages were a key cause. The Federal Reserve cut rates."})
s = call("/api/knowledge/search?q=what%20caused%20the%202008%20crisis"); check("knowledge search", s and s[0]["title"] == "Crash notes", s)
g = call("/api/knowledge/graph"); check("knowledge graph", any(n["id"] == "Lehman Brothers" for n in g["nodes"]), [n["id"] for n in g["nodes"]])
c = call(f"/api/knowledge/docs/{d['id']}/delete", {}); check("delete needs confirm", "confirm_token" in c)
call(f"/api/knowledge/docs/{d['id']}/delete", {"confirm_token": "wrong"}, expect=403)
# workforce: math task with local engine (always available)
r = job(call("/api/tasks", {"text": "Calculate 2475 * 0.37", "difficulty": "easy"})["job"])
check("task math via workforce", r and "915.75" in r["output"], r and r["output"][:200])
t = call(f"/api/tasks/{r['task_id']}"); check("task tree has delegation", len(t["tree"]["children"]) >= 1, t["tree"])
check("messages logged", len(t["messages"]) >= 3, len(t["messages"]))
ag = call("/api/agents"); spec = [a for a in ag if a["specialty"] == "math"]
check("specialist created on probation", spec and spec[0]["status"] == "probation", [(a["name"], a["status"]) for a in ag])
v = call(f"/api/agents/{spec[0]['id']}/update", {"system": "You are a careful math agent."}); check("agent versioning", v["version"] == 2)
call(f"/api/agents/{spec[0]['id']}/rollback", {"version": 1}); a = call(f"/api/agents/{spec[0]['id']}"); check("rollback", a["version"] == 3 and a["config"]["system"] != "You are a careful math agent.")
ev = job(call(f"/api/agents/{spec[0]['id']}/evaluate", {})["job"]); check("math specialist exam", ev and ev["score"] is not None, ev)
# arena on local engine
ar = job(call("/api/arena/run", {"model": "atlas-local", "category": "math", "n": 4})["jobs"][0])
check("arena local math 100%", ar and ar["accuracy"] == 1.0, ar)
lb = call("/api/arena"); check("leaderboard", len(lb["leaderboard"]) >= 1)
# lab
tr = job(call("/api/lab/train", {"config": {"dataset": "moons", "epochs": 60, "hidden": [16]}})["job"])
check("lab train", tr and tr["metrics"]["val"] > 0.85, tr and tr["metrics"])
ex = call("/api/lab/experiments?kind=train")[0]
rp = call(f"/api/lab/reproduce/{ex['id']}", {}); check("reproducible", rp["identical"], rp)
sw = job(call("/api/lab/sweep", {"base": {"dataset": "xor", "epochs": 40}, "variable": "lr", "values": [0.001, 0.05], "seeds": [0, 1]})["job"])
check("sweep", sw and len(sw["rows"]) == 2 and "conclusion" in sw, sw)
# architect
ar = job(call("/api/architect", {"description": "classify the moons pattern"})["job"])
check("architect toy deployed", ar and ar["status"] == "deployed", ar)
pr = call(f"/api/systems/{ar['system_id']}/predict", {"input": [0.5, 0.2]}); check("system predict", "label" in pr, pr)
z = call(f"/api/systems/{ar['system_id']}/download"); check("download zip", isinstance(z, bytes) and z[:2] == b"PK")
csv = "x1,x2,cls\n" + "\n".join(f"{i%10},{(i*7)%13},{'a' if (i%10)+((i*7)%13) > 10 else 'b'}" for i in range(200))
ar2 = job(call("/api/architect", {"description": "classify cls", "csv": csv})["job"])
check("architect tabular", ar2 and ar2["status"] == "deployed", ar2)
csv2 = "x1,x2,cls\n" + "\n".join(f"{i%10},{(i*3)%13},{'a' if (i%10)+((i*3)%13) > 10 else 'b'}" for i in range(120))
ft = call(f"/api/systems/{ar2['system_id']}/finetune", {"csv": csv2}); check("finetune new version", ft.get("version") == 2, ft)
rb = call(f"/api/systems/{ar2['system_id']}/rollback", {}); check("system rollback", rb.get("version") == 1, rb)
# market
call("/api/market/reset", {"config": {"population": 120, "generations": 4, "delay": 0}})
call("/api/market/start", {}); time.sleep(3)
st = call("/api/market"); check("market ran", st["gen"] >= 4 and st["status"] == "finished", (st["gen"], st["status"]))
bot = call(f"/api/market/bot/{st['last']['stats']['champion']}"); check("bot inspect", "dna" in bot and "family" in bot)
call("/api/market/reset", {"config": {"mode": "synthetic", "population": 100, "generations": 3, "delay": 0}})
call("/api/market/challenge", {"kind": "crash"}); call("/api/market/step", {})
st = call("/api/market"); check("synthetic + crash", st["history"][-1]["challenge"] == ["crash"] and "crash day" in st["history"][-1]["env"], st["history"][-1]["env"])
# workspace
ta = call("/api/workspace/ta?asset=AAPL"); check("technical analysis", ta["last_date"] == "2016-03-01")
mc = call("/api/workspace/montecarlo?asset=GSPC"); check("monte carlo", 0 < mc["prob_loss"] < 1)
# permissions + budget
call("/api/permissions", {"permissions": {"agents_can_create_agents": False}})
r = job(call("/api/tasks", {"text": "write a python function that adds two numbers"})["job"])
ag2 = call("/api/agents"); check("permission blocks agent creation", not any(a["specialty"] == "code" for a in ag2))
call("/api/permissions", {"permissions": {"agents_can_create_agents": True}})
call("/api/permissions", {"permissions": {"allow_code_execution": False}})
code = job(call("/api/arena/run", {"model": "atlas-local", "category": "code", "n": 1})["jobs"][0])
check("code exec permission enforced", code and code["accuracy"] == 0, code)
call("/api/permissions", {"permissions": {"allow_code_execution": True}})
check("credentials never returned", all("value" not in c for c in call("/api/credentials")))
call("/api/credentials", {"name": "NOT_A_KEY", "value": "x"}, expect=400)
# council
cs = job(call("/api/council", {"question": "What is 6 * 7?"})["job"])
if len(llm) >= 2:
    check("council decided", cs and cs.get("winner") and cs.get("decision"), cs)
    check("council weighted votes", cs and len(cs["votes"]) == len(llm), cs and cs["votes"])
    r = job(call("/api/tasks", {"text": "Research why the 2008 crisis happened, then calculate 100 * 3, then write a summary"})["job"])
    check("multi-step delegation", r and len(call(f"/api/tasks/{r['task_id']}")["tree"]["children"][0]["children"]) == 3, r)
    ec = call("/api/economy"); check("ledger records llm calls", any(m["model"].startswith("ollama") for m in ec["by_model"]))
else:
    check("council refuses with <2 models", cs and cs.get("note"), cs)
ec = call("/api/economy"); check("economy summary", "by_agent" in ec)
if llm:
    kn = call("/api/knowledge"); check("hybrid search mode", kn["stats"]["search_mode"].startswith("hybrid"), kn["stats"])
    call("/api/knowledge/docs", {"title": "Garage", "content": "My car needs new tires and an oil change."})
    r = call("/api/knowledge/search?q=automobile%20maintenance"); check("embedding finds synonym", r and r[0]["title"] == "Garage", r[:2])
call("/api/compute"); call("/api/events?since=0")
# ---------------- v0.2 features
di = job(call("/api/system/diagnostics", {}))
check("diagnostics run", di and di["total"] >= 10 and di["passed"] >= di["total"] - 2, di and [c for c in di["checks"] if not c["ok"]])
check("system info", "data_dir" in call("/api/system/info"))
call("/api/system/logs", {"level": "warn", "message": "test log"})
check("logs endpoint", any(l["message"] == "test log" for l in call("/api/system/logs")))
bk = call("/api/system/backup"); check("backup zip", isinstance(bk, bytes) and bk[:2] == b"PK")
import base64
c = call("/api/system/restore", {}); check("restore needs confirmation", "confirm_token" in c)
r = call("/api/system/restore", {"confirm_token": c["confirm_token"], "file_b64": base64.b64encode(bk).decode()}); check("restore staged", r.get("staged"), r)
os.remove(os.path.join(tmp, "restore_pending.zip"))
ch = job(call("/api/chat/send", {"text": "What is 7 * 8?"}))
check("chat reply", ch and "56" in ch["text"], ch)
ch2 = job(call("/api/chat/send", {"conv_id": ch["conv_id"], "text": "What caused the 2008 crisis?"}))
check("chat continues conversation", ch2 and ch2["conv_id"] == ch["conv_id"] and len(call(f"/api/chat/{ch['conv_id']}")) == 4)
check("conversation list", any(c["id"] == ch["conv_id"] for c in call("/api/chat/conversations")))
au = call("/api/automations", {"name": "test auto", "kind": "autopilot", "schedule": {"every_minutes": 5}})
check("automation created", au.get("id"))
ar = job(call(f"/api/automations/{au['id']}/run", {})); a = [x for x in call("/api/automations")["automations"] if x["id"] == au["id"]][0]
check("automation ran", a["last_status"] == "ok" and a["runs"] == 1, a)
from atlas import automations as _au
check("daily schedule math", 0 < _au.next_run({"daily_at": "06:30"}) - time.time() <= 86400)
d = call(f"/api/automations/{au['id']}/delete", {}); call(f"/api/automations/{au['id']}/delete", {"confirm_token": d["confirm_token"]})
check("automation deleted", not any(x["id"] == au["id"] for x in call("/api/automations")["automations"]))
call("/api/market/reset", {"config": {"population": 80, "generations": 3, "delay": 0}}); call("/api/market/start", {}); time.sleep(2)
champ = call("/api/market")["last"]["stats"]["champion"]
bt = call("/api/market/backtest", {"bot_id": champ, "asset": "MSFT"}); check("cross-asset backtest", bt["asset"] == "MSFT" and len(bt["curve"]) > 50, bt.keys())
hof = call("/api/market/hall", {"bot_id": champ}); check("hall of fame", call("/api/market/hall")[0]["bot_id"] == champ)
ex = call(f"/api/market/hall/{hof['id']}/export", {}); check("export champion as system", ex.get("system_id"), ex)
check("exported strategy predicts", "action" in call(f"/api/systems/{ex['system_id']}/predict", {"input": None}))
st = call("/api/onboarding"); check("onboarding status", "done" in st)
call("/api/onboarding", {"done": True}); check("onboarding saved", call("/api/onboarding")["done"] is True)
check("command palette search", any(x["type"] == "agent" for x in call("/api/search?q=Lead")))
if llm:
    o = call("/api/ollama"); check("ollama status", o["running"] and any(r["installed"] for r in o["recommended"]), o)
    pj = job(call("/api/ollama/pull", {"model": "gemma3"})); check("model download w/ progress", pj and pj["status"] == "success", pj)
    check("pulled model selectable", any(m["id"] == "ollama:gemma3" for m in call("/api/models")))
    from atlas import web as _web, marketdata as _md
    _web.SEARCH_URL = "http://127.0.0.1:11500/ddg?q={q}"
    rs = call("/api/web/search", {"query": "inflation"}); check("web search parses results", len(rs) == 3 and rs[0]["url"].endswith("/page/1"), rs)
    wr = job(call("/api/web/research", {"question": "what is inflation"}))
    check("web research reads pages", wr and len(wr["sources"]) >= 2 and "purchasing power" in wr["context"], wr)
    check("web pages filed in knowledge", any(d["project"] == "web" for d in call("/api/knowledge")["docs"]))
    check("scripts stripped from pages", "bad()" not in wr["context"])
    call("/api/permissions", {"permissions": {"allow_web_access": False}}); call("/api/web/search", {"query": "x"}, expect=403)
    call("/api/permissions", {"permissions": {"allow_web_access": True}})
    _md.SOURCES["yahoo"] = "http://127.0.0.1:11500/yahoo/{sym}?y={years}"
    md = job(call("/api/market/download", {"symbols": "NVDA"})); check("price download", md and md["downloaded"][0]["rows"] == 300, md)
    check("downloaded asset in lab", "NVDA" in call("/api/market")["assets"])
    rv = job(call("/api/tasks", {"text": "Research what inflation is, then calculate 3 * 5", "review": True}))
    tr = call(f"/api/tasks/{rv['task_id']}")
    check("peer review happened", any("review" in m["content"].lower() for m in tr["messages"]), [m["content"][:60] for m in tr["messages"]])
    ch3 = job(call("/api/chat/send", {"text": "explain inflation", "web": True}))
    check("chat with web sources", ch3 and any(s["tag"].startswith("W") for s in ch3["sources"]), ch3 and ch3["sources"])
print("\n%d failures" % len(fails))
for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
