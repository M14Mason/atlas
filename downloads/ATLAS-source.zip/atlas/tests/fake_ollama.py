"""TEST ONLY. A fake Ollama-compatible server so the LLM plumbing (council,
delegation, grading, synthesis) can be exercised without a real model.
It is deliberately dumb and deterministic; it is never used by ATLAS itself.
Run:  python tests/fake_ollama.py 11500   then set OLLAMA_HOST=http://127.0.0.1:11500
"""
import json, re, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _j(self, o):
        b = json.dumps(o).encode(); self.send_response(200); self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def _html(self, body, ctype="text/html"):
        b = body.encode(); self.send_response(200); self.send_header("content-type", ctype)
        self.send_header("content-length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path.startswith("/ddg"):   # fake DuckDuckGo HTML results
            port = self.server.server_address[1]
            items = "".join(f'<a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=http%3A%2F%2F127.0.0.1%3A{port}%2Fpage%2F{i}">Result {i}</a>'
                            f'<a class="result__snippet" href="#">Snippet about inflation {i}</a>' for i in range(1, 4))
            return self._html(f"<html><body>{items}</body></html>")
        if self.path.startswith("/page/"):
            i = self.path.rsplit("/", 1)[1]
            para = "Inflation is the rate at which the general level of prices rises over time and erodes purchasing power. " * 3
            return self._html(f"<html><head><title>Inflation explainer {i}</title><script>bad()</script></head><body><nav>menu</nav>"
                              f"<p>{para}</p><p>Central banks raise interest rates to fight inflation, which slows borrowing.</p></body></html>")
        if self.path.startswith("/yahoo/"):
            import time as _t
            ts = [int(_t.time()) - 86400 * (300 - k) for k in range(300)]
            closes = [100 + k * 0.1 + (k % 7) for k in range(300)]
            return self._j({"chart": {"result": [{"timestamp": ts, "indicators": {"quote": [{"close": closes}], "adjclose": [{"adjclose": closes}]}}]}})
        self._j({"models": [{"name": "llama3.2:latest", "size": 2000000000}, {"name": "qwen2.5:latest", "size": 4700000000},
                            {"name": "nomic-embed-text:latest", "size": 300000000}]})
    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers["content-length"])))
        if self.path == "/api/pull":   # streamed NDJSON progress like real Ollama
            self.send_response(200); self.send_header("content-type", "application/x-ndjson"); self.end_headers()
            for k in range(0, 101, 25):
                self.wfile.write((json.dumps({"status": "downloading", "total": 100, "completed": k}) + "\n").encode())
            self.wfile.write(b'{"status":"success"}\n'); return
        if self.path == "/api/embed":  # fake embedding: hashed bag of words with a tiny synonym table
            syn = {"automobile": "car", "vehicle": "car", "crash": "crisis", "collapse": "crisis"}
            vecs = []
            for t in req["input"]:
                v = [0.0] * 2048
                for w in re.findall(r"[a-z]+", t.lower()):
                    v[hash(syn.get(w, w)) % 2048] += 1
                vecs.append(v)
            return self._j({"embeddings": vecs})
        sysmsg = req["messages"][0]["content"]; p = req["messages"][-1]["content"]; m = req["model"]
        if "DECOMPOSE" in sysmsg:
            parts = [s.strip() for s in re.split(r",? then |;", p) if s.strip()]
            out = json.dumps(parts)
        elif "Reply with only the letter" in p:
            out = "B" if m == "llama3.2" else "A"
        elif "Score the answer" in p:
            out = "8"
        elif "Reply with one word" in p:
            out = "agent"
        elif "TRUE or FALSE" in p:
            out = "FALSE" if any(w in p for w in ("Great Wall", "blind", "10%", "3-second", "never strikes")) else "TRUE"
        elif "JSON object" in p:
            mm = re.search(r"named (\w+) aged (\d+)", p); out = json.dumps({"name": mm.group(1), "age": int(mm.group(2))})
        elif "REVISED:" in p:
            out = f"The other answer is fine. REVISED: {m} final answer: 42"
        else:
            expr = re.findall(r"[\d\(][\d \.\.\+\-\*/\(\)]*[\d\)]", p)
            expr = [e for e in expr if re.search(r"[\+\-\*/]", e)]
            try:
                out = str(eval(max(expr, key=len))) if expr else f"[{m}] answer to: {p[:80]}"
            except Exception:
                out = f"[{m}] answer to: {p[:80]}"
        self._j({"message": {"content": out}, "prompt_eval_count": len(p) // 4, "eval_count": len(out) // 4})

ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1]) if len(sys.argv) > 1 else 11500), H).serve_forever()
