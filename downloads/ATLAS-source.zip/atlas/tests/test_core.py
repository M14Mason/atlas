"""Fast invariant tests. Run: python3 tests/test_core.py"""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from atlas import db
db.connect(os.path.join(tempfile.mkdtemp(), "t.db"))
from atlas import market, neural, providers, agents, arena

def test_backprop_matches_numerical_gradient():
    for act in ["relu", "tanh", "sigmoid", "gelu"]:
        m = neural.MLP(3, [5, 4], 3, act, "classification", seed=1)
        X = np.random.default_rng(0).normal(size=(7, 3)); y = np.array([0, 1, 2, 1, 0, 2, 1])
        out, c = m.forward(X); _, g = m.loss_grad(out, y); gW, _ = m.backward(c, g, 0)
        e = 1e-6; m.W[0][1, 2] += e; lp = m.loss_grad(m.forward(X)[0], y)[0]; m.W[0][1, 2] -= 2 * e
        lm = m.loss_grad(m.forward(X)[0], y)[0]; m.W[0][1, 2] += e
        num = (lp - lm) / (2 * e)
        assert abs(num - gW[0][1, 2]) / (abs(num) + abs(gW[0][1, 2]) + 1e-12) < 1e-5, act

def test_no_future_leakage():
    p, _ = market.synthetic(400, 1); q = p.copy(); q[250:] *= 1.5
    assert np.allclose(market.features(p)[:250], market.features(q)[:250])
    dna = market.random_dna(30, np.random.default_rng(0))
    a = market.simulate(dna, p, market.features(p))["curve"]; b = market.simulate(dna, q, market.features(q))["curve"]
    assert np.allclose(a[:250], b[:250])

def test_training_is_reproducible():
    a = neural.train({"dataset": "moons", "epochs": 20, "seed": 3}); b = neural.train({"dataset": "moons", "epochs": 20, "seed": 3})
    assert a["history"] == b["history"]

def test_local_engine_math_and_safety():
    L = providers.ADAPTERS["local"]
    assert L.answer("What is 12 * (3 + 4)?") == "84"
    assert "too large" in L.answer("what is 9 ** 999999")
    assert "__import__" not in L.answer("__import__('os').system('echo hi')")

def test_classifier_routes():
    assert agents.classify("summarize this") == "writing"
    assert agents.classify("calculate 3 * 4") == "math"

def test_arena_graders():
    assert arena.check({"check": ("num", 42)}, "the answer is 42") == 1.0
    assert arena.check({"check": ("bool", False)}, "FALSE") == 1.0
    assert arena.check({"check": ("json", {"a": 1})}, 'here {"a": 1}') == 1.0
    assert arena.check({"check": ("code", "assert f(2)==4")}, "```python\ndef f(x): return x*2\n```") == 1.0
    assert arena.check({"check": ("code", "assert f(2)==5")}, "```python\ndef f(x): return x*2\n```") == 0.0

def test_reputation_is_category_specific():
    from atlas import economy
    for _ in range(5):
        economy.record_result("atlas-local", "math", 1.0)
    assert economy.reputation("atlas-local", "math")[0] == 1.0
    assert economy.reputation("atlas-local", "research") == (0.5, 0)
    assert economy.route("research", "medium")[0] == "atlas-local"  # only model available in tests
    assert "only the local engine" in economy.route("research", "medium")[1]

if __name__ == "__main__":
    n = 0
    for k, f in list(globals().items()):
        if k.startswith("test_"):
            f(); n += 1; print("PASS", k)
    print(f"{n} passed")
