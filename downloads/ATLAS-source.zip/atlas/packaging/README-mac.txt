ATLAS for Mac

1. Double-click ATLAS-mac.zip if it isn't unzipped yet, then drag ATLAS.app into your Applications folder.
2. Double-click ATLAS. macOS will say it can't verify the developer (ATLAS isn't signed with a paid Apple certificate).
   Open System Settings > Privacy & Security, scroll down, click "Open Anyway" next to ATLAS, and confirm.
   (Older macOS: right-click ATLAS > Open > Open.) You only do this once.
3. First launch takes about a minute: ATLAS sets up its own private Python environment.
   If your Mac asks to install "command line developer tools", click Install, wait, then open ATLAS again.
4. ATLAS opens in its own window (uses Google Chrome / Edge / Brave in app mode if installed, otherwise your browser).

Your data lives in ~/Library/Application Support/ATLAS. Deleting the app does not delete it.
Free AI models: install Ollama from https://ollama.com/download, open it, then use Settings in ATLAS to download models with one click.
Problems? Open System Health in ATLAS and press "Copy debug report", or read ~/Library/Application Support/ATLAS/launcher.log
