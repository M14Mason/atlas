#!/bin/bash
# Builds dist/ATLAS-mac.zip and dist/ATLAS-windows.zip from this source tree.
# Needs: python3, zip, unzip. Downloads the Windows Python runtime + wheels once into build/cache.
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${OUT:-$SRC/dist}"
CACHE="${CACHE:-$SRC/build-cache}"
VER="$(python3 -c "import re;print(re.search(r'__version__ = .(.+).', open('$SRC/atlas/__init__.py').read()).group(1))")"
PYV=3.12.8
mkdir -p "$OUT" "$CACHE"
STAGE="$(mktemp -d)"
echo "ATLAS $VER -> $OUT"

copy_app(){  # $1 = destination folder for the app code
  mkdir -p "$1/data"
  cp -r "$SRC/atlas" "$SRC/web" "$1/"
  cp "$SRC/launcher.py" "$SRC/run.py" "$SRC/worker.py" "$SRC/requirements.txt" "$SRC/README.md" "$1/"
  cp -r "$SRC/data/market" "$1/data/market"
  rm -f "$1"/data/market/user_*.csv
  find "$1" -name __pycache__ -prune -exec rm -rf {} +
}

# ---------------- macOS
APP="$STAGE/mac/ATLAS.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
sed "s/__VERSION__/$VER/g" "$SRC/packaging/Info.plist" > "$APP/Contents/Info.plist"
cp "$SRC/packaging/mac_launcher.sh" "$APP/Contents/MacOS/ATLAS"; chmod 755 "$APP/Contents/MacOS/ATLAS"
cp "$SRC/packaging/ATLAS.icns" "$APP/Contents/Resources/ATLAS.icns"
copy_app "$APP/Contents/Resources/atlas"
printf 'APPL????' > "$APP/Contents/PkgInfo"
cp "$SRC/packaging/README-mac.txt" "$STAGE/mac/How to open ATLAS.txt"
(cd "$STAGE/mac" && rm -f "$OUT/ATLAS-mac.zip" && zip -qry -X "$OUT/ATLAS-mac.zip" "ATLAS.app" "How to open ATLAS.txt")

# ---------------- Windows
W="$STAGE/win/ATLAS"
mkdir -p "$W/runtime" "$W/app"
[ -f "$CACHE/py-embed.zip" ] || curl -sSL -o "$CACHE/py-embed.zip" "https://www.python.org/ftp/python/$PYV/python-$PYV-embed-amd64.zip"
[ -d "$CACHE/wheels-win" ] || python3 -m pip download numpy pillow pypdf --only-binary=:all: --platform win_amd64 --python-version 3.12 --implementation cp -d "$CACHE/wheels-win" -q
unzip -q "$CACHE/py-embed.zip" -d "$W/runtime"
mkdir -p "$W/runtime/Lib/site-packages"
for whl in "$CACHE"/wheels-win/*.whl; do unzip -q -o "$whl" -d "$W/runtime/Lib/site-packages"; done
printf 'python312.zip\r\n.\r\nLib\\site-packages\r\n..\\app\r\nimport site\r\n' > "$W/runtime/python312._pth"
copy_app "$W/app"
cp "$SRC/packaging/ATLAS.exe" "$W/ATLAS.exe"
printf '@echo off\r\nREM Runs ATLAS with a visible console so you can see errors.\r\nset ATLAS_APP=1\r\n"%%~dp0runtime\\python.exe" "%%~dp0app\\launcher.py"\r\npause\r\n' > "$W/ATLAS (debug).bat"
sed 's/$/\r/' "$SRC/packaging/README-windows.txt" > "$W/README.txt"
(cd "$STAGE/win" && rm -f "$OUT/ATLAS-windows.zip" && zip -qr -X "$OUT/ATLAS-windows.zip" "ATLAS")

# ---------------- source
(cd "$SRC/.." && rm -f "$OUT/ATLAS-source.zip" && zip -qr "$OUT/ATLAS-source.zip" "$(basename "$SRC")" -x "*/__pycache__/*" "*/data/atlas.db*" "*/data/systems/*" "*/dist/*" "*/build-cache/*" "*/data/market_lab.json")
rm -rf "$STAGE"
ls -la "$OUT"
