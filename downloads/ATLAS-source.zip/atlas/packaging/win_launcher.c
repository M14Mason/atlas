// ATLAS.exe: starts the bundled Python (no console window) with launcher.py.
#include <windows.h>
#include <wchar.h>
int WINAPI wWinMain(HINSTANCE h, HINSTANCE p, PWSTR cmd, int show) {
    wchar_t dir[MAX_PATH], py[MAX_PATH], script[MAX_PATH], line[3 * MAX_PATH];
    GetModuleFileNameW(NULL, dir, MAX_PATH);
    wchar_t *slash = wcsrchr(dir, L'\\'); if (slash) *slash = 0;
    swprintf(py, MAX_PATH, L"%ls\\runtime\\pythonw.exe", dir);
    swprintf(script, MAX_PATH, L"%ls\\app\\launcher.py", dir);
    if (GetFileAttributesW(py) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL, L"ATLAS is missing its runtime folder. Extract the whole ATLAS zip and run ATLAS.exe from inside the extracted folder.", L"ATLAS", MB_ICONERROR);
        return 1;
    }
    swprintf(line, 3 * MAX_PATH, L"\"%ls\" \"%ls\"", py, script);
    STARTUPINFOW si = { sizeof(si) }; PROCESS_INFORMATION pi;
    SetEnvironmentVariableW(L"ATLAS_APP", L"1");
    if (!CreateProcessW(py, line, NULL, NULL, FALSE, 0, NULL, dir, &si, &pi)) {
        MessageBoxW(NULL, L"ATLAS could not start Python. Try 'ATLAS (debug).bat' to see the error.", L"ATLAS", MB_ICONERROR);
        return 1;
    }
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    return 0;
}
