#!/bin/bash
# ATLAS for macOS. Uses your Mac's Python 3 in a private environment.
# First launch installs numpy/pillow/pypdf into ~/Library/Application Support/ATLAS/venv (about a minute).
RES="$(cd "$(dirname "$0")/../Resources" && pwd)"
APPCODE="$RES/atlas"
if [ "$(uname)" = "Darwin" ]; then SUPPORT="$HOME/Library/Application Support/ATLAS"; else SUPPORT="${ATLAS_DATA:-$HOME/.local/share/atlas}"; fi
VENV="$SUPPORT/venv"
LOG="$SUPPORT/launcher.log"
mkdir -p "$SUPPORT"
export ATLAS_APP=1
[ -n "$ATLAS_DATA" ] || export ATLAS_DATA="$SUPPORT"

say_log(){ echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG"; }
notify(){ say_log "$1"; [ "$(uname)" = "Darwin" ] && osascript -e "display notification \"$1\" with title \"ATLAS\"" >/dev/null 2>&1; }
alert(){ say_log "ALERT: $1"; [ "$(uname)" = "Darwin" ] && osascript -e "display dialog \"$1\" buttons {\"OK\"} default button 1 with title \"ATLAS\" with icon caution" >/dev/null 2>&1; }

find_python(){
  for p in /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3 "$(command -v python3 2>/dev/null)" /usr/bin/python3; do
    [ -n "$p" ] && [ -x "$p" ] || continue
    # /usr/bin/python3 is only a stub until Apple's Command Line Tools are installed
    if [ "$p" = "/usr/bin/python3" ] && [ "$(uname)" = "Darwin" ] && ! xcode-select -p >/dev/null 2>&1; then continue; fi
    if "$p" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1; then echo "$p"; return 0; fi
  done
  return 1
}

STAMP="$(cat "$APPCODE/requirements.txt" "$APPCODE/atlas/__init__.py" 2>/dev/null | cksum | cut -d' ' -f1)"
if [ ! -x "$VENV/bin/python" ] || [ "$(cat "$VENV/.atlas_stamp" 2>/dev/null)" != "$STAMP" ]; then
  PY="$(find_python)"
  if [ -z "$PY" ]; then
    say_log "no python 3.9+ found"
    if [ "$(uname)" = "Darwin" ]; then
      BTN=$(osascript -e 'button returned of (display dialog "ATLAS needs Python 3, which comes with Apple'"'"'s free Command Line Tools.\n\nClick Install, follow Apple'"'"'s installer (a few minutes), then open ATLAS again." buttons {"Cancel", "Install"} default button "Install" with title "ATLAS" with icon note)' 2>/dev/null)
      [ "$BTN" = "Install" ] && xcode-select --install >/dev/null 2>&1
    fi
    exit 1
  fi
  notify "Setting up ATLAS for the first time (about a minute)…"
  say_log "using $PY ($("$PY" --version 2>&1))"
  rm -rf "$VENV"
  if ! "$PY" -m venv "$VENV" >> "$LOG" 2>&1; then alert "ATLAS could not create its Python environment. Details: $LOG"; exit 1; fi
  if ! "$VENV/bin/python" -m pip install --disable-pip-version-check -q -r "$APPCODE/requirements.txt" >> "$LOG" 2>&1; then
    alert "ATLAS could not download its components (numpy). Check your internet connection and open ATLAS again. Details: $LOG"
    rm -rf "$VENV"; exit 1
  fi
  echo "$STAMP" > "$VENV/.atlas_stamp"
  notify "ATLAS is ready."
fi
exec "$VENV/bin/python" "$APPCODE/launcher.py"
