# ATLAS build state (resume file)

Last updated: build session 2 (2026-11-18). Version 0.2.0.

## How to resume
Read this file, run the tests, continue at "Next steps". Do not restart or re-plan.
```
python3 tests/test_core.py                 # 7 invariant tests
python3 tests/test_api.py                  # ~45 end-to-end checks (local engine only)
python3 tests/fake_ollama.py 11500 &       # TEST-ONLY fake LLM + fake web + fake price feed
OLLAMA_HOST=http://127.0.0.1:11500 NO_PROXY=127.0.0.1 python3 tests/test_api.py --fake-llm   # 71 checks
packaging/build.sh                         # -> dist/ATLAS-mac.zip, ATLAS-windows.zip, ATLAS-source.zip
```
End of session 2: all passing on Python 3.13 AND 3.9 (macOS system Python is 3.9). Browser pass of 15 screens: 0 console errors.

## Architecture (decided, keep)
- Python stdlib HTTP server + SQLite (WAL) + numpy. Data dir: ./data (source run), or per-user when ATLAS_APP=1
  (~/Library/Application Support/ATLAS, %APPDATA%\ATLAS). db.APP_DIR = code/bundled resources (read-only).
- One event bus (`db.emit`) -> SSE -> UI. Visuals only from events/DB. `db.log(level, source, msg, detail)` -> logs table -> System Health.
- One model gateway `providers.complete()` (permissions, budget, ledger). Any network/protocol failure becomes ProviderError so tasks fall back instead of crashing.
- Background work: `compute.submit(kind, ...)` + `@compute.handler`. Automations = scheduled submits (automations.py scheduler thread, 20s tick).
- Frontend: vanilla ES modules, `web/js/core.js` (h, put, api, bus, charts, icon, modal, emptyState), one file per view. NEVER name a server route function the same as an imported module (bit us twice: `system`, `chat`).
- Desktop apps: `launcher.py` (free port, reuse running instance via data/port file, Chromium "app mode" window with its own profile, quits when window closes, `/api/system/quit`).
  - Mac: script-based .app (packaging/mac_launcher.sh) -> uses system/Homebrew Python >=3.9, creates venv in Application Support on first launch. Unsigned: Gatekeeper "Open Anyway" once.
  - Windows: python.org embeddable 3.12 + unpacked win wheels + zig-compiled GUI `ATLAS.exe` (packaging/win_launcher.c, icon via .rc). Unsigned: SmartScreen "Run anyway" once.

## Status
| area | status |
|---|---|
| v0.1 departments (council, workforce, arena, architect, ground-up, research lab, market lab, knowledge, compute, economy, workspace, settings) | done, tested |
| v0.2: Ask ATLAS chat (knowledge+web sources, export .md) | done, tested |
| web.py: DuckDuckGo search, fetch, extract, file to Knowledge; agent "web" tool | done; tested vs fake AND observed working against real DuckDuckGo + real page during a test run |
| peer review (verification agent, revise on FAIL) | done, tested |
| automations + templates | done, tested |
| marketdata.py (Alpaca -> Yahoo -> Stooq) | parsers tested vs fake feed; real Yahoo returned 429 from sandbox, real Stooq unreachable from sandbox. UNVERIFIED live. |
| Market: Hall of Fame, cross-asset backtest, export as system | done, tested |
| Ollama manager: status, recommended models, one-click pull w/ progress, auto-register pulled models | tested vs fake streaming /api/pull |
| System Health: 12 diagnostics, logs, debug report, backup zip, staged restore (applied at next start, old data moved not deleted) | done, tested |
| UI: setup wizard, ⌘K palette, job tray, icons, accent colours, notifications, quick-ask home, Quit | done, screenshot-tested |
| Mac app | simulated end to end on Linux (venv bootstrap, server from bundle, 12/12 diagnostics, quit). NOT run on a real Mac yet. |
| Windows app | structure, PE subsystem/icon/imports verified; no-console stdio fix tested. NOT run on real Windows (no Wine here). |

## Known limitations
- No real LLM has been run (sandbox policy blocked installing Ollama). Paid adapters untested (no keys).
- Apps are unsigned (no Apple Developer / code-signing cert): one-time Gatekeeper / SmartScreen click.
- No GitHub repo for ATLAS yet; gh CLI token here is invalid, so no CI. If Mason creates an empty repo `M14Mason/atlas`, push and add a GitHub Actions workflow that runs tests + build on macos-latest and windows-latest (real-OS verification).
- Arena code tests run model code in a subprocess (not a full sandbox); toggle in Settings.

## Next steps
1. Real-OS verification of both apps (CI on a repo, or Mason runs them and sends the System Health debug report).
2. Verify with real Ollama models; tune prompts for small models (council critique format, DECOMPOSE JSON).
3. Architect: image classifier (numpy CNN), time-series regression.
4. Market Lab: multi-asset portfolios; walk-forward hall-of-fame tournament.
5. Streaming chat responses (SSE token stream) for Ollama/Claude.
6. Code signing / notarization if Mason gets an Apple Developer account.
