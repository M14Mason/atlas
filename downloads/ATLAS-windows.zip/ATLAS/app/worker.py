#!/usr/bin/env python3
"""ATLAS compute worker. Run on any other machine (Windows PC, Mac, a free
Colab/Kaggle notebook) that has this folder and numpy installed:

    python worker.py --server http://<atlas-computer-ip>:8600 --token <token>

It claims neural-network training jobs, runs them locally, and sends the
results back. It only runs ATLAS's own training code, never arbitrary code.
"""
import argparse
import json
import platform
import socket
import time
import urllib.request

from atlas import compute, neural

p = argparse.ArgumentParser()
p.add_argument("--server", required=True)
p.add_argument("--token", default="")
p.add_argument("--name", default=socket.gethostname())
a = p.parse_args()


def call(path, body):
    req = urllib.request.Request(a.server.rstrip("/") + path, data=json.dumps(body).encode(), method="POST",
                                 headers={"content-type": "application/json", "x-atlas-token": a.token})
    return json.loads(urllib.request.urlopen(req, timeout=30).read())


specs = compute.local_specs()
print(f"worker {a.name} ({platform.system()}, {specs['cpus']} CPUs) -> {a.server}")
while True:
    try:
        nid = call("/api/worker/heartbeat", {"name": a.name, "specs": specs})["node_id"]
        job = call("/api/worker/claim", {"node_id": nid, "kinds": ["train"]})["job"]
        if not job:
            time.sleep(5)
            continue
        print("running job", job["id"])
        try:
            r = neural.train(job["payload"]["config"])
            r.pop("model", None)
            call("/api/worker/finish", {"job_id": job["id"], "result": r})
        except Exception as e:
            call("/api/worker/finish", {"job_id": job["id"], "error": str(e)})
    except Exception as e:
        print("connection problem:", e)
        time.sleep(10)
