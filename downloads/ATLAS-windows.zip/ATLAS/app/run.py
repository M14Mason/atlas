#!/usr/bin/env python3
"""Start ATLAS.   python3 run.py            (this computer only)
                  python3 run.py --lan      (phone/other devices on your Wi-Fi, token protected)
"""
import argparse
import socket
import webbrowser

from atlas import server

p = argparse.ArgumentParser()
p.add_argument("--port", type=int, default=8600)
p.add_argument("--lan", action="store_true", help="listen on your network (requires the printed token)")
p.add_argument("--no-browser", action="store_true")
a = p.parse_args()
host = "0.0.0.0" if a.lan else "127.0.0.1"
httpd = server.serve(host, a.port)
print(f"\n  ATLAS is running:  http://localhost:{a.port}")
if a.lan:
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except OSError:
        ip = "<this-computer-ip>"
    print(f"  On your phone:     http://{ip}:{a.port}/?token={server.TOKEN}")
    print("  Anyone with that link on your network can use ATLAS. Don't share it.")
print("  Stop with Ctrl+C\n")
if not a.no_browser:
    try:
        webbrowser.open(f"http://localhost:{a.port}")
    except Exception:
        pass
try:
    httpd.serve_forever()
except KeyboardInterrupt:
    print("\n  ATLAS stopped.")
