"""ATLAS desktop launcher (used by the Mac .app and Windows .exe).

1. Uses the per-user data folder (ATLAS_APP=1).
2. If ATLAS is already running, just opens another window.
3. Otherwise starts the server on a free port.
4. Opens ATLAS in its own app window (Chrome / Edge / Brave "app mode"
   with a dedicated profile, so it looks and behaves like a native app).
   Falls back to the default browser if none is found.
5. When the window closes, ATLAS shuts down. In browser-fallback mode it
   keeps running until you press Quit in the sidebar.
"""
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser

os.environ.setdefault("ATLAS_APP", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from atlas import db  # noqa: E402  (after env is set)

os.makedirs(db.DATA_DIR, exist_ok=True)
LOG = os.path.join(db.DATA_DIR, "launcher.log")
PORT_FILE = os.path.join(db.DATA_DIR, "port")

# pythonw.exe (Windows, no console) has no stdout/stderr; anything printed would crash.
if sys.stdout is None or sys.stderr is None:
    _out = open(os.path.join(db.DATA_DIR, "console.log"), "a", buffering=1)
    sys.stdout = sys.stdout or _out
    sys.stderr = sys.stderr or _out


def log(msg):
    with open(LOG, "a") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")


def running_port():
    try:
        port = int(open(PORT_FILE).read().strip())
        info = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/api/system/info", timeout=1.5).read())
        return port if "version" in info else None
    except Exception:
        return None


def free_port(preferred=8600):
    for p in [preferred] + list(range(8601, 8650)):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    raise RuntimeError("no free port")


def find_app_browser():
    system = platform.system()
    cands = []
    if system == "Darwin":
        for app in ("Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium", "Arc"):
            for root in ("/Applications", os.path.expanduser("~/Applications")):
                exe = f"{root}/{app}.app/Contents/MacOS/{app}"
                cands.append(exe)
    elif system == "Windows":
        pf = [os.environ.get(k, "") for k in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA")]
        for base in pf:
            cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                      os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"),
                      os.path.join(base, "BraveSoftware", "Brave-Browser", "Application", "brave.exe")]
    else:
        for n in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge", "brave-browser"):
            p = shutil.which(n)
            if p:
                cands.append(p)
    return next((c for c in cands if c and os.path.exists(c)), None)


def open_window(url, block):
    exe = find_app_browser()
    if os.environ.get("ATLAS_NO_WINDOW"):
        return None
    if exe:
        profile = os.path.join(db.DATA_DIR, "window-profile")
        args = [exe, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run", "--no-default-browser-check",
                "--window-size=1440,920", "--disable-features=Translate"]
        log(f"opening app window with {exe}")
        proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return proc
    log("no Chromium-based browser found; using default browser")
    webbrowser.open(url)
    return None


def main():
    port = running_port()
    if port:
        log(f"ATLAS already running on {port}; opening a window")
        p = open_window(f"http://127.0.0.1:{port}/", False)
        return
    from atlas import server
    port = free_port()
    httpd = server.serve("127.0.0.1", port)
    with open(PORT_FILE, "w") as f:
        f.write(str(port))
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    log(f"server started on {port}, data in {db.DATA_DIR}")
    proc = open_window(f"http://127.0.0.1:{port}/", True)
    stop = threading.Event()
    server.QUIT_HOOK = stop.set
    if proc is not None:
        # Chromium may hand the window to an existing process and exit early; detect that.
        t0 = time.time()
        proc.wait()
        if time.time() - t0 < 5:
            log("window process exited immediately (handed off); waiting for Quit instead")
            stop.wait()
    else:
        stop.wait()
    log("shutting down")
    httpd.shutdown()
    try:
        os.remove(PORT_FILE)
    except OSError:
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log("FATAL\n" + traceback.format_exc())
        raise
