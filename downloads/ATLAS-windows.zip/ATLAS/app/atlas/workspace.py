"""Personal AI Workspace: everyday tools built on ATLAS's systems.

finance      - technical analysis + Monte Carlo on bundled/imported data
learning     - flashcards from any document in the Knowledge Universe
photography  - exposure histogram, EXIF and composition stats (Pillow)
documents    - an agent drafts a document and files it in Knowledge
software     - an agent writes code; optional unit tests are run on it
research     - routed to the Council or Workforce from the UI
Optional libraries (Pillow, pypdf) are used when installed and the
feature reports clearly when they are missing.
"""
import io
import os
import re

import numpy as np

from . import agents, arena, db, knowledge, market, providers


def technical(asset, last=180):
    prices, dates = market.load_history()[asset]
    F = market.features(prices)
    p = prices[-last:]
    sma20 = np.convolve(prices, np.ones(20) / 20, "valid")[-last:]
    sma50 = np.convolve(prices, np.ones(50) / 50, "valid")[-last:]
    ret = np.diff(np.log(prices))
    rsi = F[-1, 4] * 50 + 50
    return {"asset": asset, "dates": dates[-last:], "close": p.round(2).tolist(), "sma20": sma20.round(2).tolist(),
            "sma50": sma50.round(2).tolist(), "last_date": dates[-1], "rsi14": round(float(rsi), 1),
            "vol_annual": round(float(ret[-60:].std() * np.sqrt(252)), 3),
            "return_1y": round(float(prices[-1] / prices[-253] - 1), 3),
            "max_drawdown_1y": round(float(((np.maximum.accumulate(prices[-252:]) - prices[-252:]) / np.maximum.accumulate(prices[-252:])).max()), 3),
            "signals": {f: round(float(F[-1, i]), 3) for i, f in enumerate(market.FEATURES)},
            "note": "Bundled data ends 2016-03-01. Import a CSV (Date,Close) for current data."}


def monte_carlo(asset, days=252, paths=2000, seed=0):
    prices, _ = market.load_history()[asset]
    r = np.diff(np.log(prices))[-756:]
    rng = np.random.default_rng(seed)
    sims = rng.choice(r, (paths, days)).sum(1)  # bootstrap from 3 years of real daily returns
    out = np.exp(sims) - 1
    pct = np.percentile(out, [5, 25, 50, 75, 95])
    return {"asset": asset, "days": days, "paths": paths, "method": "bootstrap of last 3y real daily returns",
            "percentiles": dict(zip(["p5", "p25", "p50", "p75", "p95"], pct.round(4).tolist())),
            "prob_loss": round(float((out < 0).mean()), 3),
            "hist": np.histogram(np.clip(out, -0.8, 1.5), bins=30, range=(-0.8, 1.5))[0].tolist()}


def import_prices(name, csv_text):
    rows = [l for l in csv_text.strip().splitlines() if l.strip()]
    header = [h.strip().lower() for h in rows[0].split(",")]
    if "date" not in header or "close" not in header:
        raise ValueError("CSV needs Date and Close columns")
    di, ci = header.index("date"), header.index("close")
    clean = ["Date,Close"]
    for l in rows[1:]:
        parts = l.split(",")
        try:
            clean.append(f"{parts[di]},{float(parts[ci])}")
        except (ValueError, IndexError):
            continue
    if len(clean) < 120:
        raise ValueError("need at least 120 daily rows")
    safe = re.sub(r"[^A-Za-z0-9]", "", name)[:12] or "custom"
    with open(os.path.join(market.user_dir(), f"user_{safe.upper()}.csv"), "w") as f:
        f.write("\n".join(clean))
    db.emit("workspace", "prices_imported", "user", asset=safe.upper(), rows=len(clean) - 1)
    return {"asset": safe.upper(), "rows": len(clean) - 1}


def flashcards(doc_id, n=8):
    d = db.one("SELECT * FROM docs WHERE id=?", (doc_id,))
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", d["content"]) if 40 < len(s.strip()) < 300]
    cards = []
    for s in sents:
        m = re.search(r"^(.{3,60}?)\s+(is|are|was|were|means|refers to)\s+(.+)$", s)
        if m:
            cards.append({"q": f"What {m.group(2)} {m.group(1).strip()}?", "a": m.group(3).rstrip(".")})
        if len(cards) >= n:
            break
    method = "pattern extraction (local, free)"
    try:
        model = [m for m in providers.available_models() if m["provider"] != "local"]
        if len(cards) < n and model:
            r = providers.complete(model[0]["id"], f"Make {n} flashcards from this text as lines 'Q: ... | A: ...'.\n\n{d['content'][:6000]}",
                                   purpose="workspace:flashcards", max_tokens=800)
            for line in r["text"].splitlines():
                mm = re.match(r"\s*Q:\s*(.+?)\s*\|\s*A:\s*(.+)", line)
                if mm:
                    cards.append({"q": mm.group(1), "a": mm.group(2)})
            method = f"pattern extraction + {model[0]['id']}"
    except Exception:
        pass
    return {"doc": d["title"], "cards": cards[:n * 2], "method": method}


def analyze_image(data):
    try:
        from PIL import Image, ExifTags
    except ImportError:
        return {"error": "Pillow not installed: pip install pillow"}
    img = Image.open(io.BytesIO(data))
    exif = {}
    try:
        for k, v in (img.getexif() or {}).items():
            tag = ExifTags.TAGS.get(k, str(k))
            if tag in ("Model", "Make", "DateTime", "LensModel", "Software"):
                exif[tag] = str(v)
        sub = img.getexif().get_ifd(0x8769)
        for k, v in sub.items():
            tag = ExifTags.TAGS.get(k, str(k))
            if tag in ("FNumber", "ExposureTime", "ISOSpeedRatings", "FocalLength"):
                exif[tag] = str(v)
    except Exception:
        pass
    g = np.asarray(img.convert("L").resize((256, int(256 * img.height / img.width) or 1)), dtype=float)
    hist = np.histogram(g, bins=32, range=(0, 255))[0]
    clip_hi, clip_lo = float((g > 250).mean()), float((g < 5).mean())
    # rule-of-thirds: where is the visual "energy" (gradient magnitude)?
    gy, gx = np.gradient(g)
    e = np.hypot(gx, gy)
    h, w = e.shape
    thirds = [[float(e[i * h // 3:(i + 1) * h // 3, j * w // 3:(j + 1) * w // 3].mean()) for j in range(3)] for i in range(3)]
    tips = []
    if clip_hi > 0.03:
        tips.append(f"{clip_hi:.0%} of pixels are blown out (pure white). Lower exposure about 1/3 to 2/3 stop.")
    if clip_lo > 0.05:
        tips.append(f"{clip_lo:.0%} of pixels are crushed black. Lift shadows or expose brighter.")
    if g.mean() < 70:
        tips.append("Overall the image is dark (mean brightness %.0f/255)." % g.mean())
    if g.std() < 35:
        tips.append("Low contrast. Try adding contrast or a stronger light source.")
    centre = thirds[1][1]
    if centre > 1.3 * np.mean([thirds[i][j] for i in range(3) for j in range(3)]):
        tips.append("Detail is concentrated in the centre. Try placing the subject on a third line.")
    return {"size": [img.width, img.height], "mode": img.mode, "exif": exif, "brightness": round(float(g.mean()), 1),
            "contrast": round(float(g.std()), 1), "clipped_highlights": round(clip_hi, 4), "clipped_shadows": round(clip_lo, 4),
            "histogram": hist.tolist(), "detail_by_third": thirds, "tips": tips or ["Exposure and contrast look balanced."],
            "method": "pixel statistics (local). Not an aesthetic judgement."}


def extract_text(filename, data):
    if filename.lower().endswith(".pdf"):
        try:
            import pypdf
        except ImportError:
            raise ValueError("pypdf not installed: pip install pypdf")
        reader = pypdf.PdfReader(io.BytesIO(data))
        return "\n\n".join(p.extract_text() or "" for p in reader.pages)
    return data.decode("utf-8", errors="replace")


def create_document(prompt, title=None):
    out = agents.run_task("document: " + prompt[:60], "Write a well-structured document: " + prompt)
    did = knowledge.add_doc(title or prompt[:60], out["output"], project="documents")
    return {"doc_id": did, **out}


def write_code(prompt, tests=None):
    out = agents.run_task("code: " + prompt[:60], prompt + "\nReturn the code in a ```python block.")
    result = {"task": out}
    if tests:
        result["tests_passed"] = bool(arena.run_code_test(out["output"], tests))
    return result
