"""Autonomy, permissions and safeguards.

Permissions are checked at the point of action (not just hidden in the
UI). Irreversible actions need a two-step confirmation token.
Autopilot is ATLAS's self-improvement loop; it is OFF by default and
respects every permission and spending limit.
"""
import secrets as pysecrets
import threading
import time

from . import db

DEFAULT_PERMS = {
    "agents_can_create_agents": True,
    "allow_paid_models": True,
    "allow_code_execution": True,
    "allow_web_access": True,         # agents/chat may search and read public web pages     # Arena code tests run model-written code locally (sandboxed subprocess)
    "autopilot": False,
    "autopilot_interval_min": 30,
}


class PermissionDenied(Exception):
    pass


def perms():
    return {**DEFAULT_PERMS, **db.setting("permissions", {})}


def set_perms(**changes):
    p = perms()
    p.update({k: v for k, v in changes.items() if k in DEFAULT_PERMS})
    db.set_setting("permissions", p)
    db.emit("control", "permissions_changed", "user", **changes)
    return p


def require(name):
    if not perms().get(name):
        db.emit("control", "permission_denied", "system", permission=name)
        raise PermissionDenied(f"permission '{name}' is off (change it in Settings)")


# ---------------------------------------------------- irreversible actions
_pending = {}


def request_confirmation(action, target):
    token = pysecrets.token_hex(4)
    _pending[token] = (action, target, time.time())
    return {"confirm_token": token, "message": f"Confirm {action} on {target}. This cannot be undone."}


def confirm(token, action, target):
    entry = _pending.pop(token, None)
    if not entry or entry[0] != action or entry[1] != target or time.time() - entry[2] > 300:
        raise PermissionDenied("confirmation missing, expired or mismatched")


# ---------------------------------------------------------------- autopilot
class Autopilot:
    def __init__(self):
        self.thread = None
        self.last_run = None
        self.log = []

    def ensure(self):
        if self.thread is None or not self.thread.is_alive():
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()

    def _loop(self):
        while True:
            p = perms()
            if p["autopilot"] and (self.last_run is None or time.time() - self.last_run > p["autopilot_interval_min"] * 60):
                self.cycle()
            time.sleep(15)

    def cycle(self):
        """One improvement cycle. Cheap by design."""
        from . import agents, arena, economy, providers
        self.last_run = time.time()
        actions = []
        db.emit("control", "autopilot_cycle", "autopilot")
        try:
            # 1. measure models nobody has measured yet (cheapest first, small samples)
            for m in sorted(providers.available_models(), key=lambda m: m["in"] + m["out"]):
                if m["provider"] == "local":
                    continue
                for cat in ("general", "math", "writing"):
                    if economy.reputation(m["id"], cat)[1] < 3:
                        arena.run_model(m["id"], cat, n=3)
                        actions.append(f"benchmarked {m['id']} on {cat}")
                        break
                if len(actions) >= 2:
                    break
            # 2. anticipate demand: frequent categories with no specialist get one (on probation)
            if p["agents_can_create_agents"]:
                rows = db.query("SELECT t.kind, a.parent_id mgr, COUNT(*) n FROM tasks t JOIN agents a ON a.id=t.agent_id "
                                "WHERE t.created>? AND t.kind!='general' GROUP BY t.kind, a.parent_id HAVING n>=5",
                                (time.time() - 7 * 86400,))
                for r in rows:
                    mgr = db.one("SELECT * FROM agents WHERE id=? AND role='manager'", (r["mgr"],))
                    if mgr and not db.one("SELECT id FROM agents WHERE parent_id=? AND specialty=? AND status!='retired'",
                                          (mgr["id"], r["kind"])):
                        agents.find_or_create_specialist(mgr, r["kind"])
                        actions.append(f"created {r['kind']} specialist for {mgr['name']} ({r['n']} recent tasks)")
            # 3. examine agents on probation
            for a in db.query("SELECT id, name FROM agents WHERE status='probation' LIMIT 2"):
                r = agents.evaluate(a["id"])
                actions.append(f"examined {a['name']}: {r['score']}")
        except Exception as e:
            actions.append(f"stopped: {e}")
        self.log = (self.log + [{"ts": time.time(), "actions": actions}])[-20:]
        db.emit("control", "autopilot_done", "autopilot", actions=actions)
        return actions


AUTOPILOT = Autopilot()
