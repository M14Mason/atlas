"""Web research tools: search + fetch + extract, with sources saved to Knowledge.

Search uses DuckDuckGo's HTML endpoint (free, no key). Pages are fetched
with a size cap and a timeout, converted to readable text, and filed in
the Knowledge Universe under project 'web' with their URL, so every
claim an agent makes from the web can be traced to a source.
Requires the 'allow_web_access' permission.
"""
import html
import re
import time
import urllib.parse
import urllib.request

from . import control, db, knowledge

SEARCH_URL = "https://html.duckduckgo.com/html/?q={q}"   # overridable in tests
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
MAX_BYTES = 1_500_000


def _get(url, timeout=12):
    req = urllib.request.Request(url, headers={"user-agent": UA, "accept-language": "en-US,en;q=0.8"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        ctype = r.headers.get("content-type", "")
        return r.read(MAX_BYTES).decode("utf-8", errors="replace"), ctype


def _strip(s):
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()


def search(query, n=6):
    control.require("allow_web_access")
    page, _ = _get(SEARCH_URL.format(q=urllib.parse.quote_plus(query)))
    results = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]+class="result__a"|$)', page, re.S):
        href, title, rest = m.groups()
        if "uddg=" in href:  # DuckDuckGo redirect wrapper
            href = urllib.parse.unquote(urllib.parse.parse_qs(urllib.parse.urlparse(href).query).get("uddg", [href])[0])
        sm = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', rest, re.S)
        if href.startswith("http") and "duckduckgo.com" not in href:
            results.append({"url": href, "title": _strip(title), "snippet": _strip(sm.group(1)) if sm else ""})
        if len(results) >= n:
            break
    db.emit("web", "search", "web", query=query, results=len(results))
    return results


def extract(page):
    page = re.sub(r"(?is)<(script|style|noscript|svg|nav|footer|header|form)[^>]*>.*?</\1>", " ", page)
    title = re.search(r"(?is)<title[^>]*>(.*?)</title>", page)
    body = re.sub(r"(?i)<(br|/p|/div|/h\d|/li|/tr)[^>]*>", "\n", page)
    text = _strip(body)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text)
    lines = [l.strip() for l in text.split("\n") if len(l.strip()) > 40 or l.strip() == ""]
    return (_strip(title.group(1)) if title else ""), "\n".join(lines).strip()


def fetch(url, save=True, project="web"):
    control.require("allow_web_access")
    if not re.match(r"^https?://", url):
        raise ValueError("only http(s) URLs")
    page, ctype = _get(url)
    if "html" not in ctype and "text" not in ctype:
        raise ValueError(f"unsupported content type {ctype}")
    title, text = extract(page) if "html" in ctype else (url, page)
    text = text[:60000]
    doc_id = None
    if save and len(text) > 200:
        doc_id = knowledge.add_doc(title or url, f"Source: {url}\nRetrieved: {time.strftime('%Y-%m-%d')}\n\n{text}", project)
    db.emit("web", "fetched", "web", url=url, chars=len(text), doc_id=doc_id)
    return {"url": url, "title": title, "text": text, "doc_id": doc_id}


def research(question, pages=3):
    """Search, read the top pages, return context with numbered sources."""
    hits = search(question, n=pages + 3)
    sources, ctx = [], []
    for h in hits:
        if len(sources) >= pages:
            break
        try:
            p = fetch(h["url"])
        except Exception as e:
            db.log("warn", "web", f"fetch failed {h['url']}: {e}")
            continue
        if len(p["text"]) < 200:
            continue
        sources.append({"n": len(sources) + 1, "url": h["url"], "title": p["title"] or h["title"]})
        # keep the paragraphs most related to the question
        paras = [x for x in p["text"].split("\n\n") if len(x) > 60]
        qw = set(knowledge.tokens(question))
        paras.sort(key=lambda x: -len(qw & set(knowledge.tokens(x))))
        ctx.append(f"[{len(sources)}] {sources[-1]['title']} ({h['url']})\n" + "\n".join(paras[:4])[:2500])
    return {"sources": sources, "context": "\n\n".join(ctx)}
