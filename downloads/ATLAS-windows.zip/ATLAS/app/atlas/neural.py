"""Ground-Up AI: a from-scratch neural network library in numpy.

Everything here is real math you can read: forward pass, backprop,
optimizers. It powers the Ground-Up lab, the Model Builder for ATLAS's
own models, the Research Lab experiments, and the AI Architect.

Teaching notes:
  * A Dense layer computes  y = x @ W + b
  * An activation bends that line so stacked layers can model curves
  * The loss measures how wrong predictions are
  * Backprop computes how each weight changed the loss (the gradient)
  * The optimizer nudges each weight against its gradient
"""
import json
import math

import numpy as np

ACTS = {
    "relu": (lambda z: np.maximum(0, z), lambda z, a: (z > 0).astype(z.dtype)),
    "tanh": (np.tanh, lambda z, a: 1 - a ** 2),
    "sigmoid": (lambda z: 1 / (1 + np.exp(-np.clip(z, -50, 50))), lambda z, a: a * (1 - a)),
    "gelu": (lambda z: 0.5 * z * (1 + np.tanh(0.79788456 * (z + 0.044715 * z ** 3))),
             lambda z, a: 0.5 * (1 + np.tanh(0.79788456 * (z + 0.044715 * z ** 3))) +
             0.5 * z * (1 - np.tanh(0.79788456 * (z + 0.044715 * z ** 3)) ** 2) * 0.79788456 * (1 + 3 * 0.044715 * z ** 2)),
    "linear": (lambda z: z, lambda z, a: np.ones_like(z)),
}


# ---------------------------------------------------------------- datasets
def dataset(name, n=600, noise=0.15, seed=0, **kw):
    rng = np.random.default_rng(seed)
    if name == "spiral":
        k = kw.get("classes", 3)
        per = n // k
        X, y = [], []
        for c in range(k):
            r = np.linspace(0.05, 1, per)
            t = np.linspace(c * 4, (c + 1) * 4, per) + rng.normal(0, noise, per)
            X.append(np.c_[r * np.sin(t), r * np.cos(t)])
            y += [c] * per
        return np.vstack(X), np.array(y), "classification"
    if name == "moons":
        h = n // 2
        t = rng.uniform(0, math.pi, h)
        X = np.r_[np.c_[np.cos(t), np.sin(t)], np.c_[1 - np.cos(t), 0.5 - np.sin(t)]] + rng.normal(0, noise, (2 * h, 2))
        return (X - X.mean(0)) / X.std(0), np.r_[np.zeros(h), np.ones(h)].astype(int), "classification"
    if name == "circles":
        h = n // 2
        t = rng.uniform(0, 2 * math.pi, n)
        r = np.r_[np.ones(h), np.full(n - h, 0.45)]
        X = np.c_[r * np.cos(t), r * np.sin(t)] + rng.normal(0, noise / 2, (n, 2))
        return X, np.r_[np.zeros(h), np.ones(n - h)].astype(int), "classification"
    if name == "xor":
        X = rng.uniform(-1, 1, (n, 2))
        return X, ((X[:, 0] > 0) ^ (X[:, 1] > 0)).astype(int), "classification"
    if name == "blobs":
        k = kw.get("classes", 4)
        centers = rng.uniform(-1, 1, (k, 2))
        y = rng.integers(0, k, n)
        return centers[y] + rng.normal(0, noise * 1.5, (n, 2)), y, "classification"
    if name == "sine":
        X = rng.uniform(-3, 3, (n, 1))
        return X, (np.sin(X[:, 0] * 1.5) + rng.normal(0, noise, n)), "regression"
    raise ValueError(f"unknown dataset {name}")


def split(X, y, seed=0, val=0.2, test=0.1):
    idx = np.random.default_rng(seed + 1).permutation(len(X))
    nt, nv = int(len(X) * test), int(len(X) * val)
    te, va, tr = idx[:nt], idx[nt:nt + nv], idx[nt + nv:]
    return (X[tr], y[tr]), (X[va], y[va]), (X[te], y[te])


# ---------------------------------------------------------------- network
class MLP:
    def __init__(self, n_in, hidden, n_out, activation="relu", task="classification", seed=0, dropout=0.0):
        rng = np.random.default_rng(seed)
        sizes = [n_in] + list(hidden) + [n_out]
        self.W, self.b = [], []
        for a, b in zip(sizes[:-1], sizes[1:]):
            scale = math.sqrt(2 / a) if activation in ("relu", "gelu") else math.sqrt(1 / a)  # He / Xavier init
            self.W.append(rng.normal(0, scale, (a, b)))
            self.b.append(np.zeros(b))
        self.act, self.task, self.dropout = activation, task, dropout
        self.rng = rng
        self.norm = None

    def params(self):
        return sum(w.size + b.size for w, b in zip(self.W, self.b))

    def forward(self, X, train=False):
        f = ACTS[self.act][0]
        cache = [(None, X, None)]
        a = X
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = a @ W + b
            last = i == len(self.W) - 1
            if last:
                if self.task == "classification":
                    e = np.exp(z - z.max(1, keepdims=True))
                    a = e / e.sum(1, keepdims=True)
                else:
                    a = z
                mask = None
            else:
                a = f(z)
                mask = None
                if train and self.dropout > 0:
                    mask = (self.rng.random(a.shape) > self.dropout) / (1 - self.dropout)
                    a = a * mask
            cache.append((z, a, mask))
        return a, cache

    def loss_grad(self, out, y):
        n = len(y)
        if self.task == "classification":
            loss = -np.log(out[np.arange(n), y] + 1e-12).mean()
            g = out.copy()
            g[np.arange(n), y] -= 1
            return loss, g / n
        diff = out[:, 0] - y
        return (diff ** 2).mean(), (2 * diff / n)[:, None]

    def backward(self, cache, g, l2):
        df = ACTS[self.act][1]
        gW, gb = [None] * len(self.W), [None] * len(self.W)
        for i in reversed(range(len(self.W))):
            a_prev = cache[i][1]
            gW[i] = a_prev.T @ g + l2 * self.W[i]
            gb[i] = g.sum(0)
            if i > 0:
                z, a, mask = cache[i]
                g = (g @ self.W[i].T)
                if mask is not None:
                    g = g * mask
                g = g * df(z, a if mask is None else a / np.where(mask == 0, 1, mask))
        return gW, gb

    def predict(self, X):
        if self.norm:
            X = (X - np.array(self.norm["mean"])) / np.array(self.norm["std"])
        out, _ = self.forward(X)
        return out.argmax(1) if self.task == "classification" else out[:, 0]

    def to_json(self):
        return {"W": [w.tolist() for w in self.W], "b": [b.tolist() for b in self.b], "act": self.act,
                "task": self.task, "norm": self.norm}

    @classmethod
    def from_json(cls, d):
        m = cls.__new__(cls)
        m.W = [np.array(w) for w in d["W"]]
        m.b = [np.array(b) for b in d["b"]]
        m.act, m.task, m.dropout, m.norm = d["act"], d["task"], 0.0, d.get("norm")
        m.rng = np.random.default_rng(0)
        return m


class Optimizer:
    def __init__(self, kind="adam", lr=0.01, beta1=0.9, beta2=0.999):
        self.kind, self.lr, self.b1, self.b2, self.t, self.m, self.v = kind, lr, beta1, beta2, 0, None, None

    def step(self, params, grads):
        if self.m is None:
            self.m = [np.zeros_like(p) for p in params]
            self.v = [np.zeros_like(p) for p in params]
        self.t += 1
        for i, (p, g) in enumerate(zip(params, grads)):
            if self.kind == "sgd":
                p -= self.lr * g
            elif self.kind == "momentum":
                self.m[i] = 0.9 * self.m[i] + g
                p -= self.lr * self.m[i]
            else:
                self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
                self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
                mh = self.m[i] / (1 - self.b1 ** self.t)
                vh = self.v[i] / (1 - self.b2 ** self.t)
                p -= self.lr * mh / (np.sqrt(vh) + 1e-8)


def metric(model, X, y):
    if len(y) == 0:
        return None
    p = model.predict(X)
    if model.task == "classification":
        return float((p == y).mean())
    return float(1 - ((p - y) ** 2).sum() / (((y - y.mean()) ** 2).sum() + 1e-12))  # R^2


def train(cfg, progress=None, X=None, y=None, task=None, init=None):
    """cfg: dataset, hidden, activation, optimizer, lr, epochs, batch, l2, dropout, seed, noise, n.
    Returns metrics, history, snapshots and the serialised model."""
    seed = int(cfg.get("seed", 0))
    if X is None:
        X, y, task = dataset(cfg.get("dataset", "spiral"), cfg.get("n", 600), cfg.get("noise", 0.15), seed,
                             classes=cfg.get("classes", 3))
    X = np.asarray(X, dtype=float)
    norm = {"mean": X.mean(0).tolist(), "std": (X.std(0) + 1e-9).tolist()}
    Xn = (X - np.array(norm["mean"])) / np.array(norm["std"])
    (Xtr, ytr), (Xva, yva), (Xte, yte) = split(Xn, y, seed, cfg.get("val_frac", 0.2), cfg.get("test_frac", 0.1))
    n_out = int(y.max()) + 1 if task == "classification" else 1
    if init is not None:
        model = MLP.from_json(init)
        model.dropout = float(cfg.get("dropout", 0))
    else:
        model = MLP(X.shape[1], cfg.get("hidden", [32, 32]), n_out, cfg.get("activation", "relu"), task, seed,
                    float(cfg.get("dropout", 0)))
    opt = Optimizer(cfg.get("optimizer", "adam"), float(cfg.get("lr", 0.01)))
    epochs, bs, l2 = int(cfg.get("epochs", 200)), int(cfg.get("batch", 64)), float(cfg.get("l2", 1e-4))
    rng = np.random.default_rng(seed + 2)
    hist, snaps = [], []
    grid = None
    if X.shape[1] == 2:
        g = np.linspace(-2.5, 2.5, 40)
        gx, gy = np.meshgrid(g, g)
        grid = np.c_[gx.ravel(), gy.ravel()]
    every = max(1, epochs // 20)
    for ep in range(epochs):
        perm = rng.permutation(len(Xtr))
        tot = 0.0
        for s in range(0, len(Xtr), bs):
            bi = perm[s:s + bs]
            out, cache = model.forward(Xtr[bi], train=True)
            loss, g = model.loss_grad(out, ytr[bi])
            gW, gb = model.backward(cache, g, l2)
            opt.step(model.W + model.b, gW + gb)
            tot += loss * len(bi)
        if ep % every == 0 or ep == epochs - 1:
            vo, _ = model.forward(Xva)
            vloss, _ = model.loss_grad(vo, yva) if len(yva) else (None, None)
            row = {"epoch": ep + 1, "loss": round(tot / len(Xtr), 5), "val_loss": round(float(vloss), 5) if vloss is not None else None,
                   "train_metric": round(metric(model, Xtr, ytr), 4), "val_metric": round(metric(model, Xva, yva) or 0, 4)}
            if not np.isfinite(row["loss"]):
                row["diverged"] = True
                hist.append(row)
                break
            hist.append(row)
            snap = None
            if grid is not None and task == "classification":
                snap = model.forward(grid)[0].argmax(1).tolist()
                snaps.append({"epoch": ep + 1, "grid": snap})
            if progress:
                progress((ep + 1) / epochs, **row)
    model.norm = None
    result = {"metrics": {"train": metric(model, Xtr, ytr), "val": metric(model, Xva, yva), "test": metric(model, Xte, yte),
                          "metric_name": "accuracy" if task == "classification" else "R2"},
              "history": hist, "params": model.params(), "task": task,
              "snapshots": snaps[-12:], "points": {"X": Xn[:400].round(3).tolist(), "y": np.asarray(y[:400]).tolist()}
              if X.shape[1] <= 2 else None}
    model.norm = norm
    result["model"] = model.to_json()
    return result
