"""Knowledge Universe: documents, semantic search, knowledge graph, memory.

Search uses TF-IDF vectors with cosine similarity (numpy, fully local,
free). It is lexical-semantic, not neural: it matches related wording
well but will miss pure synonyms. The interface (index/search) is the
same one a neural embedding model would use, so swapping in local
sentence embeddings later is a one-function change in `_vectorize`.

Three kinds of learning are kept deliberately separate:
  memory     - facts ATLAS stored and can retrieve (no behaviour change)
  skill      - reusable procedures/prompts agents apply to new tasks
  parameter  - actual weight changes from training (Model Builder)
"""
import math
import re
import threading
import time
from collections import Counter

import numpy as np

from . import db

STOP = set("""a an the and or but if of to in on for with at by from as is are was were be been being it its this that
these those i you he she we they them his her our your their not no yes do does did so than then there here what which
who whom how why when where can could should would will shall may might must about into over under also just very more
most such only own same too s t""".split())

_index = {"vocab": {}, "idf": None, "mat": None, "chunks": [], "dirty": True}
_ilock = threading.Lock()


def tokens(text):
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP and len(w) > 1]


def chunk(text, size=600):
    paras = re.split(r"\n\s*\n", text)
    out, cur = [], ""
    for p in paras:
        if len(cur) + len(p) > size and cur:
            out.append(cur.strip())
            cur = ""
        cur += p + "\n\n"
        while len(cur) > size * 2:
            out.append(cur[:size].strip())
            cur = cur[size:]
    if cur.strip():
        out.append(cur.strip())
    return out


def add_doc(title, content, project="general", emit=True):
    did = db.insert("docs", title=title, content=content, project=project, ts=time.time())
    _index["dirty"] = True
    if emit:
        db.emit("knowledge", "doc_added", "librarian", doc_id=did, title=title, chars=len(content), project=project)
    return did


def remember(kind, subject, content, source="user"):
    assert kind in ("memory", "skill", "parameter")
    mid = db.insert("memories", kind=kind, subject=subject, content=content, source=source, ts=time.time())
    db.emit("knowledge", f"{kind}_stored", source, id=mid, subject=subject)
    _index["dirty"] = True
    return mid


def _rebuild():
    chunks = []
    for d in db.query("SELECT id, title, content, project FROM docs"):
        for i, c in enumerate(chunk(d["content"])):
            chunks.append({"doc_id": d["id"], "title": d["title"], "project": d["project"], "text": c, "i": i})
    for m in db.query("SELECT id, kind, subject, content FROM memories"):
        chunks.append({"doc_id": None, "memory_id": m["id"], "title": f"[{m['kind']}] {m['subject']}",
                       "project": "memory", "text": m["content"], "i": 0})
    vocab, df = {}, Counter()
    toks = [tokens(c["title"] + " " + c["text"]) for c in chunks]
    for t in toks:
        df.update(set(t))
    for w in df:
        vocab[w] = len(vocab)
    n = max(1, len(chunks))
    idf = np.array([math.log((1 + n) / (1 + df[w])) + 1 for w in vocab]) if vocab else np.zeros(0)
    mat = np.zeros((len(chunks), len(vocab)), dtype=np.float32)
    for r, t in enumerate(toks):
        for w, c in Counter(t).items():
            mat[r, vocab[w]] = (1 + math.log(c)) * idf[vocab[w]]
    norms = np.linalg.norm(mat, axis=1, keepdims=True)
    mat /= np.where(norms == 0, 1, norms)
    _index.update(vocab=vocab, idf=idf, mat=mat, chunks=chunks, dirty=False)


def _vectorize(text):
    v = np.zeros(len(_index["vocab"]), dtype=np.float32)
    for w, c in Counter(tokens(text)).items():
        j = _index["vocab"].get(w)
        if j is not None:
            v[j] = (1 + math.log(c)) * _index["idf"][j]
    n = np.linalg.norm(v)
    return v / n if n else v


EMBED_MODEL = "nomic-embed-text"


def _embedder():
    """Neural embeddings via a local Ollama embedding model, if pulled.
    Returns a function texts -> np.array, or None."""
    from . import providers
    import json as _json
    import urllib.request
    ol = providers.ADAPTERS["ollama"]
    if not ol.available():
        return None
    try:
        tags = _json.loads(urllib.request.urlopen(ol.host() + "/api/tags", timeout=2).read())
        if not any(m["name"].split(":")[0] == EMBED_MODEL for m in tags.get("models", [])):
            return None
    except Exception:
        return None

    def embed(texts):
        r = providers._post(ol.host() + "/api/embed", {"model": EMBED_MODEL, "input": texts}, {}, timeout=120)
        v = np.array(r["embeddings"], dtype=np.float32)
        return v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)
    return embed


def _chunk_vectors(embed):
    import hashlib
    out = []
    missing = []
    for i, c in enumerate(_index["chunks"]):
        hsh = hashlib.sha1((EMBED_MODEL + c["title"] + c["text"]).encode()).hexdigest()
        row = db.one("SELECT vec FROM embeddings WHERE hash=?", (hsh,))
        if row:
            out.append(np.frombuffer(row["vec"], dtype=np.float32))
        else:
            out.append(None)
            missing.append((i, hsh))
    for s in range(0, len(missing), 32):
        batch = missing[s:s + 32]
        vecs = embed([_index["chunks"][i]["title"] + "\n" + _index["chunks"][i]["text"] for i, _ in batch])
        for (i, hsh), v in zip(batch, vecs):
            db.execute("INSERT OR REPLACE INTO embeddings(hash, model, vec) VALUES(?,?,?)", (hsh, EMBED_MODEL, v.tobytes()))
            out[i] = v
    return np.vstack(out) if out else None


def search_mode():
    return "hybrid (neural embeddings + TF-IDF)" if _embedder() else "TF-IDF (lexical)"


def search(q, k=5, project=None):
    with _ilock:
        if _index["dirty"]:
            _rebuild()
        if not _index["chunks"]:
            return []
        scores = _index["mat"] @ _vectorize(q)
        try:
            embed = _embedder()
            if embed:
                M = _chunk_vectors(embed)
                scores = 0.4 * scores + 0.6 * (M @ embed([q])[0])
        except Exception:
            pass  # fall back to TF-IDF only
        order = np.argsort(-scores)
        out = []
        for i in order:
            c = _index["chunks"][i]
            if project and c["project"] != project:
                continue
            if scores[i] <= 0:
                break
            out.append({**{k2: c[k2] for k2 in ("doc_id", "title", "project")}, "score": float(scores[i]),
                        "snippet": c["text"][:400]})
            if len(out) >= k:
                break
        return out


def graph(limit_nodes=60):
    """Entity graph: capitalised phrases and strong keywords become nodes,
    co-occurrence inside the same chunk becomes weighted edges."""
    with _ilock:
        if _index["dirty"]:
            _rebuild()
        chunks = list(_index["chunks"])
    ent_re = re.compile(r"\b([A-Z][a-zA-Z0-9]+(?:\s+[A-Z][a-zA-Z0-9]+)*)\b")
    counts, pairs = Counter(), Counter()
    for c in chunks:
        ents = {e for e in ent_re.findall(c["text"]) if e.lower() not in STOP and len(e) > 2}
        ents |= {f"doc:{c['title']}"}
        counts.update(ents)
        el = sorted(ents)
        for i in range(len(el)):
            for j in range(i + 1, len(el)):
                pairs[(el[i], el[j])] += 1
    top = {e for e, _ in counts.most_common(limit_nodes)}
    nodes = [{"id": e, "weight": counts[e], "type": "doc" if e.startswith("doc:") else "entity"} for e in top]
    edges = [{"a": a, "b": b, "w": w} for (a, b), w in pairs.items() if a in top and b in top]
    return {"nodes": nodes, "edges": edges}


def stats():
    return {"search_mode": search_mode(), "docs": db.one("SELECT COUNT(*) n FROM docs")["n"],
            "memories": db.query("SELECT kind, COUNT(*) n FROM memories GROUP BY kind"),
            "chunks": len(_index["chunks"])}
