"""AI Workforce: agent hierarchy, delegation, evaluation and evolution.

Lifecycle of a task:
  1. A manager agent receives it.
  2. It decomposes the task (its model, or the local splitter as fallback).
  3. Each subtask is classified into a category and routed to a
     subordinate specialist. If none exists, the manager creates one
     (status=probation) and the event is logged.
  4. Subordinates execute with their tools (knowledge lookup, calculator,
     memory). Every message is stored in `messages`.
  5. A reviewer grades the output when a grader exists (exact checks for
     math, model review otherwise). Grades feed agent stats and model
     reputation.
  6. The manager synthesises the final answer.

Evolution: when a generalist keeps doing the same category of work, the
system spawns a cheaper specialist on probation, evaluates it in the
Arena, and only promotes it to `trusted` if it passes. Important tasks
are only ever given to trusted agents. Every config change is versioned
and can be rolled back.
"""
import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from . import db, economy, knowledge, providers

CATEGORIES = {
    "math": r"\b(?:calculat\w*|comput\w*|sum|percent\w*|average|math|equation)\b|\d+\s*[\+\-\*/x×]\s*\d+",
    "code": r"\b(code|html|css|javascript|python|function|script|bug|api|website|app)\b",
    "research": r"\b(research|find|look up|investigate|sources?|history of|what is|who is)\b",
    "verification": r"\b(verify|check|fact|validate|confirm|review)\b",
    "analysis": r"\b(analy[sz]e|compare|evaluate|trend|risk|pros|cons|why)\b",
    "writing": r"\b(write|draft|summari[sz]e|explain|essay|email|post|outline)\b",
    "finance": r"\b(stock|market|portfolio|trading|price|invest|earnings|ticker)\b",
}

SPECIALIST_PROMPTS = {
    "math": "You are a precise math specialist. Show the key step, then the final number on the last line.",
    "code": "You are a senior software engineer. Return correct, minimal, well-commented code.",
    "research": "You are a research specialist. Answer factually, say what you are unsure of, never invent sources.",
    "verification": "You are a verification specialist. Check claims for errors and state PASS or FAIL with reasons.",
    "analysis": "You are an analyst. Give a structured, evidence-based analysis with clear trade-offs.",
    "writing": "You are a clear, concise writer.",
    "finance": "You are a financial analyst. Be precise, flag risks, never give personalised investment advice.",
    "general": "You are a capable general assistant.",
}


def classify(text):
    t = text.lower()
    scores = {c: len(re.findall(p, t)) for c, p in CATEGORIES.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] else "general"


# ------------------------------------------------------------- CRUD
def create(name, role="specialist", specialty="general", model="auto", parent_id=None, status="probation",
           system=None, tools=None, can_delegate=False, note="created"):
    config = {"system": system or SPECIALIST_PROMPTS.get(specialty, SPECIALIST_PROMPTS["general"]),
              "tools": tools if tools is not None else (["knowledge", "calculator", "web"] if specialty in
                                                        ("research", "finance", "verification") else ["knowledge", "calculator"]),
              "can_delegate": can_delegate}
    aid = db.insert("agents", name=name, parent_id=parent_id, model=model, role=role, specialty=specialty,
                    status=status, version=1, config=config,
                    stats={"tasks": 0, "ok": 0, "graded": 0, "quality_sum": 0.0, "by_category": {}},
                    created=time.time())
    db.insert("agent_versions", agent_id=aid, version=1, config=json.dumps({"model": model, **config}), note=note, ts=time.time())
    db.emit("workforce", "agent_created", name, agent_id=aid, parent_id=parent_id, specialty=specialty,
            model=model, status=status, role=role)
    return aid


def get(aid):
    return db.one("SELECT * FROM agents WHERE id=?", (aid,))


def all_agents():
    return db.query("SELECT * FROM agents WHERE status!='retired' ORDER BY id")


def update_config(aid, note="edited", **changes):
    a = get(aid)
    cfg = a["config"]
    model = changes.pop("model", a["model"])
    status = changes.pop("status", a["status"])
    cfg.update({k: v for k, v in changes.items() if v is not None})
    v = a["version"] + 1
    db.update("agents", aid, config=cfg, model=model, version=v, status=status)
    db.insert("agent_versions", agent_id=aid, version=v, config=json.dumps({"model": model, **cfg}), note=note, ts=time.time())
    db.emit("workforce", "agent_updated", a["name"], agent_id=aid, version=v, note=note)
    return v


def rollback(aid, version):
    row = db.one("SELECT config FROM agent_versions WHERE agent_id=? AND version=?", (aid, version))
    if not row:
        raise ValueError("no such version")
    cfg = json.loads(row["config"]) if isinstance(row["config"], str) else row["config"]
    model = cfg.pop("model")
    return update_config(aid, note=f"rollback to v{version}", model=model, **cfg)


def versions(aid):
    return db.query("SELECT version, config, note, ts FROM agent_versions WHERE agent_id=? ORDER BY version DESC", (aid,))


def ensure_seed():
    """First run: one manager team per available model family plus a
    Director. Teams exist even before keys are added; their tasks route
    to whatever model is actually available."""
    if db.one("SELECT id FROM agents"):
        return
    director = create("Director", role="director", specialty="general", model="auto", status="trusted",
                      can_delegate=True, system="You are the ATLAS Director. Break work into clear subtasks.",
                      note="seed")
    for name, model in [("Claude Team Lead", "claude-sonnet-5-5"), ("GPT Team Lead", "gpt-5"),
                        ("Gemini Team Lead", "gemini-2.5-pro"), ("Open-Source Lead", "ollama:llama3.2")]:
        create(name, role="manager", specialty="general", model=model, parent_id=director, status="trusted",
               can_delegate=True, note="seed")


# ------------------------------------------------------------- execution
def _resolve_model(agent, category, difficulty):
    m = agent["model"]
    if m != "auto":
        try:
            if providers.model_info(m)["available"]:
                return m, "agent's assigned model"
        except providers.ProviderError:
            pass
    return economy.route(category, difficulty)


def _say(thread, sender, recipient, content):
    db.insert("messages", ts=time.time(), thread=thread, sender=sender, recipient=recipient, content=content[:4000])
    db.emit("workforce", "message", sender, thread=thread, recipient=recipient, preview=content[:180])


def execute(agent_id, text, task_id, thread, difficulty="medium"):
    """One agent does one piece of work with its tools."""
    agent = get(agent_id)
    cfg = agent["config"]
    category = agent["specialty"] if agent["specialty"] != "general" else classify(text)
    model, why = _resolve_model(agent, category, difficulty)
    db.emit("workforce", "agent_working", agent["name"], agent_id=agent_id, task_id=task_id, model=model, why=why)
    context = ""
    if "knowledge" in cfg.get("tools", []):
        hits = knowledge.search(text, k=3)
        hits = [h for h in hits if h["score"] > 0.1]
        if hits:
            context = "Relevant knowledge:\n" + "\n".join(f"- ({h['title']}) {h['snippet'][:300]}" for h in hits) + "\n\n"
            db.emit("workforce", "tool_use", agent["name"], tool="knowledge", hits=len(hits), task_id=task_id)
    if "web" in cfg.get("tools", []) and category in ("research", "finance", "analysis", "verification"):
        from . import control, web
        if control.perms().get("allow_web_access"):
            try:
                r = web.research(text, pages=2)
                if r["sources"]:
                    context += ("Web sources (cite as [1], [2]):\n" + r["context"][:5000] + "\n\n")
                    db.emit("workforce", "tool_use", agent["name"], tool="web", sources=len(r["sources"]), task_id=task_id)
            except Exception as e:
                db.log("warn", "agents", f"web tool failed: {e}")
    if "calculator" in cfg.get("tools", []) and category == "math":
        local = providers.ADAPTERS["local"].answer(text)
        if re.fullmatch(r"-?[\d\.]+", local):
            context += f"Calculator result: {local}\n\n"
            db.emit("workforce", "tool_use", agent["name"], tool="calculator", result=local, task_id=task_id)
    try:
        res = providers.complete(model, context + text, system=cfg["system"], agent_id=agent_id,
                                 task_id=task_id, purpose=f"task:{category}")
    except (providers.ProviderError, economy.BudgetExceeded) as e:
        model = "atlas-local"
        res = providers.complete(model, context + text, system=cfg["system"], agent_id=agent_id, task_id=task_id,
                                 purpose=f"fallback:{category}")
        res["text"] = f"(fallback to local engine: {e})\n" + res["text"]
    if "remember" in cfg.get("tools", []):
        knowledge.remember("memory", text[:80], res["text"][:2000], source=agent["name"])
    return res, category, model


def grade(text, output, category):
    """Returns (score 0..1 or None, method). Exact where possible."""
    if category == "math":
        expected = providers.ADAPTERS["local"].answer(text)
        if re.fullmatch(r"-?[\d\.]+", expected):
            nums = re.findall(r"-?\d[\d,]*\.?\d*", output.replace(",", ""))
            ok = bool(nums) and abs(float(nums[-1]) - float(expected)) < 1e-6 * max(1, abs(float(expected)))
            return (1.0 if ok else 0.0), "exact (calculator)"
    if output.startswith("(fallback") or output.startswith("[ATLAS Local Engine] I can only"):
        return 0.0, "no capable model"
    try:
        reviewer, _ = economy.route("verification", "easy", exclude_local=True)
    except RuntimeError:
        return None, "ungraded (no reviewer model)"
    if reviewer == "atlas-local":
        return None, "ungraded (no reviewer model)"
    try:
        r = providers.complete(reviewer, f"TASK:\n{text}\n\nANSWER:\n{output[:3000]}\n\nScore the answer's correctness "
                               "and usefulness from 0 to 10. Reply with only the number.",
                               system="You are a strict grader.", max_tokens=5, purpose="grading")
        m = re.search(r"\d+(\.\d+)?", r["text"])
        return (min(10, float(m.group())) / 10 if m else None), f"model review ({reviewer})"
    except Exception as e:
        return None, f"ungraded ({e})"


_stats_lock = threading.Lock()


def _record(agent_id, category, score, ok):
    with _stats_lock:
        _record_unlocked(agent_id, category, score, ok)


def _record_unlocked(agent_id, category, score, ok):
    a = get(agent_id)
    s = a["stats"]
    s["tasks"] += 1
    s["ok"] += int(ok)
    bc = s["by_category"].setdefault(category, {"n": 0, "q": 0.0, "graded": 0})
    bc["n"] += 1
    if score is not None:
        s["graded"] += 1
        s["quality_sum"] += score
        bc["graded"] += 1
        bc["q"] += score
    db.update("agents", agent_id, stats=s)


def find_or_create_specialist(manager, category):
    sub = db.one("SELECT * FROM agents WHERE parent_id=? AND specialty=? AND status IN ('trusted','probation') "
                 "ORDER BY status='trusted' DESC, id LIMIT 1", (manager["id"], category))
    if sub:
        return sub["id"], False
    from . import control
    if not control.perms()["agents_can_create_agents"]:
        db.emit("workforce", "permission_denied", manager["name"], permission="agents_can_create_agents")
        return manager["id"], False
    base = manager["name"].replace(" Team Lead", "").replace(" Lead", "")
    aid = create(f"{base} {category.title()} Agent", specialty=category, model="auto", parent_id=manager["id"],
                 status="probation", note=f"created by {manager['name']} for {category} work")
    _say(f"org", manager["name"], f"{base} {category.title()} Agent",
         f"I created you to handle {category} work for my team. You are on probation until you pass evaluation.")
    return aid, True


def peer_review(manager, text, draft, tid):
    """A verification specialist checks the team's answer before it goes back.
    If it finds problems, the manager revises once with the critique."""
    rid, _ = find_or_create_specialist(manager, "verification")
    reviewer = get(rid)
    if reviewer["id"] == manager["id"]:
        return draft, None
    model, _ = _resolve_model(reviewer, "verification", "medium")
    if model == "atlas-local":
        return draft, None
    _say(f"task-{tid}", manager["name"], reviewer["name"], "Please review the team's answer before I send it.")
    r = providers.complete(model, f"REQUEST:\n{text}\n\nDRAFT ANSWER:\n{draft[:6000]}\n\nCheck for factual errors, missing "
                           "parts of the request and calculation mistakes. First line: PASS or FAIL. Then list issues.",
                           system=reviewer["config"]["system"], agent_id=rid, task_id=tid, purpose="peer-review", max_tokens=500)
    verdict = "FAIL" if r["text"].strip().upper().startswith("FAIL") else "PASS"
    _say(f"task-{tid}", reviewer["name"], manager["name"], r["text"])
    db.emit("workforce", "peer_review", reviewer["name"], task_id=tid, verdict=verdict)
    if verdict == "FAIL":
        mm, _ = _resolve_model(manager, "writing", "medium")
        fix = providers.complete(mm, f"Request: {text}\n\nDraft:\n{draft[:6000]}\n\nReviewer feedback:\n{r['text']}\n\n"
                                 "Write the corrected final answer.", system=manager["config"]["system"],
                                 agent_id=manager["id"], task_id=tid, purpose="revision")
        return fix["text"], verdict
    return draft, verdict


def run_task(title, text, agent_id=None, important=False, difficulty="medium", parent_task=None, review=False):
    """Synchronous. Call through compute.submit for background execution."""
    ensure_seed()
    if agent_id is None:
        agent_id = db.one("SELECT id FROM agents WHERE role='director'")["id"]
    agent = get(agent_id)
    if agent["status"] == "paused":
        raise RuntimeError(f"{agent['name']} is paused")
    tid = db.insert("tasks", title=title, input=text, kind=classify(text), agent_id=agent_id,
                    parent_id=parent_task, status="running", created=time.time())
    thread = f"task-{tid}"
    db.emit("workforce", "task_started", agent["name"], task_id=tid, title=title, agent_id=agent_id, parent_task=parent_task)
    _say(thread, "You", agent["name"], text)

    subtasks = []
    if agent["config"].get("can_delegate") and agent["role"] != "director":
        try:
            planner, _ = _resolve_model(agent, "general", "medium")
            plan = providers.complete(planner, text, system="DECOMPOSE: split the request into 1-5 independent subtasks. "
                                      "Reply with ONLY a JSON array of strings.", agent_id=agent_id, task_id=tid,
                                      purpose="planning", max_tokens=400)
            m = re.search(r"\[.*\]", plan["text"], re.S)
            subtasks = [s for s in json.loads(m.group()) if isinstance(s, str)][:5] if m else []
        except Exception:
            subtasks = providers.split_task(text)[:5]
        if not subtasks:
            subtasks = [text]

    if subtasks or agent["role"] == "director":
        # pick a team: director hands the whole task to the best available manager
        if agent["role"] == "director":
            managers = db.query("SELECT * FROM agents WHERE parent_id=? AND role='manager' AND status='trusted'", (agent_id,))
            avail = [m for m in managers if m["model"] == "auto" or providers.model_info(m["model"])["available"]]
            mgr = max(avail or managers, key=lambda m: (m["stats"]["quality_sum"] / max(1, m["stats"]["graded"])))
            db.emit("workforce", "delegated", agent["name"], task_id=tid, to=mgr["name"], to_id=mgr["id"])
            _say(thread, agent["name"], mgr["name"], f"Please handle: {text}")
            child = run_task(title, text, mgr["id"], important, difficulty, parent_task=tid, review=review)
            out = child["output"]
            quality = child["quality"]
        else:
            # assign first (sequential: agent creation must not race), then execute in parallel
            plan = []
            for st in subtasks:
                cat = classify(st)
                sid, new = find_or_create_specialist(agent, cat)
                sub = get(sid)
                if important and sub["status"] != "trusted":
                    sid, sub = agent_id, agent  # untrusted agents never get important work
                    db.emit("workforce", "trust_gate", agent["name"], task_id=tid, reason="specialist on probation")
                st_id = db.insert("tasks", title=st[:80], input=st, kind=cat, agent_id=sid, parent_id=tid,
                                  status="running", created=time.time())
                db.emit("workforce", "delegated", agent["name"], task_id=st_id, parent_task=tid, to=sub["name"],
                        to_id=sid, category=cat)
                _say(thread, agent["name"], sub["name"], st)
                plan.append((st, sid, sub, st_id))

            def work(item):
                st, sid, sub, st_id = item
                res, cat, model = execute(sid, st, st_id, thread, difficulty)
                score, method = grade(st, res["text"], cat)
                ok = score is None or score >= 0.5
                db.update("tasks", st_id, status="done" if ok else "failed", output=res["text"], cost=res["cost"],
                          quality=score, finished=time.time())
                _record(sid, cat, score, ok)
                if score is not None and model != "atlas-local":
                    economy.record_result(model, cat, score)
                _say(thread, sub["name"], agent["name"], res["text"])
                db.emit("workforce", "task_done", sub["name"], task_id=st_id, parent_task=tid, quality=score,
                        method=method, cost=res["cost"], ok=ok)
                return (st, res["text"], score)

            with ThreadPoolExecutor(max_workers=min(4, len(plan))) as ex:
                results = list(ex.map(work, plan))
            out = _synthesise(agent, text, results, tid)
            if review:
                try:
                    out, verdict = peer_review(agent, text, out, tid)
                except Exception as e:
                    db.log("warn", "agents", f"peer review skipped: {e}")
            graded = [s for _, _, s in results if s is not None]
            quality = sum(graded) / len(graded) if graded else None
            maybe_evolve(agent)
    else:
        res, cat, model = execute(agent_id, text, tid, thread, difficulty)
        out = res["text"]
        quality, method = grade(text, out, cat)
        if quality is not None and model != "atlas-local":
            economy.record_result(model, cat, quality)
        _record(agent_id, cat, quality, quality is None or quality >= 0.5)

    cost = db.one("SELECT COALESCE(SUM(cost),0) c FROM ledger WHERE task_id IN "
                  "(SELECT id FROM tasks WHERE id=? OR parent_id=?)", (tid, tid))["c"]
    db.update("tasks", tid, status="done", output=out, cost=cost, quality=quality, finished=time.time())
    _say(thread, agent["name"], "You", out)
    db.emit("workforce", "task_done", agent["name"], task_id=tid, quality=quality, cost=cost, parent_task=parent_task, ok=True)
    return {"task_id": tid, "output": out, "quality": quality, "cost": cost}


def _synthesise(agent, text, results, tid):
    if len(results) == 1:
        return results[0][1]
    body = "\n\n".join(f"### {st}\n{out}" for st, out, _ in results)
    try:
        model, _ = _resolve_model(agent, "writing", "easy")
        if model != "atlas-local":
            r = providers.complete(model, f"Original request: {text}\n\nTeam results:\n{body}\n\nCombine these into one "
                                   "clear final answer.", system=agent["config"]["system"], agent_id=agent["id"],
                                   task_id=tid, purpose="synthesis")
            return r["text"]
    except Exception:
        pass
    return body


# ------------------------------------------------------------- evolution
def maybe_evolve(manager):
    """If a manager's team keeps receiving one category, and the specialist
    for it is proven, try a cheaper clone. Spawned clones start on
    probation and must pass the Arena before promotion."""
    for sub in db.query("SELECT * FROM agents WHERE parent_id=? AND status='trusted'", (manager["id"],)):
        bc = sub["stats"]["by_category"].get(sub["specialty"], {})
        if bc.get("n", 0) >= 5 and bc.get("graded", 0) >= 3 and bc["q"] / bc["graded"] >= 0.8:
            cheaper = economy.route(sub["specialty"], "easy")[0]
            exists = db.one("SELECT id FROM agents WHERE parent_id=? AND specialty=? AND model=?",
                            (manager["id"], sub["specialty"], cheaper))
            if not exists and cheaper != sub["model"]:
                create(f"{sub['name']} (economy)", specialty=sub["specialty"], model=cheaper, parent_id=manager["id"],
                       status="probation", system=sub["config"]["system"], tools=sub["config"]["tools"],
                       note=f"evolved from {sub['name']}: cheaper model, must pass evaluation")
                db.emit("workforce", "evolution", manager["name"], from_agent=sub["id"], model=cheaper,
                        reason="repetitive proven work; testing a cheaper specialist")


def evaluate(agent_id, n=6):
    """Probation exam using the Arena benchmark for the agent's specialty."""
    from . import arena
    a = get(agent_id)
    result = arena.run_agent_exam(agent_id, a["specialty"], n)
    bar = economy.DIFFICULTY_BAR["medium"]
    passed = result["score"] is not None and result["score"] >= bar
    new_status = "trusted" if passed else "probation"
    if a["status"] in ("trusted", "probation"):
        db.update("agents", agent_id, status=new_status)
    db.emit("workforce", "evaluation", a["name"], agent_id=agent_id, score=result["score"], passed=passed,
            status=new_status, method=result["method"])
    return {**result, "passed": passed, "status": new_status}


def org_tree():
    agents = all_agents()
    for a in agents:
        s = a["stats"]
        a["quality"] = s["quality_sum"] / s["graded"] if s["graded"] else None
        a["busy"] = bool(db.one("SELECT id FROM tasks WHERE agent_id=? AND status='running'", (a["id"],)))
    return agents
