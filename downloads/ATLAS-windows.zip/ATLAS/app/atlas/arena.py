"""Intelligence Arena: benchmarks with verifiable answers.

Every item has an automatic, objective grader (exact number, keyword
match, JSON validity, or running generated code against unit tests).
No vibes-based scoring. Results feed the Council's reputation weights
and the economy's routing.

Safety: the code benchmark executes model-written Python in a separate
process with a 5 second timeout, isolated mode and an empty temp
directory. It is still code from a model running on your machine, so
the code category is opt-in per run.
"""
import json
import random
import re
import subprocess
import sys
import tempfile
import time

from . import db, economy, providers

FACTS = [("What is the capital of Australia?", ["canberra"]), ("What is the chemical symbol for gold?", ["au"]),
         ("How many sides does a hexagon have?", ["6", "six"]), ("What planet is known as the Red Planet?", ["mars"]),
         ("Who wrote 'Romeo and Juliet'?", ["shakespeare"]), ("What is the largest ocean on Earth?", ["pacific"]),
         ("What gas do plants absorb from the air for photosynthesis?", ["carbon dioxide", "co2"]),
         ("In what year did World War II end?", ["1945"]), ("What is the square root of 144?", ["12"]),
         ("What is the capital of Canada?", ["ottawa"]), ("What is the freezing point of water in Fahrenheit?", ["32"]),
         ("What is the hardest natural substance?", ["diamond"]), ("What language has the most native speakers?", ["mandarin", "chinese"]),
         ("What is the smallest prime number?", ["2", "two"]), ("Which organ pumps blood through the body?", ["heart"])]

CLAIMS = [("The Great Wall of China is visible from the Moon with the naked eye.", False),
          ("Water boils at 100 degrees Celsius at sea level.", True), ("Bats are blind.", False),
          ("The Earth orbits the Sun once roughly every 365 days.", True), ("Humans only use 10% of their brains.", False),
          ("Light travels faster than sound.", True), ("Goldfish have a 3-second memory.", False),
          ("Mount Everest is the tallest mountain above sea level.", True), ("Lightning never strikes the same place twice.", False),
          ("Diamonds are made of carbon.", True)]

CODE = [("Write a Python function `is_palindrome(s)` that returns True if string s reads the same forwards and "
         "backwards, ignoring case.", "assert is_palindrome('Racecar')\nassert not is_palindrome('hello')\nassert is_palindrome('')"),
        ("Write a Python function `fizz(n)` returning 'Fizz' if n divisible by 3, 'Buzz' if by 5, 'FizzBuzz' if both, else str(n).",
         "assert fizz(3)=='Fizz'\nassert fizz(10)=='Buzz'\nassert fizz(15)=='FizzBuzz'\nassert fizz(7)=='7'"),
        ("Write a Python function `second_largest(xs)` returning the second largest distinct value in a list of ints.",
         "assert second_largest([1,5,3,5])==3\nassert second_largest([10,9])==9"),
        ("Write a Python function `word_count(s)` returning a dict of lowercase word -> count.",
         "assert word_count('A a b')=={'a':2,'b':1}"),
        ("Write a Python function `sma(prices, n)` returning a list of simple moving averages (length len(prices)-n+1).",
         "assert sma([1,2,3,4],2)==[1.5,2.5,3.5]\nassert sma([5,5,5],3)==[5]")]


def items(category, n, seed=0):
    rnd = random.Random(seed)
    if category == "math":
        out = []
        for _ in range(n):
            a, b, c = rnd.randint(12, 999), rnd.randint(2, 99), rnd.randint(2, 50)
            op = rnd.choice(["{a} * {b} + {c}", "({a} + {b}) * {c}", "{a} * {b} - {c} * {c}", "{a} / {c} + {b}"])
            expr = op.format(a=a, b=b, c=c)
            out.append({"q": f"What is {expr}? Reply with only the number.", "check": ("num", eval(expr))})
        return out
    if category == "finance":
        out = []
        for _ in range(n):
            p0, p1 = rnd.randint(20, 400), rnd.randint(20, 400)
            out.append({"q": f"A stock goes from ${p0} to ${p1}. What is the percentage return, rounded to 2 decimals? "
                             "Reply with only the number.", "check": ("num", round((p1 - p0) / p0 * 100, 2), 0.011)})
        return out
    if category in ("verification", "analysis"):
        pool = rnd.sample(CLAIMS, min(n, len(CLAIMS)))
        return [{"q": f"True or false: {c} Reply with only TRUE or FALSE.", "check": ("bool", v)} for c, v in pool]
    if category == "code":
        pool = rnd.sample(CODE, min(n, len(CODE)))
        return [{"q": q + " Reply with only the code in a ```python block.", "check": ("code", t)} for q, t in pool]
    if category == "writing":
        names = ["Ada", "Linus", "Grace", "Alan", "Katherine", "Margaret"]
        out = []
        for _ in range(n):
            nm, age = rnd.choice(names), rnd.randint(18, 90)
            out.append({"q": f"Return ONLY a JSON object with keys \"name\" and \"age\" for a person named {nm} aged {age}.",
                        "check": ("json", {"name": nm, "age": age})})
        return out
    pool = rnd.sample(FACTS, min(n, len(FACTS)))
    return [{"q": q + " Answer in a few words.", "check": ("kw", kws)} for q, kws in pool]


def check(item, out):
    kind = item["check"][0]
    text = out.strip()
    if kind == "num":
        exp = item["check"][1]
        tol = item["check"][2] if len(item["check"]) > 2 else 1e-6 * max(1, abs(exp))
        nums = re.findall(r"-?\d+\.?\d*", text.replace(",", ""))
        return 1.0 if nums and abs(float(nums[-1]) - exp) <= tol else 0.0
    if kind == "kw":
        return 1.0 if any(k in text.lower() for k in item["check"][1]) else 0.0
    if kind == "bool":
        t = text.lower()
        said = True if "true" in t and "false" not in t else False if "false" in t and "true" not in t else None
        return 1.0 if said == item["check"][1] else 0.0
    if kind == "json":
        m = re.search(r"\{.*\}", text, re.S)
        try:
            obj = json.loads(m.group()) if m else None
        except ValueError:
            obj = None
        return 1.0 if obj == item["check"][1] else 0.0
    if kind == "code":
        return run_code_test(text, item["check"][1])
    return 0.0


def run_code_test(text, tests):
    from . import control
    control.require("allow_code_execution")
    m = re.search(r"```(?:python)?\n(.*?)```", text, re.S)
    code = m.group(1) if m else text
    with tempfile.TemporaryDirectory() as d:
        try:
            r = subprocess.run([sys.executable, "-I", "-c", code + "\n" + tests], cwd=d, capture_output=True, timeout=5)
            return 1.0 if r.returncode == 0 else 0.0
        except subprocess.TimeoutExpired:
            return 0.0


CATS = ["general", "math", "finance", "verification", "writing", "code"]


def run_model(model, category, n=5, seed=None, progress=None):
    seed = seed if seed is not None else int(time.time())
    results = []
    for i, it in enumerate(items(category, n, seed)):
        t0 = time.time()
        try:
            r = providers.complete(model, it["q"], system="Answer precisely and briefly.", max_tokens=400,
                                   purpose=f"arena:{category}")
            score, cost, out = check(it, r["text"]), r["cost"], r["text"]
        except Exception as e:
            score, cost, out = 0.0, 0.0, f"ERROR {e}"
        results.append({"q": it["q"], "out": out[:500], "score": score, "latency": time.time() - t0, "cost": cost})
        if model != "atlas-local" or category in ("math",):
            economy.record_result(model, category, score)
        db.emit("arena", "item_scored", model, category=category, i=i, score=score)
        if progress:
            progress((i + 1) / n)
    summary = {"model": model, "category": category, "n": len(results), "seed": seed,
               "accuracy": sum(r["score"] for r in results) / max(1, len(results)),
               "avg_latency": sum(r["latency"] for r in results) / max(1, len(results)),
               "cost": sum(r["cost"] for r in results),
               "reliability": sum(1 for r in results if not r["out"].startswith("ERROR")) / max(1, len(results))}
    db.insert("experiments", name=f"arena {model} {category}", kind="arena", config={"model": model, "category": category, "n": n},
              seed=seed, status="done", results={"summary": summary, "items": results}, created=time.time(), finished=time.time())
    db.emit("arena", "run_done", model, **summary)
    return summary


def run_agent_exam(agent_id, category, n=6):
    from . import agents
    cat = category if category in CATS or category == "analysis" else "general"
    scores = []
    for it in items(cat, n, seed=int(time.time())):
        tid = db.insert("tasks", title="exam: " + it["q"][:60], input=it["q"], kind=cat, agent_id=agent_id,
                        status="running", created=time.time())
        res, _, _ = agents.execute(agent_id, it["q"], tid, f"exam-{agent_id}", "easy")
        s = check(it, res["text"])
        db.update("tasks", tid, status="done", output=res["text"], quality=s, cost=res["cost"], finished=time.time())
        scores.append(s)
    return {"score": sum(scores) / len(scores) if scores else None, "n": len(scores), "method": f"arena:{cat}"}


def leaderboard():
    rows = db.query("""SELECT json_extract(results,'$.summary.model') model, json_extract(results,'$.summary.category') category,
        AVG(json_extract(results,'$.summary.accuracy')) accuracy, AVG(json_extract(results,'$.summary.avg_latency')) latency,
        SUM(json_extract(results,'$.summary.cost')) cost, SUM(json_extract(results,'$.summary.n')) n
        FROM experiments WHERE kind='arena' GROUP BY model, category ORDER BY category, accuracy DESC""")
    return rows
