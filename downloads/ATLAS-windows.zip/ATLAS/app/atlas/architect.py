"""AI Architect: natural-language description -> working, tested, packaged AI.

Pipeline (each stage is logged as real events for the Creation Cockpit):
  understand -> research -> design -> build -> train -> test -> debug -> package -> deploy

What it can build today, end to end:
  * tabular classifier/regressor from a CSV you upload
  * text classifier from labelled examples you type (optionally expanded
    with model-generated examples, clearly marked synthetic)
  * market direction forecaster on the bundled real 2007-2016 data
    (it will honestly report when it fails to beat the baseline)
  * evolved trading strategy (Market Lab genetic search) - virtual only
  * 2D pattern classifiers (spiral, moons, circles, xor, sine)
  * LLM agent systems: a configured specialist agent in the Workforce,
    examined in the Arena before it is trusted

The Architect never claims success it did not measure: a system is
marked 'passed' only if it beats a naive baseline on held-out test data.
"""
import csv
import io
import json
import os
import re
import time
import zipfile

import numpy as np

from . import agents, db, economy, knowledge, market, neural, providers

SYS_DIR = os.path.join(db.DATA_DIR, "systems")
STAGES = ["understand", "research", "design", "build", "train", "test", "debug", "package", "deploy"]


class Build:
    def __init__(self, sid, progress):
        self.sid, self.progress, self.log = sid, progress, []

    def stage(self, name, msg, **data):
        i = STAGES.index(name)
        self.log.append({"stage": name, "msg": msg, "ts": time.time(), **data})
        db.emit("architect", "stage", "architect", system_id=self.sid, stage=name, msg=msg, **data)
        self.progress((i + 0.5) / len(STAGES))
        db.update("systems", self.sid, status=name, metrics={"log": self.log[-60:]})


def _llm():
    try:
        m, _ = economy.route("analysis", "medium", exclude_local=True)
        return None if m == "atlas-local" else m
    except RuntimeError:
        return None


# ---------------------------------------------------------------- understanding
def detect(desc, csv_text=None):
    d = desc.lower()
    if csv_text:
        return "tabular"
    if len(re.findall(r"^.+(?:->|=>|\t)\s*\S+\s*$", desc, re.M)) >= 4:
        return "text"
    if any(w in d for w in ("spiral", "moons", "circles", "xor", "sine wave")):
        return "toy"
    assets = [a.lower() for a in market.load_history()]
    if re.search(r"\b(trading strateg|trading bot|strategy that trades|evolve)", d):
        return "strategy"
    if any(a in d.split() or a in d for a in assets + ["s&p", "sp500", "stock"]) and re.search(r"predict|forecast|up or down|direction|tomorrow", d):
        return "forecast"
    if re.search(r"\b(chat|assistant|answer questions|agent|summari|tutor|write|explain|support bot)", d):
        return "agent"
    return None


def parse_examples(desc):
    ex = []
    for line in desc.splitlines():
        m = re.match(r"^\s*['\"]?(.+?)['\"]?\s*(?:->|=>|\t)\s*([\w\- ]+?)\s*$", line)
        if m:
            ex.append((m.group(1).strip(), m.group(2).strip().lower()))
    return ex


# ---------------------------------------------------------------- feature builders
def text_vectorizer(texts, max_vocab=800):
    from collections import Counter
    c = Counter(w for t in texts for w in set(knowledge.tokens(t)))
    vocab = [w for w, n in c.most_common(max_vocab)]
    return vocab


def text_features(texts, vocab):
    idx = {w: i for i, w in enumerate(vocab)}
    X = np.zeros((len(texts), len(vocab) + 2))
    for r, t in enumerate(texts):
        toks = knowledge.tokens(t)
        for w in toks:
            if w in idx:
                X[r, idx[w]] = 1
        X[r, -2] = min(len(t), 400) / 100
        X[r, -1] = sum(ch.isupper() for ch in t) / max(1, len(t))
    return X


def parse_csv(text, target=None):
    rows = list(csv.DictReader(io.StringIO(text.strip())))
    if len(rows) < 20:
        raise ValueError("need at least 20 rows of data")
    cols = list(rows[0].keys())
    target = target if target in cols else cols[-1]
    feats = [c for c in cols if c != target]
    Xcols, schema = [], []
    for c in feats:
        vals = [r[c] for r in rows]
        try:
            Xcols.append(np.array([float(v) for v in vals]))
            schema.append({"col": c, "type": "num"})
        except ValueError:
            cats = sorted(set(vals))[:30]
            if len(cats) > 25 and len(set(vals)) > len(rows) * 0.5:
                continue  # id-like text column, skip
            for k in cats:
                Xcols.append(np.array([1.0 if v == k else 0.0 for v in vals]))
            schema.append({"col": c, "type": "cat", "values": cats})
    yraw = [r[target] for r in rows]
    try:
        yn = np.array([float(v) for v in yraw])
        task = "classification" if len(set(yn)) <= 10 and np.allclose(yn, yn.round()) else "regression"
    except ValueError:
        task, yn = "classification", None
    if task == "classification":
        labels = sorted(set(yraw))
        y = np.array([labels.index(v) for v in yraw])
    else:
        labels, y = None, yn
    return np.column_stack(Xcols), y, task, {"target": target, "features": schema, "labels": labels}


def forecast_data(asset, horizon=1):
    prices, dates = market.load_history()[asset]
    F = market.features(prices)
    fut = np.r_[prices[horizon:] / prices[:-horizon] - 1, [np.nan] * horizon]
    ok = ~np.isnan(fut)
    ok[:60] = False
    X, y = F[ok], (fut[ok] > 0).astype(int)
    return X, y, {"asset": asset, "features": market.FEATURES, "labels": ["down", "up"],
                  "period": f"{dates[60]} to {dates[-1 - horizon]}"}


def baseline(y_train, y_test, task):
    if task == "classification":
        maj = np.bincount(y_train).argmax()
        return float((y_test == maj).mean()), "majority-class guess"
    return 0.0, "predict-the-mean (R2 = 0)"


# ---------------------------------------------------------------- main pipeline
def find_dataset(desc):
    """Investigate the Knowledge Universe for a CSV that matches the request.
    Returns (csv_text, target, title) or None."""
    for hit in knowledge.search(desc, k=5):
        if not hit["doc_id"]:
            continue
        doc = db.one("SELECT title, content FROM docs WHERE id=?", (hit["doc_id"],))
        lines = [l for l in doc["content"].strip().splitlines() if l.strip()]
        if len(lines) < 21 or lines[0].count(",") < 1:
            continue
        cols = [c.strip() for c in lines[0].split(",")]
        if len({len(l.split(",")) for l in lines[:50]}) != 1:
            continue
        d = desc.lower()
        target = next((c for c in cols if re.search(r"\b" + re.escape(c.lower()) + r"\b", d) and
                       re.search(r"(predict|classify|estimate|forecast)\w*\s+(?:\w+\s+){0,3}" + re.escape(c.lower()), d)), None)
        target = target or next((c for c in cols if c.lower() in d), None)
        return doc["content"], target, doc["title"]
    return None


def build(desc, name=None, csv_text=None, target=None, allow_synthetic=True, progress=lambda p, **k: None):
    name = name or (re.sub(r"[^a-zA-Z0-9 ]", "", desc)[:40].strip() or "system")
    sid = db.insert("systems", name=name, description=desc, approach=None, status="understand", version=1,
                    created=time.time(), metrics={})
    B = Build(sid, progress)
    llm = _llm()
    if not csv_text and re.search(r"\b(predict|classify|estimate)\b", desc.lower()) and not detect(desc):
        found = find_dataset(desc)
        if found:
            csv_text, t, title = found
            target = target or t
            B.stage("research", f"No data attached, so I searched the Knowledge Universe and found a matching dataset: '{title}'"
                        f" (target column: {target or 'last column'}).")
    kind = detect(desc, csv_text)
    B.stage("understand", f"Interpreted the request as: {kind or 'unclear'}", kind=kind, model=llm)
    if kind is None and llm:
        r = providers.complete(llm, f"Classify this AI system request into exactly one of: tabular, text, forecast, "
                               f"strategy, toy, agent. Request: {desc}\nReply with one word.", purpose="architect:understand",
                               max_tokens=5)
        guess = r["text"].strip().lower().strip(".")
        kind = guess if guess in ("tabular", "text", "forecast", "strategy", "toy", "agent") else None
        B.stage("understand", f"{llm} classified the request as: {kind}", kind=kind)
    if kind is None:
        kind = "agent"
        B.stage("understand", "Could not match a data-driven type; defaulting to an LLM agent system, which needs a configured model.")

    # research: what does ATLAS already know?
    hits = knowledge.search(desc, k=3)
    prior = db.query("SELECT name, approach, metrics FROM systems WHERE approach IS NOT NULL AND id!=? ORDER BY id DESC LIMIT 20", (sid,))
    similar = [p["name"] for p in prior if p["approach"] and p["approach"].startswith(kind)]
    notes = f"Knowledge hits: {[h['title'] for h in hits] or 'none'}. Similar past systems: {similar[:3] or 'none'}."
    if llm:
        try:
            r = providers.complete(llm, f"I am designing an AI system for: {desc}\nType: {kind}. In 4 short bullets, give the "
                                   "key design risks and the most suitable technique.", purpose="architect:research",
                                   max_tokens=300)
            notes += "\n" + r["text"]
        except Exception as e:
            notes += f"\n(research model call failed: {e})"
    B.stage("research", notes)

    try:
        handler = {"tabular": _tabular, "text": _text, "forecast": _forecast, "toy": _toy,
                   "strategy": _strategy, "agent": _agent}[kind]
        out = handler(B, desc, csv_text=csv_text, target=target, llm=llm, allow_synthetic=allow_synthetic)
    except Exception as e:
        B.stage("debug", f"Build failed: {e}", error=str(e))
        db.update("systems", sid, status="failed", approach=kind, metrics={"log": B.log, "error": str(e)})
        return {"system_id": sid, "status": "failed", "error": str(e)}

    path = package(sid, name, desc, out)
    B.stage("package", f"Packaged to {os.path.relpath(path, db.DATA_DIR)} (model, standalone predict script, README, metrics)")
    status = "deployed" if out["passed"] else "failed-test"
    B.stage("deploy", "Deployed: callable from ATLAS and from the packaged predict.py" if out["passed"] else
            "Not deployed: it did not beat the baseline on unseen data. Kept for inspection.")
    db.update("systems", sid, status=status, approach=out["approach"], package=out["package"],
              metrics={"log": B.log, **out["metrics"]})
    if out["package"]["type"] == "mlp":
        knowledge.remember("parameter", f"system {sid}: {name}", f"Trained {out['metrics'].get('params')} parameters "
                           f"({out['approach']}); test {out['metrics'].get('test')}", "architect")
    progress(1.0)
    return {"system_id": sid, "status": status, **out["metrics"]}


def _search(B, X, y, task, candidates, seed=0):
    """Small architecture search with a debug loop. Real experiments."""
    best = None
    tried = []
    for cfg in candidates:
        cfg = {"epochs": 150, "lr": 0.01, "batch": 32, "l2": 1e-3, "seed": seed, **cfg}
        r = neural.train(cfg, X=X, y=y, task=task,
                         progress=lambda p, **row: B.progress((STAGES.index("train") + p) / len(STAGES)))
        diverged = any(h.get("diverged") for h in r["history"])
        if diverged:
            B.stage("debug", f"{cfg['hidden']} diverged at lr={cfg['lr']}; retrying with lr={cfg['lr']/10}")
            cfg["lr"] /= 10
            r = neural.train(cfg, X=X, y=y, task=task)
        v = r["metrics"]["val"]
        tried.append({"hidden": cfg["hidden"], "activation": cfg.get("activation", "relu"), "val": v, "params": r["params"]})
        B.stage("train", f"Trained {cfg['hidden']} {cfg.get('activation','relu')}: val {r['metrics']['metric_name']} {v:.3f}",
                history=r["history"][-20:], val=v)
        if best is None or v > best[1]["metrics"]["val"]:
            best = (cfg, r)
    return best, tried


def _evaluate(B, r, X, y, task, seed=0, cfg=None):
    """Held-out test vs a naive baseline. Small datasets (<150 rows) use
    5 different random splits and average them, because one tiny test
    set is too noisy to trust."""
    margin = 0.02 if task == "classification" else 0.05
    if len(X) < 150 and cfg is not None:
        tests, bases = [], []
        for s in range(8):
            rr = neural.train({**cfg, "seed": s, "val_frac": 0.15, "test_frac": 0.3}, X=X, y=y, task=task)
            (_, ytr), _, (_, yte) = neural.split(X, y, s, 0.15, 0.3)
            tests.append(rr["metrics"]["test"])
            bases.append(baseline(ytr, yte, task)[0])
        test, base, how = float(np.mean(tests)), float(np.mean(bases)), "majority/mean baseline, 8 resampled 30% test splits"
        r["metrics"]["test"] = test
        r["metrics"]["test_splits"] = tests
    else:
        (_, ytr), _, (_, yte) = neural.split(X, y, seed)
        base, how = baseline(ytr, yte, task)
        test = r["metrics"]["test"]
    passed = test is not None and test > base + margin
    B.stage("test", f"Held-out test {r['metrics']['metric_name']}: {test:.3f} vs baseline ({how}) {base:.3f} -> "
            f"{'PASS' if passed else 'FAIL'}", test=test, baseline=base, passed=passed)
    return passed, base


def _nn_system(B, X, y, task, schema, approach, extra=None):
    n = len(X)
    cands = [{"hidden": [16]}, {"hidden": [32, 16]}, {"hidden": [64, 32], "dropout": 0.1}]
    if n > 2000:
        cands = [{"hidden": [32]}, {"hidden": [64, 32], "dropout": 0.1}, {"hidden": [32], "l2": 1e-2}]
    B.stage("design", f"{n} samples, {X.shape[1]} features, {task}. Searching {len(cands)} MLP architectures "
            "(He init, Adam, L2, early-stop by validation).", candidates=cands)
    B.stage("build", "Built normalised feature matrix and seeded train/val/test split (70/20/10).")
    (cfg, r), tried = _search(B, X, y, task, cands)
    passed, base = _evaluate(B, r, X, y, task, cfg=cfg)
    if not passed:
        B.stage("debug", "Below baseline. Trying a simpler, more regularised model (overfitting is the usual cause).")
        (cfg2, r2), t2 = _search(B, X, y, task, [{"hidden": [8], "l2": 1e-2, "epochs": 80}])
        tried += t2
        if r2["metrics"]["val"] >= r["metrics"]["val"]:
            cfg, r = cfg2, r2
            passed, base = _evaluate(B, r, X, y, task, cfg=cfg)
    return {"approach": approach, "passed": passed,
            "package": {"type": "mlp", "model": r["model"], "schema": schema, "config": cfg, **(extra or {})},
            "metrics": {**r["metrics"], "baseline": base, "passed": passed, "params": r["params"], "tried": tried,
                        "history": r["history"]}}


def _tabular(B, desc, csv_text, target, **_):
    X, y, task, schema = parse_csv(csv_text, target)
    return _nn_system(B, X, y, task, schema, f"tabular-{task}")


def _toy(B, desc, **_):
    ds = next(w for w in ("spiral", "moons", "circles", "xor", "sine") if w in desc.lower())
    X, y, task = neural.dataset(ds, 800, 0.2, 0)
    return _nn_system(B, X, y, task, {"features": ["x1", "x2"] if X.shape[1] == 2 else ["x"], "dataset": ds}, f"toy-{ds}")


def _text(B, desc, llm=None, allow_synthetic=True, **_):
    ex = parse_examples(desc)
    labels = sorted(set(l for _, l in ex))
    B.stage("build", f"Found {len(ex)} labelled examples across labels {labels}.")
    synthetic = 0
    if len(ex) < 40 and llm and allow_synthetic:
        try:
            r = providers.complete(llm, "Generate 30 additional diverse, realistic training examples for this text "
                                   f"classifier. Labels: {labels}. Existing examples:\n" + "\n".join(f"{t} -> {l}" for t, l in ex[:20]) +
                                   "\nReply ONLY with a JSON array of [text, label] pairs.", purpose="architect:data",
                                   max_tokens=2000)
            m = re.search(r"\[.*\]", r["text"], re.S)
            gen = [(t, l.lower()) for t, l in json.loads(m.group()) if l.lower() in labels] if m else []
            ex += gen
            synthetic = len(gen)
            B.stage("build", f"{llm} generated {synthetic} synthetic examples (marked synthetic; test set uses only your examples where possible).")
        except Exception as e:
            B.stage("debug", f"Synthetic data generation failed ({e}); continuing with your examples only.")
    if len(ex) < 12:
        raise ValueError("need at least 12 labelled examples (format: text -> label, one per line)")
    texts = [t for t, _ in ex]
    vocab = text_vectorizer(texts)
    X = text_features(texts, vocab)
    y = np.array([labels.index(l) for _, l in ex])
    out = _nn_system(B, X, y, "classification", {"labels": labels}, "text-classifier",
                     extra={"vocab": vocab, "labels": labels})
    out["metrics"]["synthetic_examples"] = synthetic
    return out


def _forecast(B, desc, **_):
    hist = market.load_history()
    asset = next((a for a in hist if a.lower() in desc.lower()), "GSPC")
    X, y, schema = forecast_data(asset)
    B.stage("build", f"Built {len(X)} causal samples from real {asset} prices ({schema['period']}): today's indicators -> "
            "tomorrow up/down. Note: random split mixes eras; walk-forward test also run below.")
    out = _nn_system(B, X, y, "classification", schema, "forecast-direction")
    # walk-forward: train on first 70% in time, test on last 30%
    cut = int(len(X) * 0.7)
    m = neural.MLP.from_json(out["package"]["model"])
    wf = float((m.predict(X[cut:]) == y[cut:]).mean())
    base = float(max(y[cut:].mean(), 1 - y[cut:].mean()))
    B.stage("test", f"Walk-forward accuracy on the final 30% (in time) {wf:.3f} vs always-guess-majority {base:.3f}. "
            "Daily direction is close to a coin flip; treat any small edge as noise unless it holds across assets.",
            walk_forward=wf, wf_baseline=base)
    out["metrics"]["walk_forward"] = wf
    out["metrics"]["walk_forward_baseline"] = base
    if wf <= base + 0.01:
        out["passed"] = out["metrics"]["passed"] = False
    return out


def _strategy(B, desc, **_):
    hist = market.load_history()
    asset = next((a for a in hist if a.lower() in desc.lower()), "GSPC")
    B.stage("design", f"Evolve a population of 300 rule-based strategies on real {asset} history with costs, "
            "then pick the champion by out-of-sample performance.")
    lab = market.Lab()
    lab.reset({"population": 300, "mode": "historical", "asset": asset, "generations": 25, "delay": 0})
    for g in range(25):
        s = lab.step()
        B.progress((STAGES.index("train") + g / 25) / len(STAGES))
        if g % 5 == 0:
            B.stage("train", f"Gen {g}: best return {s['best_return']:.1%}, out-of-sample {s['oos_return']:.1%}, "
                    f"buy&hold {s['buy_hold']:.1%}")
    oos = [h["oos_return"] for h in lab.history[-10:]]
    bh = [h["buy_hold"] for h in lab.history[-10:]]
    champ = lab.bot(lab.history[-1]["champion"])
    passed = float(np.mean(oos)) > float(np.mean(bh))
    B.stage("test", f"Champion out-of-sample mean return {np.mean(oos):.1%} vs buy&hold {np.mean(bh):.1%} -> "
            f"{'PASS' if passed else 'FAIL (does not beat simply holding)'}", passed=passed)
    return {"approach": "strategy-evolved", "passed": passed, "package": {"type": "strategy", "dna": champ.get("dna"),
            "asset": asset, "features": market.FEATURES},
            "metrics": {"oos_mean": float(np.mean(oos)), "buy_hold_mean": float(np.mean(bh)), "passed": passed}}


def _agent(B, desc, llm=None, **_):
    cat = agents.classify(desc)
    B.stage("design", f"LLM agent system. Specialty: {cat}. Tools: knowledge base, calculator, memory.")
    if not llm:
        raise ValueError("an LLM agent needs a configured model (add an API key or start Ollama in Settings)")
    r = providers.complete(llm, f"Write a concise system prompt (max 120 words) for an AI agent that does: {desc}",
                           purpose="architect:design", max_tokens=300)
    lead = db.one("SELECT id FROM agents WHERE role='manager' ORDER BY id LIMIT 1")
    aid = agents.create(re.sub(r"[^\w ]", "", desc)[:30].strip().title() + " Agent", specialty=cat, model="auto",
                        parent_id=lead["id"] if lead else None, system=r["text"].strip(),
                        tools=["knowledge", "calculator", "remember"], note="built by AI Architect")
    B.stage("build", f"Created agent #{aid} on probation.")
    ev = agents.evaluate(aid)
    B.stage("test", f"Arena exam ({ev['method']}): {ev['score']:.2f} -> {'trusted' if ev['passed'] else 'still on probation'}",
            passed=ev["passed"])
    return {"approach": f"agent-{cat}", "passed": ev["passed"], "package": {"type": "agent", "agent_id": aid,
            "system_prompt": r["text"].strip()}, "metrics": {"exam": ev["score"], "passed": ev["passed"]}}


# ---------------------------------------------------------------- packaging & inference
PREDICT_PY = '''"""Standalone inference for an ATLAS-built model. Needs only numpy.
Usage:  python predict.py '{"feature": value, ...}'   or   python predict.py "some text"
"""
import json, re, sys
import numpy as np
P = json.load(open(__file__.replace("predict.py", "model.json")))
M = P["model"]
ACT = {"relu": lambda z: np.maximum(0, z), "tanh": np.tanh, "sigmoid": lambda z: 1/(1+np.exp(-z)),
       "gelu": lambda z: 0.5*z*(1+np.tanh(0.79788456*(z+0.044715*z**3))), "linear": lambda z: z}
def forward(x):
    x = (np.asarray(x, float) - np.array(M["norm"]["mean"])) / np.array(M["norm"]["std"])
    for i, (W, b) in enumerate(zip(M["W"], M["b"])):
        x = x @ np.array(W) + np.array(b)
        if i < len(M["W"]) - 1: x = ACT[M["act"]](x)
    return x
def featurize(inp):
    if "vocab" in P:
        toks = set(w for w in re.findall(r"[a-z0-9]+", inp.lower()))
        v = [1.0 if w in toks else 0.0 for w in P["vocab"]]
        return v + [min(len(inp), 400)/100, sum(c.isupper() for c in inp)/max(1, len(inp))]
    row = json.loads(inp) if isinstance(inp, str) else inp
    x = []
    for f in P["schema"]["features"]:
        if isinstance(f, str): x.append(float(row[f])); continue
        if f["type"] == "num": x.append(float(row[f["col"]]))
        else: x += [1.0 if str(row[f["col"]]) == k else 0.0 for k in f["values"]]
    return x
def predict(inp):
    out = forward(featurize(inp))
    if M["task"] == "classification":
        labels = P.get("labels") or P["schema"].get("labels") or list(range(len(out)))
        e = np.exp(out - out.max()); p = e / e.sum()
        return {"label": labels[int(p.argmax())], "confidence": float(p.max())}
    return {"value": float(out[0])}
if __name__ == "__main__":
    print(json.dumps(predict(sys.argv[1])))
'''


def package(sid, name, desc, out):
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40] or "system"
    d = os.path.join(SYS_DIR, f"{sid}-{slug}")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "model.json"), "w") as f:
        json.dump(out["package"], f)
    with open(os.path.join(d, "metrics.json"), "w") as f:
        json.dump(out["metrics"], f, indent=1, default=float)
    if out["package"]["type"] == "mlp":
        with open(os.path.join(d, "predict.py"), "w") as f:
            f.write(PREDICT_PY)
    m = out["metrics"]
    with open(os.path.join(d, "README.md"), "w") as f:
        f.write(f"# {name}\n\nBuilt by the ATLAS AI Architect.\n\n**Request:** {desc}\n\n**Approach:** {out['approach']}\n\n"
                f"**Passed held-out test:** {out['passed']}\n\n```\n{json.dumps({k: v for k, v in m.items() if k not in ('history',)}, indent=1, default=float)[:3000]}\n```\n")
    return d


def predict(sid, inp):
    s = db.one("SELECT * FROM systems WHERE id=?", (sid,))
    if not s or not s["package"]:
        raise ValueError("system not built")
    P = s["package"]
    if P["type"] == "agent":
        return agents.run_task("query " + s["name"], inp if isinstance(inp, str) else json.dumps(inp), P["agent_id"])
    if P["type"] == "strategy":
        prices = market.load_history()[P["asset"]][0]
        F = market.features(prices)
        d = P["dna"]
        w = np.array([d[f] for f in market.FEATURES])
        sig = float(np.tanh(F[-1] @ w * 0.5 + d["bias"]))
        return {"signal": sig, "action": "long" if sig > d["enter"] else "short" if sig < -d["enter"] and d["can_short"] else "flat",
                "as_of": market.load_history()[P["asset"]][1][-1], "note": "research signal on bundled data, virtual only"}
    # direct in-process inference (same math as predict.py)
    model = neural.MLP.from_json(P["model"])
    if "vocab" in P:
        X = text_features([inp], P["vocab"])
        labels = P["labels"]
    elif P["schema"].get("dataset") or isinstance(P["schema"]["features"][0], str):
        X = np.array([inp if isinstance(inp, list) else [inp[f] for f in P["schema"]["features"]]], float)
        labels = P["schema"].get("labels")
    else:
        row = inp if isinstance(inp, dict) else json.loads(inp)
        x = []
        for f in P["schema"]["features"]:
            x += [float(row[f["col"]])] if f["type"] == "num" else [1.0 if str(row[f["col"]]) == k else 0.0 for k in f["values"]]
        X = np.array([x])
        labels = P["schema"].get("labels")
    norm = model.norm
    Xn = (X - np.array(norm["mean"])) / np.array(norm["std"])
    out, _ = model.forward(Xn)
    if model.task == "classification":
        k = int(out[0].argmax())
        return {"label": labels[k] if labels else k, "confidence": float(out[0].max())}
    return {"value": float(out[0, 0])}


def zip_system(sid):
    s = db.one("SELECT name FROM systems WHERE id=?", (sid,))
    slug = re.sub(r"[^a-z0-9]+", "-", s["name"].lower()).strip("-")[:40] or "system"
    d = os.path.join(SYS_DIR, f"{sid}-{slug}")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for fn in os.listdir(d):
            z.write(os.path.join(d, fn), fn)
    return buf.getvalue(), f"{slug}.zip"
