"""Model providers.

Each provider is a small adapter with one method: complete(). Adding a
new provider (Mistral, Groq, a local llama.cpp server...) means adding
one class here and one entry to MODELS. Nothing else changes.

Prices are USD per million tokens. They are ESTIMATES you can edit in
Settings, because vendors change prices. ATLAS records the token counts
the vendor actually returns, so cost tracking is only as accurate as the
price table.
"""
import http.client
import json
import math
import re
import time
import urllib.error
import urllib.request

from . import db, secrets

# tier: 1 = cheap/fast, 2 = balanced, 3 = strongest. Routing uses this.
MODELS = [
    {"id": "atlas-local", "provider": "local", "name": "ATLAS Local Engine", "tier": 0, "in": 0, "out": 0,
     "note": "Built-in deterministic engine (math, retrieval, extraction). Not an LLM. Free, always available."},
    {"id": "ollama:llama3.2", "provider": "ollama", "name": "Llama 3.2 (local)", "tier": 1, "in": 0, "out": 0},
    {"id": "ollama:qwen2.5", "provider": "ollama", "name": "Qwen 2.5 (local)", "tier": 1, "in": 0, "out": 0},
    {"id": "claude-haiku-5-5", "provider": "anthropic", "name": "Claude Haiku", "tier": 1, "in": 1.0, "out": 5.0},
    {"id": "claude-sonnet-5-5", "provider": "anthropic", "name": "Claude Sonnet", "tier": 2, "in": 3.0, "out": 15.0},
    {"id": "claude-opus-5-5", "provider": "anthropic", "name": "Claude Opus", "tier": 3, "in": 5.0, "out": 25.0},
    {"id": "gpt-5-mini", "provider": "openai", "name": "GPT mini", "tier": 1, "in": 0.25, "out": 2.0},
    {"id": "gpt-5", "provider": "openai", "name": "GPT", "tier": 3, "in": 1.25, "out": 10.0},
    {"id": "gemini-2.5-flash", "provider": "gemini", "name": "Gemini Flash", "tier": 1, "in": 0.3, "out": 2.5},
    {"id": "gemini-2.5-pro", "provider": "gemini", "name": "Gemini Pro", "tier": 3, "in": 1.25, "out": 10.0},
]


class ProviderError(Exception):
    pass


def _post(url, payload, headers, timeout=120):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST",
                                 headers={"content-type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise ProviderError(f"HTTP {e.code}: {e.read()[:300].decode(errors='replace')}")
    except (urllib.error.URLError, TimeoutError) as e:
        raise ProviderError(f"unreachable: {e}")
    except (OSError, http.client.HTTPException, ValueError) as e:  # dropped connection, bad JSON, etc.
        raise ProviderError(f"provider connection failed: {type(e).__name__}: {e}")


def _est_tokens(text):
    return max(1, math.ceil(len(text) / 4))


# ------------------------------------------------------------ adapters
class Anthropic:
    def available(self):
        return bool(secrets.get("ANTHROPIC_API_KEY"))

    def complete(self, model, system, messages, max_tokens):
        r = _post("https://api.anthropic.com/v1/messages",
                  {"model": model, "max_tokens": max_tokens, "system": system, "messages": messages},
                  {"x-api-key": secrets.get("ANTHROPIC_API_KEY"), "anthropic-version": "2023-06-01"})
        text = "".join(b.get("text", "") for b in r.get("content", []))
        u = r.get("usage", {})
        return text, u.get("input_tokens", 0), u.get("output_tokens", 0)


class OpenAI:
    def available(self):
        return bool(secrets.get("OPENAI_API_KEY"))

    def complete(self, model, system, messages, max_tokens):
        r = _post("https://api.openai.com/v1/chat/completions",
                  {"model": model, "max_completion_tokens": max_tokens,
                   "messages": [{"role": "system", "content": system}] + messages},
                  {"authorization": "Bearer " + secrets.get("OPENAI_API_KEY")})
        u = r.get("usage", {})
        return r["choices"][0]["message"]["content"], u.get("prompt_tokens", 0), u.get("completion_tokens", 0)


class Gemini:
    def available(self):
        return bool(secrets.get("GEMINI_API_KEY"))

    def complete(self, model, system, messages, max_tokens):
        contents = [{"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                    for m in messages]
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        r = _post(url, {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                        "generationConfig": {"maxOutputTokens": max_tokens}},
                  {"x-goog-api-key": secrets.get("GEMINI_API_KEY")})
        parts = r["candidates"][0]["content"].get("parts", [])
        u = r.get("usageMetadata", {})
        return "".join(p.get("text", "") for p in parts), u.get("promptTokenCount", 0), u.get("candidatesTokenCount", 0)


class Ollama:
    _ok = None
    _checked = 0

    def host(self):
        return secrets.get("OLLAMA_HOST") or "http://localhost:11434"

    def available(self):
        if time.time() - self._checked > 30:
            Ollama._checked = time.time()
            try:
                urllib.request.urlopen(self.host() + "/api/tags", timeout=1.5)
                Ollama._ok = True
            except Exception:
                Ollama._ok = False
        return Ollama._ok

    def complete(self, model, system, messages, max_tokens):
        r = _post(self.host() + "/api/chat",
                  {"model": model.split(":", 1)[1], "stream": False, "options": {"num_predict": max_tokens},
                   "messages": [{"role": "system", "content": system}] + messages}, {}, timeout=300)
        return r["message"]["content"], r.get("prompt_eval_count", 0), r.get("eval_count", 0)


class Local:
    """Deterministic engine. Honest about what it can do:
    - evaluates arithmetic safely
    - answers from the Knowledge Universe by retrieval
    - splits multi-part requests into subtasks (used for delegation)
    - extracts key sentences (summaries)
    Anything else returns a clear 'cannot do this' message.
    """

    def available(self):
        return True

    def complete(self, model, system, messages, max_tokens):
        prompt = messages[-1]["content"]
        text = self.answer(prompt, system)
        return text, _est_tokens(system + prompt), _est_tokens(text)

    ARITH = re.compile(r"^[\d\s\.\+\-\*/\(\)%]+$")

    def answer(self, prompt, system=""):
        p = prompt.strip()
        if "DECOMPOSE" in system:
            return json.dumps(split_task(p))
        cands = re.findall(r"[\d\(][\d\s\.\+\-\*/\(\)%x×\^]*[\d\)]", p)
        expr = max(cands, key=len) if cands else ""
        expr = expr.replace("x", "*").replace("×", "*").replace("^", "**").strip()
        if re.search(r"[\+\-\*/%]", expr) and len(expr) < 200 and expr.count("**") <= 1:
            if "**" in expr and float(re.findall(r"\*\*\s*([\d\.]+)", expr)[0] or 0) > 300:
                return "Exponent too large for the local engine."
            try:
                val = eval(compile(expr, "<arith>", "eval"), {"__builtins__": {}}, {})
                return str(round(val, 10)).rstrip("0").rstrip(".") if isinstance(val, float) else str(val)
            except Exception:
                pass
        if re.match(r"(?i)^(summari[sz]e|tl;?dr)", p):
            return extractive_summary(re.sub(r"(?i)^(summari[sz]e|tl;?dr)[:\s]*", "", p))
        from . import knowledge
        hits = knowledge.search(p, k=2)
        if hits and hits[0]["score"] > 0.12:
            return f"From knowledge base ('{hits[0]['title']}'): {hits[0]['snippet']}"
        return ("[ATLAS Local Engine] I can only do math, summaries, task splitting and knowledge-base lookup. "
                "Connect a real model (Ollama is free) for open-ended reasoning.")


def split_task(text):
    parts = re.split(r"(?:;|\n|\.\s+|\band then\b|\bthen\b|,\s*and\b|\band\b(?=\s+(?:write|build|test|research|find|create|analy[sz]e|design|check|verify|summari[sz]e)))", text)
    parts = [p.strip(" .,") for p in parts if p and len(p.strip()) > 3]
    return parts or [text]


def extractive_summary(text, n=3):
    sents = re.split(r"(?<=[.!?])\s+", text.strip())
    if len(sents) <= n:
        return text.strip()
    words = re.findall(r"[a-z]{4,}", text.lower())
    freq = {}
    for w in words:
        freq[w] = freq.get(w, 0) + 1
    scored = sorted(range(len(sents)), key=lambda i: -sum(freq.get(w, 0) for w in re.findall(r"[a-z]{4,}", sents[i].lower())) / (1 + len(sents[i]) ** 0.5))
    return " ".join(sents[i] for i in sorted(scored[:n]))


ADAPTERS = {"anthropic": Anthropic(), "openai": OpenAI(), "gemini": Gemini(), "ollama": Ollama(), "local": Local()}


def price_table():
    overrides = db.setting("prices", {})
    out = []
    for m in MODELS:
        m = dict(m)
        if m["id"] in overrides:
            m["in"], m["out"] = overrides[m["id"]]
        m["available"] = ADAPTERS[m["provider"]].available()
        out.append(m)
    return out


def model_info(model_id):
    for m in price_table():
        if m["id"] == model_id:
            return m
    raise ProviderError(f"unknown model {model_id}")


def available_models():
    return [m for m in price_table() if m["available"]]


def complete(model_id, prompt, system="You are a helpful, precise assistant.", history=None,
             max_tokens=800, agent_id=None, task_id=None, purpose="chat"):
    """Single entry point for every model call in ATLAS. Enforces the
    spending limit, records the cost in the ledger, and emits an event."""
    from . import economy
    m = model_info(model_id)
    if not m["available"]:
        raise ProviderError(f"{m['name']} is not configured (missing credential or service not running)")
    from . import control
    if (m["in"] or m["out"]) and not control.perms()["allow_paid_models"]:
        raise ProviderError("paid models are disabled in Settings > Permissions")
    est = (_est_tokens(system + prompt) * m["in"] + max_tokens * m["out"]) / 1e6
    economy.check_budget(est)
    messages = (history or []) + [{"role": "user", "content": prompt}]
    t0 = time.time()
    text, tin, tout = ADAPTERS[m["provider"]].complete(model_id.split("@")[0], system, messages, max_tokens)
    latency = time.time() - t0
    cost = (tin * m["in"] + tout * m["out"]) / 1e6
    db.insert("ledger", ts=time.time(), model=model_id, agent_id=agent_id, task_id=task_id,
              tokens_in=tin, tokens_out=tout, cost=cost, latency=latency, purpose=purpose)
    db.emit("economy", "model_call", model_id, cost=cost, tokens_in=tin, tokens_out=tout,
            latency=round(latency, 3), purpose=purpose, agent_id=agent_id)
    return {"text": text, "model": model_id, "tokens_in": tin, "tokens_out": tout, "cost": cost, "latency": latency}
