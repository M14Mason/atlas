"""AI Council: independent answers -> anonymous critique and revision ->
reputation-weighted vote -> decision.

Weights come from measured Arena/task performance for the question's
category (economy.reputation). A model with no track record gets the
neutral prior 0.5, so proven models outweigh unproven ones.
Answers are anonymised as A, B, C... during critique and voting so a
model can't simply vote for itself by name; self-votes are discarded.
"""
import math
import re
import string
import time

from . import agents, db, economy, providers


def weight(model, category):
    score, n = economy.reputation(model, category)
    return round(score * (1 + math.log1p(n) / 3), 4)


def deliberate(question, members=None, category=None, rounds=1, progress=None):
    category = category or agents.classify(question)
    avail = [m["id"] for m in providers.available_models() if m["provider"] != "local"]
    members = [m for m in (members or avail) if m in avail]
    cid = db.insert("experiments", name="council: " + question[:60], kind="council",
                    config={"question": question, "members": members, "category": category}, seed=0,
                    status="running", created=time.time())
    thread = f"council-{cid}"
    db.emit("council", "session_started", "council", session=cid, members=members, category=category, question=question)

    def say(sender, content, phase):
        db.insert("messages", ts=time.time(), thread=thread, sender=sender, recipient="council", content=content)
        db.emit("council", "statement", sender, session=cid, phase=phase, preview=content[:200])

    if len(members) < 2:
        note = ("The council needs at least 2 configured models. Available now: "
                f"{members or 'none'}. Add API keys or start Ollama in Settings.")
        if members:
            r = providers.complete(members[0], question, purpose="council:answer")
            say(members[0], r["text"], "answer")
            result = {"decision": r["text"], "winner": members[0], "note": note, "votes": {}}
        else:
            result = {"decision": None, "note": note, "votes": {}}
        db.update("experiments", cid, status="done", results=result, finished=time.time())
        db.emit("council", "session_done", "council", session=cid, **{k: v for k, v in result.items() if k != "decision"})
        return {"session": cid, **result}

    answers = {}
    steps = len(members) * (2 + rounds)
    done = 0
    for m in members:
        try:
            answers[m] = providers.complete(m, question, system="Answer carefully and concisely. Give your reasoning briefly.",
                                            purpose="council:answer", max_tokens=600)["text"]
        except Exception as e:
            answers[m] = None
            say(m, f"(unavailable: {e})", "error")
            continue
        say(m, answers[m], "answer")
        done += 1
        progress and progress(done / steps)
    live = [m for m in members if answers.get(m)]
    for _ in range(rounds):
        labels = dict(zip(live, string.ascii_uppercase))
        for m in live:
            others = "\n\n".join(f"Answer {labels[o]}:\n{answers[o]}" for o in live if o != m)
            try:
                r = providers.complete(m, f"Question: {question}\n\nYour answer:\n{answers[m]}\n\nOther council answers:\n"
                                       f"{others}\n\nCritique the others briefly, then give your REVISED final answer "
                                       "after the line 'REVISED:'.", purpose="council:critique", max_tokens=700)["text"]
                say(m, r, "critique")
                if "REVISED:" in r:
                    answers[m] = r.split("REVISED:", 1)[1].strip()
            except Exception as e:
                say(m, f"(critique failed: {e})", "error")
            done += 1
            progress and progress(done / steps)
    labels = dict(zip(live, string.ascii_uppercase))
    by_label = {v: k for k, v in labels.items()}
    ballot = "\n\n".join(f"Answer {labels[m]}:\n{answers[m]}" for m in live)
    votes, tally = {}, {m: 0.0 for m in live}
    for m in live:
        try:
            r = providers.complete(m, f"Question: {question}\n\n{ballot}\n\nWhich answer is most correct and useful? "
                                   "Reply with only the letter.", purpose="council:vote", max_tokens=5)["text"]
            letter = (re.findall(r"\b([A-Z])\b", r.upper()) or [None])[0]
            choice = by_label.get(letter)
            if choice and choice != m:
                w = weight(m, category)
                votes[m] = {"for": choice, "weight": w}
                tally[choice] += w
            else:
                votes[m] = {"for": choice, "weight": 0, "note": "self-vote or invalid, discarded"}
            say(m, f"Votes {letter} (weight {votes[m]['weight']})", "vote")
        except Exception as e:
            say(m, f"(vote failed: {e})", "error")
        done += 1
        progress and progress(min(1, done / steps))
    winner = max(tally, key=lambda k: (tally[k], weight(k, category))) if tally else None
    result = {"decision": answers.get(winner), "winner": winner, "tally": tally, "votes": votes,
              "weights": {m: weight(m, category) for m in live}, "category": category}
    db.update("experiments", cid, status="done", results=result, finished=time.time())
    db.emit("council", "session_done", "council", session=cid, winner=winner, tally=tally)
    return {"session": cid, **result}


def sessions():
    return db.query("SELECT id, name, config, status, results, created FROM experiments WHERE kind='council' ORDER BY id DESC LIMIT 30")
