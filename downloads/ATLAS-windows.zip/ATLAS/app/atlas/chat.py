"""Ask ATLAS: persistent conversations with any model, grounded in your
Knowledge Universe (and the web, when allowed), with cost per message."""
import time

from . import agents, db, economy, knowledge, providers

SYSTEM = ("You are ATLAS, a helpful, precise assistant inside the user's AI command center. "
          "When context passages are provided, use them and cite them as [K1], [W1] etc. "
          "If you are not sure, say so. Keep answers clear and well structured.")


def conversations():
    return db.query("SELECT c.*, (SELECT COUNT(*) FROM chat_messages m WHERE m.conv_id=c.id) n FROM conversations c "
                    "ORDER BY updated DESC LIMIT 100")


def messages(cid):
    return db.query("SELECT * FROM chat_messages WHERE conv_id=? ORDER BY id", (cid,))


def new(title="New chat", model="auto"):
    return db.insert("conversations", title=title, model=model, created=time.time(), updated=time.time())


def send(cid, text, model="auto", use_knowledge=True, use_web=False):
    if not cid:
        cid = new(text[:50])
    hist = [{"role": m["role"], "content": m["content"]} for m in messages(cid)[-12:]]
    db.insert("chat_messages", conv_id=cid, role="user", content=text, model=None, cost=0, sources=[], ts=time.time())
    sources, ctx = [], ""
    if use_knowledge:
        hits = [h for h in knowledge.search(text, k=4) if h["score"] > 0.08]
        for i, h in enumerate(hits, 1):
            sources.append({"tag": f"K{i}", "title": h["title"], "doc_id": h["doc_id"]})
            ctx += f"[K{i}] ({h['title']}) {h['snippet']}\n"
    if use_web:
        from . import web
        try:
            r = web.research(text, pages=3)
            for s in r["sources"]:
                sources.append({"tag": f"W{s['n']}", "title": s["title"], "url": s["url"]})
            ctx += "\n" + r["context"].replace("[", "[W")
        except Exception as e:
            ctx += f"\n(web research unavailable: {e})\n"
    why = "chosen by you"
    if model == "auto":
        model, why = economy.route(agents.classify(text), "medium")
    # the Local Engine does its own retrieval and needs the bare question
    prompt = (f"Context passages:\n{ctx}\n\nQuestion: {text}" if ctx and model != "atlas-local" else text)
    try:
        r = providers.complete(model, prompt, system=SYSTEM, history=hist, max_tokens=1200, purpose="chat")
    except (providers.ProviderError, economy.BudgetExceeded) as e:
        r = providers.complete("atlas-local", text, purpose="chat-fallback")
        r["text"] = f"({model} unavailable: {e}. Answer from the local engine.)\n\n" + r["text"]
        model = "atlas-local"
    mid = db.insert("chat_messages", conv_id=cid, role="assistant", content=r["text"], model=model, cost=r["cost"],
                    sources=sources, ts=time.time())
    title = db.one("SELECT title FROM conversations WHERE id=?", (cid,))["title"]
    db.execute("UPDATE conversations SET updated=?, title=? WHERE id=?",
               (time.time(), text[:50] if title == "New chat" else title, cid))
    db.emit("chat", "reply", model, conv_id=cid, cost=r["cost"], why=why)
    return {"conv_id": cid, "message_id": mid, "text": r["text"], "model": model, "why": why, "cost": r["cost"],
            "sources": sources, "latency": r.get("latency")}


def delete(cid):
    db.execute("DELETE FROM chat_messages WHERE conv_id=?", (cid,))
    db.execute("DELETE FROM conversations WHERE id=?", (cid,))
