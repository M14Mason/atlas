"""Compute Center: machines, a job queue, and the runner.

The machine running ATLAS registers itself as the 'local' node with its
real CPU, memory and GPU details. Other machines (your Windows PC,
another Mac, a free Colab/Kaggle notebook) join by running
`python worker.py --server http://<atlas-host>:8600`, which claims jobs
over HTTP. Free local nodes are always preferred over paid ones.
"""
import json
import os
import platform
import shutil
import subprocess
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

from . import db

_pool = ThreadPoolExecutor(max_workers=max(2, (os.cpu_count() or 2)))
_handlers = {}
_cancel = set()


def handler(kind, remote_ok=False):
    def deco(fn):
        _handlers[kind] = (fn, remote_ok)
        return fn
    return deco


def local_specs():
    mem_gb = None
    try:
        if platform.system() == "Darwin":
            mem_gb = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"])) / 1e9
        else:
            with open("/proc/meminfo") as f:
                mem_gb = int(f.readline().split()[1]) / 1e6
    except Exception:
        pass
    gpu = None
    if shutil.which("nvidia-smi"):
        try:
            gpu = subprocess.check_output(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
                                          timeout=3).decode().strip()
        except Exception:
            pass
    elif platform.system() == "Darwin" and platform.machine() == "arm64":
        gpu = "Apple Silicon GPU (Metal, usable via PyTorch MPS)"
    du = shutil.disk_usage(os.path.expanduser("~"))
    return {"os": f"{platform.system()} {platform.release()}", "machine": platform.machine(),
            "cpus": os.cpu_count(), "memory_gb": round(mem_gb, 1) if mem_gb else None, "gpu": gpu,
            "disk_free_gb": round(du.free / 1e9, 1), "python": platform.python_version()}


def register_local():
    existing = db.one("SELECT id FROM nodes WHERE kind='local'")
    specs = local_specs()
    if existing:
        db.update("nodes", existing["id"], specs=specs, status="online", last_seen=time.time())
        return existing["id"]
    return db.insert("nodes", name=platform.node() or "this machine", kind="local", specs=specs,
                     cost_per_hour=0, status="online", last_seen=time.time())


def submit(kind, title, payload, prefer_remote=False):
    """Queue a job. Runs locally right away unless a remote worker is
    requested and online for a remote-capable kind."""
    fn, remote_ok = _handlers[kind]
    jid = db.insert("jobs", kind=kind, title=title, status="queued", progress=0,
                    result={"payload": payload}, created=time.time())
    db.emit("compute", "job_queued", "scheduler", job_id=jid, kind=kind, title=title)
    remote_online = db.one("SELECT id FROM nodes WHERE kind='worker' AND last_seen>?", (time.time() - 30,))
    if prefer_remote and remote_ok and remote_online:
        return jid  # a worker will claim it
    _pool.submit(_run, jid, fn, payload)
    return jid


def _run(jid, fn, payload):
    node = db.one("SELECT id FROM nodes WHERE kind='local'")
    db.update("jobs", jid, status="running", node_id=node["id"] if node else None)
    db.emit("compute", "job_started", "scheduler", job_id=jid)

    def progress(p, **info):
        if jid in _cancel:
            raise InterruptedError("cancelled")
        db.update("jobs", jid, progress=p)
        if info:
            db.emit("compute", "job_progress", "worker", job_id=jid, progress=p, **info)

    try:
        res = fn(payload, progress)
        db.update("jobs", jid, status="done", progress=1, result=res, finished=time.time())
        db.emit("compute", "job_done", "worker", job_id=jid)
    except InterruptedError:
        db.update("jobs", jid, status="cancelled", finished=time.time())
        db.emit("compute", "job_cancelled", "worker", job_id=jid)
    except Exception as e:
        db.log("error", f"job:{db.one('SELECT kind FROM jobs WHERE id=?', (jid,))['kind']}", str(e), traceback.format_exc()[-4000:])
        db.update("jobs", jid, status="error", result={"error": str(e), "trace": traceback.format_exc()[-2000:]},
                  finished=time.time())
        db.emit("compute", "job_error", "worker", job_id=jid, error=str(e))


def cancel(jid):
    _cancel.add(int(jid))


# ----------------------------------------------------------- remote workers
def worker_heartbeat(name, specs):
    row = db.one("SELECT id FROM nodes WHERE kind='worker' AND name=?", (name,))
    if row:
        db.update("nodes", row["id"], specs=specs, status="online", last_seen=time.time())
        return row["id"]
    nid = db.insert("nodes", name=name, kind="worker", specs=specs, cost_per_hour=0, status="online", last_seen=time.time())
    db.emit("compute", "node_joined", name, node_id=nid, specs=specs)
    return nid


def claim(node_id, kinds):
    for kind in kinds:
        if kind in _handlers and _handlers[kind][1]:
            j = db.one("SELECT * FROM jobs WHERE status='queued' AND kind=? ORDER BY id LIMIT 1", (kind,))
            if j:
                db.update("jobs", j["id"], status="running", node_id=node_id)
                db.emit("compute", "job_claimed", f"node {node_id}", job_id=j["id"])
                return {"id": j["id"], "kind": kind, "payload": j["result"]["payload"]}
    return None


def finish_remote(jid, result, error=None):
    db.update("jobs", jid, status="error" if error else "done", progress=1,
              result={"error": error} if error else result, finished=time.time())
    db.emit("compute", "job_error" if error else "job_done", "remote", job_id=jid)


def overview():
    nodes = db.query("SELECT * FROM nodes")
    for n in nodes:
        if n["kind"] == "worker" and time.time() - (n["last_seen"] or 0) > 30:
            n["status"] = "offline"
    jobs = db.query("SELECT id, kind, title, status, progress, node_id, created, finished FROM jobs ORDER BY id DESC LIMIT 50")
    return {"nodes": nodes, "jobs": jobs, "handlers": sorted(_handlers)}
