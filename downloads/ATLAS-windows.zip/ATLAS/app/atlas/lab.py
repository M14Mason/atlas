"""Research Lab + Model Builder.

Research Lab: controlled experiments. Change ONE variable, keep
everything else fixed, repeat across several seeds, report mean and
spread. Every run stores its full config and seed, and `reproduce()`
re-runs it and checks the numbers match exactly.

Model Builder: train ATLAS's own models, continue training (fine-tune)
an existing system on new data, version and roll back. For large
language models, it exports your best graded agent work as a JSONL
training set and can submit an OpenAI fine-tuning job (needs a key) or
print the MLX LoRA command to fine-tune an open model on your Mac.
"""
import hashlib
import json
import os
import time
import urllib.request

import numpy as np

from . import db, neural, secrets


def _fingerprint(r):
    return hashlib.sha256(json.dumps(r["history"], sort_keys=True).encode()).hexdigest()[:16]


def run_experiment(cfg, name=None, progress=None):
    eid = db.insert("experiments", name=name or f"train {cfg.get('dataset')}", kind="train", config=cfg,
                    seed=int(cfg.get("seed", 0)), status="running", created=time.time())
    db.emit("research", "experiment_started", "lab", experiment=eid, config=cfg)

    def prog(p, **row):
        if progress:
            progress(p, **row)
        db.emit("research", "epoch", "lab", experiment=eid, **row)

    r = neural.train(cfg, progress=prog)
    r["fingerprint"] = _fingerprint(r)
    db.update("experiments", eid, status="done", results={k: v for k, v in r.items() if k != "model"}, finished=time.time())
    db.emit("research", "experiment_done", "lab", experiment=eid, metrics=r["metrics"], fingerprint=r["fingerprint"])
    from . import knowledge
    knowledge.remember("parameter", f"experiment {eid}: {cfg.get('dataset')} {cfg.get('hidden')}",
                       f"Trained {r['params']} parameters; val {r['metrics']['metric_name']} {r['metrics']['val']:.3f}", "research-lab")
    return {"experiment": eid, **r}


def sweep(base, variable, values, seeds=(0, 1, 2), progress=None):
    """Controlled experiment."""
    eid = db.insert("experiments", name=f"sweep {variable}", kind="sweep",
                    config={"base": base, "variable": variable, "values": values, "seeds": list(seeds)},
                    seed=0, status="running", created=time.time())
    db.emit("research", "sweep_started", "lab", experiment=eid, variable=variable, values=values)
    rows, total, k = [], len(values) * len(seeds), 0
    for v in values:
        vals = []
        for s in seeds:
            cfg = {**base, variable: v, "seed": s}
            r = neural.train(cfg)
            vals.append(r["metrics"]["val"])
            k += 1
            progress and progress(k / total)
        rows.append({"value": v, "mean": float(np.mean(vals)), "std": float(np.std(vals)), "runs": vals})
        db.emit("research", "sweep_point", "lab", experiment=eid, value=v, mean=rows[-1]["mean"], std=rows[-1]["std"])
    best = max(rows, key=lambda r: r["mean"])
    # is the best clearly better than the runner-up, or within noise?
    srt = sorted(rows, key=lambda r: -r["mean"])
    sig = len(srt) > 1 and (srt[0]["mean"] - srt[1]["mean"]) > (srt[0]["std"] + srt[1]["std"])
    res = {"rows": rows, "best": best["value"], "clear_winner": bool(sig),
           "conclusion": f"Best {variable}={best['value']} (val {best['mean']:.3f} +/- {best['std']:.3f}). " +
           ("The gap to the runner-up is larger than the seed noise." if sig else
            "The gap to the runner-up is within seed noise, so this is NOT a reliable difference.")}
    db.update("experiments", eid, status="done", results=res, finished=time.time())
    db.emit("research", "sweep_done", "lab", experiment=eid, conclusion=res["conclusion"])
    return {"experiment": eid, **res}


def reproduce(eid):
    e = db.one("SELECT * FROM experiments WHERE id=? AND kind='train'", (eid,))
    r = neural.train(e["config"])
    fp = _fingerprint(r)
    same = fp == e["results"].get("fingerprint")
    db.emit("research", "reproduced", "lab", experiment=eid, identical=same)
    return {"experiment": eid, "original": e["results"].get("fingerprint"), "rerun": fp, "identical": same}


# ------------------------------------------------------------ model builder
def finetune_system(sid, csv_text, epochs=60, lr=0.003):
    """Continue training an Architect-built tabular model on new rows.
    Creates a new version; the old one stays for rollback."""
    from . import architect
    s = db.one("SELECT * FROM systems WHERE id=?", (sid,))
    P = s["package"]
    if not P or P["type"] != "mlp" or "vocab" in P:
        raise ValueError("fine-tuning is supported for tabular MLP systems")
    X, y, task, schema = architect.parse_csv(csv_text, P["schema"]["target"])
    if schema["features"] != P["schema"]["features"]:
        raise ValueError("new data must have the same columns as the original")
    r = neural.train({**P["config"], "epochs": epochs, "lr": lr}, X=X, y=y, task=task, init=P["model"])
    hist = (s["metrics"] or {}).get("versions", [])
    hist.append({"version": s["version"], "package": P, "test": (s["metrics"] or {}).get("test"), "ts": time.time()})
    newP = {**P, "model": r["model"]}
    metrics = {**(s["metrics"] or {}), "test": r["metrics"]["test"], "versions": hist[-10:], "finetuned_on": len(X)}
    db.update("systems", sid, package=newP, version=s["version"] + 1, metrics=metrics)
    from . import knowledge
    knowledge.remember("parameter", f"system {sid} v{s['version'] + 1}", f"Fine-tuned on {len(X)} new rows; test {r['metrics']['test']}", "model-builder")
    db.emit("builder", "finetuned", "model-builder", system_id=sid, version=s["version"] + 1, test=r["metrics"]["test"],
            previous_test=hist[-1]["test"])
    return {"version": s["version"] + 1, "test": r["metrics"]["test"], "previous_test": hist[-1]["test"]}


def rollback_system(sid):
    s = db.one("SELECT * FROM systems WHERE id=?", (sid,))
    hist = (s["metrics"] or {}).get("versions", [])
    if not hist:
        raise ValueError("no earlier version")
    prev = hist.pop()
    db.update("systems", sid, package=prev["package"], version=prev["version"],
              metrics={**s["metrics"], "versions": hist, "test": prev["test"]})
    db.emit("builder", "rollback", "model-builder", system_id=sid, version=prev["version"])
    return {"version": prev["version"]}


def export_llm_dataset(min_quality=0.8):
    """Training examples for LLM fine-tuning, from agent work that was
    graded highly. This is how the workforce turns experience into
    parameter changes."""
    rows = db.query("SELECT t.input, t.output, a.config FROM tasks t JOIN agents a ON a.id=t.agent_id "
                    "WHERE t.quality>=? AND t.output IS NOT NULL", (min_quality,))
    path = os.path.join(db.DATA_DIR, "finetune", f"dataset-{int(time.time())}.jsonl")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps({"messages": [{"role": "system", "content": r["config"]["system"]},
                                             {"role": "user", "content": r["input"]},
                                             {"role": "assistant", "content": r["output"]}]}) + "\n")
    db.emit("builder", "dataset_exported", "model-builder", examples=len(rows), path=os.path.basename(path))
    return {"path": path, "examples": len(rows),
            "mlx_command": f"pip install mlx-lm && mlx_lm.lora --model mlx-community/Llama-3.2-1B-Instruct-4bit --train "
                           f"--data {os.path.dirname(path)} --iters 200   # Apple Silicon Mac, free, local",
            "note": "OpenAI requires at least 10 examples. Review the file before uploading anything."}


def submit_openai_finetune(path, base_model="gpt-4.1-mini-2025-04-14"):
    """UNTESTED in this build environment (no OpenAI key here).
    Uploads the JSONL and creates a fine-tuning job. Costs real money."""
    key = secrets.get("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY not set")
    boundary = "atlasboundary"
    with open(path, "rb") as f:
        data = f.read()
    body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"purpose\"\r\n\r\nfine-tune\r\n"
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"data.jsonl\"\r\n"
            "Content-Type: application/jsonl\r\n\r\n").encode() + data + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request("https://api.openai.com/v1/files", data=body, method="POST",
                                 headers={"authorization": f"Bearer {key}",
                                          "content-type": f"multipart/form-data; boundary={boundary}"})
    file_id = json.loads(urllib.request.urlopen(req, timeout=60).read())["id"]
    req = urllib.request.Request("https://api.openai.com/v1/fine_tuning/jobs", method="POST",
                                 data=json.dumps({"training_file": file_id, "model": base_model}).encode(),
                                 headers={"authorization": f"Bearer {key}", "content-type": "application/json"})
    job = json.loads(urllib.request.urlopen(req, timeout=60).read())
    db.emit("builder", "llm_finetune_submitted", "model-builder", job=job.get("id"), base=base_model)
    return job
