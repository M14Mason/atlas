"""Storage layer: one SQLite file plus a live event bus.

Every department writes what it does to the `events` table. The UI's
animations, diagrams and conversation feeds are drawn only from these
events, so nothing on screen is invented.
"""
import json
import os
import queue
import sqlite3
import threading
import time

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # code + bundled resources (read-only in apps)


def _default_data_dir():
    if os.environ.get("ATLAS_DATA"):
        return os.environ["ATLAS_DATA"]
    if os.environ.get("ATLAS_APP"):  # installed desktop app: per-user writable folder
        if os.name == "nt":
            return os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "ATLAS")
        if os.uname().sysname == "Darwin":
            return os.path.expanduser("~/Library/Application Support/ATLAS")
        return os.path.expanduser("~/.local/share/atlas")
    return os.path.join(APP_DIR, "data")


DATA_DIR = _default_data_dir()
DB_PATH = os.path.join(DATA_DIR, "atlas.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, ts REAL, dept TEXT, kind TEXT, actor TEXT, data TEXT);
CREATE INDEX IF NOT EXISTS ev_dept ON events(dept, id);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS agents(id INTEGER PRIMARY KEY, name TEXT, parent_id INTEGER, model TEXT, role TEXT,
  specialty TEXT, status TEXT, version INTEGER, config TEXT, stats TEXT, created REAL);
CREATE TABLE IF NOT EXISTS agent_versions(id INTEGER PRIMARY KEY, agent_id INTEGER, version INTEGER, config TEXT, note TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT, input TEXT, kind TEXT, agent_id INTEGER,
  parent_id INTEGER, status TEXT, output TEXT, cost REAL DEFAULT 0, quality REAL, created REAL, finished REAL);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, ts REAL, thread TEXT, sender TEXT, recipient TEXT, content TEXT);
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY, ts REAL, model TEXT, agent_id INTEGER, task_id INTEGER,
  tokens_in INTEGER, tokens_out INTEGER, cost REAL, latency REAL, purpose TEXT);
CREATE TABLE IF NOT EXISTS reputation(model TEXT, category TEXT, score REAL, n INTEGER, PRIMARY KEY(model, category));
CREATE TABLE IF NOT EXISTS docs(id INTEGER PRIMARY KEY, title TEXT, content TEXT, project TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY, kind TEXT, subject TEXT, content TEXT, source TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS experiments(id INTEGER PRIMARY KEY, name TEXT, kind TEXT, config TEXT, seed INTEGER,
  status TEXT, results TEXT, created REAL, finished REAL);
CREATE TABLE IF NOT EXISTS nodes(id INTEGER PRIMARY KEY, name TEXT, kind TEXT, specs TEXT, cost_per_hour REAL, status TEXT, last_seen REAL);
CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, kind TEXT, title TEXT, status TEXT, progress REAL, node_id INTEGER,
  result TEXT, created REAL, finished REAL);
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, ts REAL, level TEXT, source TEXT, message TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY, title TEXT, model TEXT, created REAL, updated REAL);
CREATE TABLE IF NOT EXISTS chat_messages(id INTEGER PRIMARY KEY, conv_id INTEGER, role TEXT, content TEXT, model TEXT,
  cost REAL, sources TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS automations(id INTEGER PRIMARY KEY, name TEXT, kind TEXT, payload TEXT, schedule TEXT,
  enabled INTEGER, last_run REAL, next_run REAL, last_status TEXT, runs INTEGER DEFAULT 0, created REAL);
CREATE TABLE IF NOT EXISTS hall_of_fame(id INTEGER PRIMARY KEY, bot_id INTEGER, asset TEXT, mode TEXT, gen INTEGER,
  in_sample REAL, oos REAL, buy_hold REAL, dna TEXT, note TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS embeddings(hash TEXT PRIMARY KEY, model TEXT, vec BLOB);
CREATE TABLE IF NOT EXISTS systems(id INTEGER PRIMARY KEY, name TEXT, description TEXT, approach TEXT, status TEXT,
  version INTEGER, package TEXT, metrics TEXT, created REAL);
"""

_lock = threading.RLock()
_conn = None
_subscribers = []


def connect(path=None):
    global _conn, DB_PATH
    DB_PATH = path or os.path.join(DATA_DIR, "atlas.db")
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    _conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    _conn.row_factory = sqlite3.Row
    _conn.execute("PRAGMA journal_mode=WAL")
    _conn.executescript(SCHEMA)
    _conn.commit()
    return _conn


def execute(sql, params=()):
    with _lock:
        cur = _conn.execute(sql, params)
        _conn.commit()
        return cur.lastrowid


def query(sql, params=()):
    with _lock:
        rows = _conn.execute(sql, params).fetchall()
    return [_decode(dict(r)) for r in rows]


def one(sql, params=()):
    rows = query(sql, params)
    return rows[0] if rows else None


JSON_COLS = {"data", "config", "stats", "results", "specs", "result", "package", "metrics", "payload", "schedule",
             "sources", "dna", "detail"}


def _decode(row):
    for k in JSON_COLS & row.keys():
        if isinstance(row[k], str):
            try:
                row[k] = json.loads(row[k])
            except ValueError:
                pass
    return row


def insert(table, **fields):
    for k, v in fields.items():
        if isinstance(v, (dict, list)):
            fields[k] = json.dumps(v)
    cols = ",".join(fields)
    marks = ",".join("?" * len(fields))
    return execute(f"INSERT INTO {table}({cols}) VALUES({marks})", tuple(fields.values()))


def update(table, row_id, **fields):
    for k, v in fields.items():
        if isinstance(v, (dict, list)):
            fields[k] = json.dumps(v)
    sets = ",".join(f"{k}=?" for k in fields)
    execute(f"UPDATE {table} SET {sets} WHERE id=?", (*fields.values(), row_id))


def setting(key, default=None):
    row = one("SELECT value FROM settings WHERE key=?", (key,))
    return json.loads(row["value"]) if row else default


def set_setting(key, value):
    execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, json.dumps(value)))


# ---------------------------------------------------------------- event bus
def emit(_dept, _kind, _actor="system", **data):
    dept, kind, actor = _dept, _kind, _actor
    ts = time.time()
    eid = insert("events", ts=ts, dept=dept, kind=kind, actor=actor, data=data)
    ev = {"id": eid, "ts": ts, "dept": dept, "kind": kind, "actor": actor, "data": data}
    for q in list(_subscribers):
        try:
            q.put_nowait(ev)
        except queue.Full:
            pass
    return ev


def subscribe():
    q = queue.Queue(maxsize=2000)
    _subscribers.append(q)
    return q


def unsubscribe(q):
    if q in _subscribers:
        _subscribers.remove(q)


# ---------------------------------------------------------------- error log
def log(level, source, message, detail=None):
    """Persistent log for debugging. Shown in System Health."""
    try:
        insert("logs", ts=time.time(), level=level, source=source, message=str(message)[:2000],
               detail=detail if isinstance(detail, (dict, list)) else (str(detail)[:8000] if detail else None))
        if level == "error":
            emit("system", "error_logged", source, message=str(message)[:300])
        execute("DELETE FROM logs WHERE id < (SELECT MAX(id) FROM logs) - 5000")
    except Exception:
        pass
