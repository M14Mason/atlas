"""PROJECT ATLAS - an AI ecosystem command center."""
__version__ = "0.3.0"
