"""Live market data: download daily prices so the Market Lab, Architect
and Workspace can use current data instead of the bundled 2007-2016 set.

Source order: Alpaca (if ALPACA keys are set) -> Yahoo Finance chart API
-> Stooq CSV. Each is free for personal use. Files land in the user data
folder as user_<TICKER>.csv (Date,Close) and appear everywhere instantly.
"""
import csv
import io
import json
import os
import re
import time
import urllib.request
from datetime import datetime, timedelta, timezone

from . import db, market, secrets

UA = {"user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 Safari/605.1.15"}
SOURCES = {
    "yahoo": "https://query1.finance.yahoo.com/v8/finance/chart/{sym}?range={years}y&interval=1d",
    "stooq": "https://stooq.com/q/d/l/?s={sym}.us&i=d",
    "alpaca": "https://data.alpaca.markets/v2/stocks/{sym}/bars?timeframe=1Day&start={start}&limit=10000&adjustment=all&feed=iex",
}


def _get(url, headers=None, timeout=20):
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")


def parse_yahoo(text):
    j = json.loads(text)["chart"]["result"][0]
    closes = j["indicators"].get("adjclose", [{}])[0].get("adjclose") or j["indicators"]["quote"][0]["close"]
    rows = []
    for t, c in zip(j["timestamp"], closes):
        if c is not None:
            rows.append((datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d"), float(c)))
    return rows


def parse_stooq(text):
    rows = []
    for r in csv.DictReader(io.StringIO(text)):
        try:
            rows.append((r["Date"], float(r["Close"])))
        except (KeyError, ValueError):
            pass
    return rows


def parse_alpaca(text):
    return [(b["t"][:10], float(b["c"])) for b in json.loads(text).get("bars", [])]


def download(symbol, years=10):
    sym = re.sub(r"[^A-Za-z0-9\.\-\^]", "", symbol).upper()[:12]
    if not sym:
        raise ValueError("enter a ticker like AAPL")
    errors = []
    attempts = []
    if secrets.get("ALPACA_API_KEY") and secrets.get("ALPACA_SECRET_KEY"):
        start = (datetime.now(timezone.utc) - timedelta(days=365 * years)).strftime("%Y-%m-%d")
        attempts.append(("alpaca", SOURCES["alpaca"].format(sym=sym, start=start), parse_alpaca,
                         {"APCA-API-KEY-ID": secrets.get("ALPACA_API_KEY"), "APCA-API-SECRET-KEY": secrets.get("ALPACA_SECRET_KEY")}))
    attempts.append(("yahoo", SOURCES["yahoo"].format(sym=sym, years=years), parse_yahoo, None))
    attempts.append(("stooq", SOURCES["stooq"].format(sym=sym.lower()), parse_stooq, None))
    for name, url, parser, headers in attempts:
        try:
            rows = parser(_get(url, headers))
            if len(rows) < 130:
                raise ValueError(f"only {len(rows)} rows")
            path = os.path.join(market.user_dir(), f"user_{sym.replace('^', 'IDX')}.csv")
            with open(path, "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(["Date", "Close"])
                w.writerows(rows)
            market.LAB.hist = market.load_history()
            db.emit("workspace", "prices_downloaded", "market-data", asset=sym, rows=len(rows), source=name,
                    last=rows[-1][0])
            return {"asset": sym.replace("^", "IDX"), "rows": len(rows), "source": name, "first": rows[0][0], "last": rows[-1][0]}
        except Exception as e:
            errors.append(f"{name}: {e}")
    db.log("warn", "marketdata", f"download {sym} failed", errors)
    raise ValueError("all sources failed: " + "; ".join(errors))


def refresh_all():
    """Update every previously downloaded ticker. Used by automations."""
    done, failed = [], []
    for fn in os.listdir(market.user_dir()):
        if fn.startswith("user_") and fn.endswith(".csv"):
            sym = fn[5:-4]
            try:
                download(sym)
                done.append(sym)
            except Exception as e:
                failed.append(f"{sym}: {e}")
            time.sleep(1)
    return {"updated": done, "failed": failed}
