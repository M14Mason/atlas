"""HTTP API + live event stream + static UI. Standard library only.

Security: binds to 127.0.0.1 (this computer only) by default. With
--lan it listens on your network so your phone can connect, and every
non-local request must carry the access token printed at startup.
"""
import base64
import json
import os
import re
import secrets as pysecrets
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import (agents, architect, arena, automations, chat, compute, control, council, db, economy, knowledge, lab,
               market, marketdata, providers, secrets, system, web, workspace)

WEB = os.path.join(os.path.dirname(os.path.dirname(__file__)), "web")
ROUTES = []
TOKEN = pysecrets.token_urlsafe(12)
QUIT_HOOK = None  # set by the desktop launcher


def route(method, pattern):
    rx = re.compile("^" + pattern + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


class HTTPError(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code = code


# ------------------------------------------------------------ job handlers
@compute.handler("task")
def _h_task(p, progress):
    return agents.run_task(p.get("title") or p["text"][:60], p["text"], p.get("agent_id"), p.get("important", False),
                           p.get("difficulty", "medium"), review=p.get("review", False))


@compute.handler("ollama_pull")
def _h_pull(p, progress):
    return system.ollama_pull(p["model"], progress)


@compute.handler("market_download")
def _h_mdl(p, progress):
    out, errs = [], []
    syms = [s for s in p["symbols"] if s.strip()]
    for i, sym in enumerate(syms):
        try:
            out.append(marketdata.download(sym.strip(), int(p.get("years", 10))))
        except Exception as e:
            errs.append(f"{sym}: {e}")
        progress((i + 1) / len(syms))
    if not out:
        raise RuntimeError("; ".join(errs))
    return {"downloaded": out, "failed": errs}


@compute.handler("chat")
def _h_chat(p, progress):
    return chat.send(p.get("conv_id"), p["text"], p.get("model", "auto"), p.get("knowledge", True), p.get("web", False))


@compute.handler("diagnostics")
def _h_diag(p, progress):
    return system.diagnostics()


@compute.handler("web_research")
def _h_web(p, progress):
    return web.research(p["question"], int(p.get("pages", 3)))


@compute.handler("council")
def _h_council(p, progress):
    return council.deliberate(p["question"], p.get("members"), p.get("category"), int(p.get("rounds", 1)), progress)


@compute.handler("arena")
def _h_arena(p, progress):
    return arena.run_model(p["model"], p["category"], int(p.get("n", 5)), progress=progress)


@compute.handler("architect")
def _h_arch(p, progress):
    return architect.build(p["description"], p.get("name"), p.get("csv"), p.get("target"),
                           p.get("allow_synthetic", True), progress)


@compute.handler("train", remote_ok=True)
def _h_train(p, progress):
    r = lab.run_experiment(p["config"], p.get("name"), progress)
    return {k: v for k, v in r.items() if k != "model"}


@compute.handler("sweep")
def _h_sweep(p, progress):
    return lab.sweep(p["base"], p["variable"], p["values"], tuple(p.get("seeds", (0, 1, 2))), progress)


@compute.handler("evaluate")
def _h_eval(p, progress):
    return agents.evaluate(int(p["agent_id"]))


@compute.handler("autopilot")
def _h_auto(p, progress):
    return {"actions": control.AUTOPILOT.cycle()}


# ------------------------------------------------------------ overview
@route("GET", "/api/overview")
def overview(q, b):
    models = providers.price_table()
    jobs = db.query("SELECT status, COUNT(*) n FROM jobs GROUP BY status")
    return {
        "agents": db.one("SELECT COUNT(*) n FROM agents WHERE status!='retired'")["n"],
        "agents_by_status": db.query("SELECT status, COUNT(*) n FROM agents GROUP BY status"),
        "tasks": db.one("SELECT COUNT(*) n FROM tasks")["n"],
        "tasks_running": db.one("SELECT COUNT(*) n FROM tasks WHERE status='running'")["n"],
        "systems": db.query("SELECT status, COUNT(*) n FROM systems GROUP BY status"),
        "docs": db.one("SELECT COUNT(*) n FROM docs")["n"],
        "experiments": db.one("SELECT COUNT(*) n FROM experiments")["n"],
        "models_available": [m["id"] for m in models if m["available"]],
        "models_total": len(models),
        "jobs": jobs, "cost": {"today": economy.spent_since(86400), "total": economy.summary()["total"],
                               "limit": economy.limits()["daily_limit_usd"]},
        "market": {"gen": market.LAB.gen, "status": market.LAB.status},
        "nodes": len(db.query("SELECT id FROM nodes")),
        "events": db.query("SELECT * FROM events ORDER BY id DESC LIMIT 40"),
        "activity": db.query("SELECT dept, COUNT(*) n FROM events WHERE ts>? GROUP BY dept", (time.time() - 3600,)),
        "permissions": control.perms(),
        "health": {"db": True, "autopilot": control.perms()["autopilot"], "credentials": secrets.status()},
    }


@route("GET", "/api/events")
def events(q, b):
    since = int(q.get("since", 0))
    dept = q.get("dept")
    if dept:
        return db.query("SELECT * FROM events WHERE id>? AND dept=? ORDER BY id DESC LIMIT 300", (since, dept))
    return db.query("SELECT * FROM events WHERE id>? ORDER BY id DESC LIMIT 300", (since,))


# ------------------------------------------------------------ settings
@route("GET", "/api/models")
def models(q, b):
    return providers.price_table()


@route("POST", "/api/models/prices")
def set_prices(q, b):
    p = db.setting("prices", {})
    p[b["model"]] = [float(b["in"]), float(b["out"])]
    db.set_setting("prices", p)
    return {"ok": True}


@route("GET", "/api/credentials")
def creds(q, b):
    return secrets.status()


@route("POST", "/api/credentials")
def set_cred(q, b):
    secrets.set_secret(b["name"], b.get("value", ""))
    providers.Ollama._checked = 0
    db.emit("control", "credential_changed", "user", name=b["name"], set=bool(b.get("value")))
    return secrets.status()


@route("GET", "/api/permissions")
def get_perms(q, b):
    return {"permissions": control.perms(), "limits": economy.limits(), "autopilot_log": control.AUTOPILOT.log}


@route("POST", "/api/permissions")
def post_perms(q, b):
    if "limits" in b:
        db.set_setting("limits", {**economy.limits(), **{k: float(v) for k, v in b["limits"].items()}})
    control.set_perms(**b.get("permissions", {}))
    return get_perms(q, b)


@route("POST", "/api/autopilot/run")
def autopilot_now(q, b):
    return {"job": compute.submit("autopilot", "autopilot cycle", {})}


@route("POST", "/api/chat")
def chat_direct(q, b):
    model = b.get("model") or "auto"
    why = "chosen by you"
    if model == "auto":
        model, why = economy.route(agents.classify(b["prompt"]), b.get("difficulty", "medium"))
    r = providers.complete(model, b["prompt"], history=b.get("history"), purpose="chat")
    return {**r, "why": why}


# ------------------------------------------------------------ council
@route("POST", "/api/council")
def council_ask(q, b):
    return {"job": compute.submit("council", "council: " + b["question"][:50], b)}


@route("GET", "/api/council/sessions")
def council_sessions(q, b):
    return council.sessions()


@route("GET", "/api/thread/(?P<name>[\\w\\-]+)")
def thread(q, b, name):
    return db.query("SELECT * FROM messages WHERE thread=? ORDER BY id", (name,))


@route("GET", "/api/messages")
def messages(q, b):
    return db.query("SELECT * FROM messages ORDER BY id DESC LIMIT ?", (int(q.get("limit", 80)),))


# ------------------------------------------------------------ workforce
@route("GET", "/api/agents")
def agent_list(q, b):
    agents.ensure_seed()
    return agents.org_tree()


@route("POST", "/api/agents")
def agent_create(q, b):
    return {"id": agents.create(b["name"], b.get("role", "specialist"), b.get("specialty", "general"), b.get("model", "auto"),
                                b.get("parent_id"), "probation", b.get("system"), b.get("tools"), b.get("can_delegate", False),
                                note="created by you")}


@route("GET", "/api/agents/(?P<aid>\\d+)")
def agent_detail(q, b, aid):
    a = agents.get(int(aid))
    if not a:
        raise HTTPError(404, "no such agent")
    a["versions"] = agents.versions(int(aid))
    a["tasks"] = db.query("SELECT id, title, status, quality, cost, created FROM tasks WHERE agent_id=? ORDER BY id DESC LIMIT 30", (aid,))
    a["team"] = db.query("SELECT id, name, specialty, status FROM agents WHERE parent_id=?", (aid,))
    a["spend"] = db.one("SELECT COALESCE(SUM(cost),0) c, COUNT(*) n FROM ledger WHERE agent_id=?", (aid,))
    return a


@route("POST", "/api/agents/(?P<aid>\\d+)/update")
def agent_update(q, b, aid):
    return {"version": agents.update_config(int(aid), note=b.pop("note", "edited by you"), **b)}


@route("POST", "/api/agents/(?P<aid>\\d+)/rollback")
def agent_rollback(q, b, aid):
    return {"version": agents.rollback(int(aid), int(b["version"]))}


@route("POST", "/api/agents/(?P<aid>\\d+)/evaluate")
def agent_eval(q, b, aid):
    return {"job": compute.submit("evaluate", f"evaluate agent {aid}", {"agent_id": aid})}


@route("POST", "/api/agents/(?P<aid>\\d+)/retire")
def agent_retire(q, b, aid):
    if not b.get("confirm_token"):
        return control.request_confirmation("retire", f"agent {aid}")
    control.confirm(b["confirm_token"], "retire", f"agent {aid}")
    agents.update_config(int(aid), note="retired by you", status="retired")
    return {"ok": True}


@route("POST", "/api/tasks")
def task_create(q, b):
    return {"job": compute.submit("task", b.get("title") or b["text"][:50], b)}


@route("GET", "/api/tasks")
def task_list(q, b):
    return db.query("SELECT t.id, t.title, t.kind, t.status, t.quality, t.cost, t.parent_id, t.agent_id, a.name agent, t.created "
                    "FROM tasks t LEFT JOIN agents a ON a.id=t.agent_id ORDER BY t.id DESC LIMIT 100")


@route("GET", "/api/tasks/(?P<tid>\\d+)")
def task_detail(q, b, tid):
    t = db.one("SELECT * FROM tasks WHERE id=?", (tid,))
    root = t
    while root["parent_id"]:
        root = db.one("SELECT * FROM tasks WHERE id=?", (root["parent_id"],))

    def tree(node):
        node["children"] = [tree(c) for c in db.query(
            "SELECT t.*, a.name agent FROM tasks t LEFT JOIN agents a ON a.id=t.agent_id WHERE t.parent_id=?", (node["id"],))]
        return node
    tr = tree(dict(root))
    ids = []

    def collect(n):
        ids.append(f"task-{n['id']}")
        for c in n["children"]:
            collect(c)
    collect(tr)
    marks = ",".join("?" * len(ids))
    return {"task": t, "tree": tr, "messages": db.query(f"SELECT * FROM messages WHERE thread IN ({marks}) ORDER BY id", tuple(ids))}


# ------------------------------------------------------------ arena
@route("POST", "/api/arena/run")
def arena_run(q, b):
    cats = b["categories"] if "categories" in b else [b["category"]]
    return {"jobs": [compute.submit("arena", f"arena {b['model']} {c}", {**b, "category": c}) for c in cats]}


@route("GET", "/api/arena")
def arena_data(q, b):
    return {"leaderboard": arena.leaderboard(), "categories": arena.CATS,
            "reputation": db.query("SELECT * FROM reputation ORDER BY category, score DESC"),
            "runs": db.query("SELECT id, name, results, created FROM experiments WHERE kind='arena' ORDER BY id DESC LIMIT 30")}


# ------------------------------------------------------------ knowledge
@route("GET", "/api/knowledge")
def kn(q, b):
    return {"docs": db.query("SELECT id, title, project, length(content) chars, ts FROM docs ORDER BY id DESC"),
            "memories": db.query("SELECT * FROM memories ORDER BY id DESC LIMIT 200"), "stats": knowledge.stats()}


@route("GET", "/api/knowledge/docs/(?P<did>\\d+)")
def kn_doc(q, b, did):
    return db.one("SELECT * FROM docs WHERE id=?", (did,))


@route("POST", "/api/knowledge/docs")
def kn_add(q, b):
    content = b.get("content")
    if b.get("file_b64"):
        content = workspace.extract_text(b.get("filename", "file.txt"), base64.b64decode(b["file_b64"]))
    if not content or not content.strip():
        raise HTTPError(400, "empty document")
    return {"id": knowledge.add_doc(b.get("title") or b.get("filename") or content[:40], content, b.get("project", "general"))}


@route("POST", "/api/knowledge/docs/(?P<did>\\d+)/delete")
def kn_del(q, b, did):
    if not b.get("confirm_token"):
        return control.request_confirmation("delete", f"doc {did}")
    control.confirm(b["confirm_token"], "delete", f"doc {did}")
    db.execute("DELETE FROM docs WHERE id=?", (did,))
    knowledge._index["dirty"] = True
    db.emit("knowledge", "doc_deleted", "user", doc_id=int(did))
    return {"ok": True}


@route("GET", "/api/knowledge/search")
def kn_search(q, b):
    return knowledge.search(q.get("q", ""), int(q.get("k", 8)), q.get("project"))


@route("GET", "/api/knowledge/graph")
def kn_graph(q, b):
    return knowledge.graph()


@route("POST", "/api/knowledge/memory")
def kn_mem(q, b):
    return {"id": knowledge.remember(b.get("kind", "memory"), b["subject"], b["content"], "user")}


# ------------------------------------------------------------ build / architect / systems
@route("POST", "/api/architect")
def arch(q, b):
    if not b.get("description", "").strip():
        raise HTTPError(400, "describe the AI you want")
    return {"job": compute.submit("architect", "architect: " + b["description"][:50], b)}


@route("GET", "/api/systems")
def systems(q, b):
    rows = db.query("SELECT id, name, description, approach, status, version, metrics, created FROM systems ORDER BY id DESC")
    for r in rows:
        m = r["metrics"] or {}
        r["summary"] = {k: m.get(k) for k in ("test", "baseline", "passed", "walk_forward", "oos_mean", "buy_hold_mean", "exam",
                                               "metric_name", "error")}
        r["log"] = (m.get("log") or [])[-1:]
        r.pop("metrics")
    return rows


@route("GET", "/api/systems/(?P<sid>\\d+)")
def system_detail(q, b, sid):
    s = db.one("SELECT * FROM systems WHERE id=?", (sid,))
    if s and s.get("package"):
        s["package"] = {k: v for k, v in s["package"].items() if k not in ("model", "vocab")}
    return s


@route("POST", "/api/systems/(?P<sid>\\d+)/predict")
def sys_predict(q, b, sid):
    return architect.predict(int(sid), b.get("input"))


@route("POST", "/api/systems/(?P<sid>\\d+)/finetune")
def sys_ft(q, b, sid):
    return lab.finetune_system(int(sid), b["csv"], int(b.get("epochs", 60)))


@route("POST", "/api/systems/(?P<sid>\\d+)/rollback")
def sys_rb(q, b, sid):
    return lab.rollback_system(int(sid))


# ------------------------------------------------------------ lab
@route("POST", "/api/lab/train")
def lab_train(q, b):
    return {"job": compute.submit("train", "train " + b["config"].get("dataset", ""), b, prefer_remote=b.get("remote", False))}


@route("POST", "/api/lab/sweep")
def lab_sweep(q, b):
    return {"job": compute.submit("sweep", f"sweep {b['variable']}", b)}


@route("POST", "/api/lab/reproduce/(?P<eid>\\d+)")
def lab_repro(q, b, eid):
    return lab.reproduce(int(eid))


@route("GET", "/api/lab/experiments")
def lab_exps(q, b):
    kind = q.get("kind")
    sql = "SELECT id, name, kind, config, seed, status, created, finished FROM experiments"
    return db.query(sql + (" WHERE kind=?" if kind else "") + " ORDER BY id DESC LIMIT 60", (kind,) if kind else ())


@route("GET", "/api/experiments/(?P<eid>\\d+)")
def exp(q, b, eid):
    return db.one("SELECT * FROM experiments WHERE id=?", (eid,))


@route("POST", "/api/builder/export")
def builder_export(q, b):
    return lab.export_llm_dataset(float(b.get("min_quality", 0.8)))


@route("POST", "/api/builder/openai")
def builder_openai(q, b):
    return lab.submit_openai_finetune(b["path"], b.get("base_model", "gpt-4.1-mini-2025-04-14"))


# ------------------------------------------------------------ market
@route("GET", "/api/market")
def mk_state(q, b):
    return market.LAB.state()


@route("POST", "/api/market/(?P<act>start|pause|resume|stop|step|reset|challenge|speed)")
def mk_ctrl(q, b, act):
    L = market.LAB
    if act == "start":
        if L.running:
            raise HTTPError(409, "already running")
        L.start(b.get("config") if b.get("config") else None)
    elif act == "pause":
        L.paused = True
        L.status = "paused"
    elif act == "resume":
        L.paused = False
        if not L.running and L.gen < int(L.cfg["generations"]):
            L.start(None)  # continue a stopped or restored evolution
        L.status = "running" if L.running else L.status
    elif act == "stop":
        L.running = False
    elif act == "step":
        if L.running and not L.paused:
            raise HTTPError(409, "pause first")
        L.step()
    elif act == "reset":
        L.running = False
        time.sleep(0.2)
        L.reset(b.get("config") or {})
    elif act == "challenge":
        L.pending.add(b["kind"])
        db.emit("market", "challenge_queued", "user", challenge=b["kind"])
    elif act == "speed":
        L.cfg["delay"] = max(0.0, float(b["delay"]))
    return {"status": L.status, "gen": L.gen}


@route("GET", "/api/market/bot/(?P<bid>\\d+)")
def mk_bot(q, b, bid):
    bot = market.LAB.bot(int(bid))
    if not bot:
        raise HTTPError(404, "bot not found (it may have been forgotten after 40 generations)")
    return bot


@route("GET", "/api/market/generation/(?P<g>\\d+)")
def mk_gen(q, b, g):
    h = market.LAB.history
    g = int(g)
    if g >= len(h):
        raise HTTPError(404, "no such generation")
    return h[g]


# ------------------------------------------------------------ compute
@route("GET", "/api/compute")
def comp(q, b):
    return compute.overview()


@route("GET", "/api/jobs/(?P<jid>\\d+)")
def job(q, b, jid):
    return db.one("SELECT * FROM jobs WHERE id=?", (jid,))


@route("POST", "/api/jobs/(?P<jid>\\d+)/cancel")
def job_cancel(q, b, jid):
    compute.cancel(jid)
    return {"ok": True}


@route("POST", "/api/compute/nodes")
def node_add(q, b):
    nid = db.insert("nodes", name=b["name"], kind=b.get("kind", "cloud"), specs=b.get("specs", {}),
                    cost_per_hour=float(b.get("cost_per_hour", 0)), status="registered (not connected)", last_seen=None)
    return {"id": nid}


@route("POST", "/api/worker/heartbeat")
def w_hb(q, b):
    return {"node_id": compute.worker_heartbeat(b["name"], b.get("specs", {}))}


@route("POST", "/api/worker/claim")
def w_claim(q, b):
    return {"job": compute.claim(int(b["node_id"]), b.get("kinds", ["train"]))}


@route("POST", "/api/worker/finish")
def w_finish(q, b):
    compute.finish_remote(int(b["job_id"]), b.get("result"), b.get("error"))
    return {"ok": True}


# ------------------------------------------------------------ economy & workspace
@route("GET", "/api/economy")
def econ(q, b):
    s = economy.summary()
    s["daily"] = db.query("SELECT CAST((ts/86400) AS INTEGER) day, SUM(cost) cost, COUNT(*) calls FROM ledger GROUP BY day ORDER BY day DESC LIMIT 30")
    return s


@route("GET", "/api/workspace/ta")
def ws_ta(q, b):
    return workspace.technical(q.get("asset", "GSPC"), int(q.get("last", 180)))


@route("GET", "/api/workspace/montecarlo")
def ws_mc(q, b):
    return workspace.monte_carlo(q.get("asset", "GSPC"), int(q.get("days", 252)))


@route("POST", "/api/workspace/import")
def ws_import(q, b):
    r = workspace.import_prices(b["name"], b["csv"])
    market.LAB.hist = market.load_history()
    return r


@route("POST", "/api/workspace/flashcards")
def ws_fc(q, b):
    return workspace.flashcards(int(b["doc_id"]))


@route("POST", "/api/workspace/image")
def ws_img(q, b):
    return workspace.analyze_image(base64.b64decode(b["file_b64"]))


@route("POST", "/api/workspace/document")
def ws_doc(q, b):
    return {"job": compute.submit("task", "document: " + b["prompt"][:40],
                                  {"title": "document", "text": "Write a well-structured document: " + b["prompt"]})}


# ------------------------------------------------------------ chat
@route("GET", "/api/chat/conversations")
def chat_convs(q, b):
    return chat.conversations()


@route("GET", "/api/chat/(?P<cid>\\d+)")
def chat_msgs(q, b, cid):
    return chat.messages(int(cid))


@route("POST", "/api/chat/send")
def chat_send(q, b):
    if not b.get("text", "").strip():
        raise HTTPError(400, "type a message")
    return {"job": compute.submit("chat", "chat: " + b["text"][:40], b)}


@route("POST", "/api/chat/(?P<cid>\\d+)/delete")
def chat_del(q, b, cid):
    if not b.get("confirm_token"):
        return control.request_confirmation("delete", f"chat {cid}")
    control.confirm(b["confirm_token"], "delete", f"chat {cid}")
    chat.delete(int(cid))
    return {"ok": True}


# ------------------------------------------------------------ web
@route("POST", "/api/web/search")
def web_search(q, b):
    return web.search(b["query"])


@route("POST", "/api/web/fetch")
def web_fetch(q, b):
    r = web.fetch(b["url"], save=b.get("save", True))
    r["text"] = r["text"][:3000]
    return r


@route("POST", "/api/web/research")
def web_research(q, b):
    return {"job": compute.submit("web_research", "research: " + b["question"][:40], b)}


# ------------------------------------------------------------ automations
@route("GET", "/api/automations")
def auto_list(q, b):
    return {"automations": db.query("SELECT * FROM automations ORDER BY id DESC"), "kinds": automations.KINDS,
            "templates": automations.TEMPLATES}


@route("POST", "/api/automations")
def auto_create(q, b):
    return {"id": automations.create(b["name"], b["kind"], b.get("payload"), b.get("schedule"), b.get("enabled", True))}


@route("POST", "/api/automations/(?P<aid>\\d+)/(?P<act>update|run|delete)")
def auto_act(q, b, aid, act):
    aid = int(aid)
    if act == "update":
        automations.update(aid, **b)
    elif act == "run":
        return {"job": automations.run_now(aid)}
    else:
        if not b.get("confirm_token"):
            return control.request_confirmation("delete", f"automation {aid}")
        control.confirm(b["confirm_token"], "delete", f"automation {aid}")
        automations.delete(aid)
    return {"ok": True}


# ------------------------------------------------------------ market data + hall of fame
@route("POST", "/api/market/download")
def mk_download(q, b):
    syms = b["symbols"] if isinstance(b["symbols"], list) else str(b["symbols"]).replace(" ", ",").split(",")
    return {"job": compute.submit("market_download", "prices: " + ",".join(syms)[:40], {**b, "symbols": syms})}


@route("POST", "/api/market/backtest")
def mk_backtest(q, b):
    dna = b.get("dna")
    if not dna and b.get("bot_id"):
        dna = market.LAB.bot(int(b["bot_id"]))["dna"]
    if not dna and b.get("hof_id"):
        dna = db.one("SELECT dna FROM hall_of_fame WHERE id=?", (b["hof_id"],))["dna"]
    return market.backtest(dna, b.get("asset", "GSPC"), float(b.get("cost_bps", 7)))


@route("GET", "/api/market/hall")
def mk_hall(q, b):
    return db.query("SELECT * FROM hall_of_fame ORDER BY oos DESC")


@route("POST", "/api/market/hall")
def mk_hall_add(q, b):
    return {"id": market.enshrine(market.LAB, int(b["bot_id"]), b.get("note", ""))}


@route("POST", "/api/market/hall/(?P<hid>\\d+)/export")
def mk_hall_export(q, b, hid):
    return market.export_system(int(hid))


# ------------------------------------------------------------ system health
@route("GET", "/api/system/info")
def sys_info(q, b):
    return system.info()


@route("POST", "/api/system/diagnostics")
def sys_diag(q, b):
    return {"job": compute.submit("diagnostics", "diagnostics", {})}


@route("GET", "/api/system/update")
def sys_update(q, b):
    return system.check_update()


@route("GET", "/api/system/logs")
def sys_logs(q, b):
    return system.logs(q.get("level"), int(q.get("limit", 200)))


@route("POST", "/api/system/logs")
def sys_log_client(q, b):
    db.log(b.get("level", "error"), "ui", b.get("message", "")[:1000], b.get("detail"))
    return {"ok": True}


@route("POST", "/api/system/restore")
def sys_restore(q, b):
    if not b.get("confirm_token"):
        return control.request_confirmation("restore", "all ATLAS data")
    control.confirm(b["confirm_token"], "restore", "all ATLAS data")
    return system.stage_restore(base64.b64decode(b["file_b64"]))


@route("GET", "/api/ollama")
def ollama_st(q, b):
    st = system.ollama_status()
    system.sync_ollama_models()
    return st


@route("POST", "/api/ollama/pull")
def ollama_pull(q, b):
    if not system.ollama_status()["running"]:
        raise HTTPError(400, "Ollama is not running. Install it from ollama.com and open it, then try again.")
    return {"job": compute.submit("ollama_pull", "download model " + b["model"], b)}


@route("GET", "/api/onboarding")
def onboarding(q, b):
    return {"done": db.setting("onboarded", False), "ollama": system.ollama_status()["running"],
            "models": [m["id"] for m in providers.available_models()], "docs": db.one("SELECT COUNT(*) n FROM docs")["n"],
            "systems": db.one("SELECT COUNT(*) n FROM systems")["n"], "tasks": db.one("SELECT COUNT(*) n FROM tasks")["n"],
            "chats": db.one("SELECT COUNT(*) n FROM conversations")["n"], "automations": db.one("SELECT COUNT(*) n FROM automations")["n"],
            "arena_runs": db.one("SELECT COUNT(*) n FROM experiments WHERE kind='arena'")["n"],
            "market_gens": market.LAB.gen + db.one("SELECT COUNT(*) n FROM experiments WHERE kind='market'")["n"]}


@route("POST", "/api/onboarding")
def onboarding_done(q, b):
    db.set_setting("onboarded", bool(b.get("done", True)))
    if "profile" in b:
        db.set_setting("profile", b["profile"])
    return {"ok": True}


@route("GET", "/api/search")
def global_search(q, b):
    """Command palette search across agents, systems, docs, chats, tasks."""
    t = f"%{q.get('q', '')}%"
    out = []
    for a in db.query("SELECT id, name FROM agents WHERE name LIKE ? LIMIT 5", (t,)):
        out.append({"type": "agent", "id": a["id"], "label": a["name"], "href": "#workforce"})
    for s_ in db.query("SELECT id, name FROM systems WHERE name LIKE ? LIMIT 5", (t,)):
        out.append({"type": "system", "id": s_["id"], "label": s_["name"], "href": "#build"})
    for d in db.query("SELECT id, title FROM docs WHERE title LIKE ? LIMIT 5", (t,)):
        out.append({"type": "doc", "id": d["id"], "label": d["title"], "href": "#knowledge"})
    for c in db.query("SELECT id, title FROM conversations WHERE title LIKE ? LIMIT 5", (t,)):
        out.append({"type": "chat", "id": c["id"], "label": c["title"], "href": "#chat"})
    for k in db.query("SELECT id, title FROM tasks WHERE title LIKE ? AND parent_id IS NULL LIMIT 5", (t,)):
        out.append({"type": "task", "id": k["id"], "label": k["title"], "href": "#workforce"})
    return out


@route("POST", "/api/system/quit")
def sys_quit(q, b):
    if QUIT_HOOK is None:
        return {"ok": False, "message": "Running from a terminal: press Ctrl+C there to stop ATLAS."}
    threading.Timer(0.5, QUIT_HOOK).start()
    return {"ok": True}


@route("GET", "/api/jobs")
def jobs_recent(q, b):
    return db.query("SELECT id, kind, title, status, progress, created, finished FROM jobs ORDER BY id DESC LIMIT 20")


# ------------------------------------------------------------ HTTP plumbing
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _authorised(self):
        if self.client_address[0] in ("127.0.0.1", "::1"):
            return True
        q = parse_qs(urlparse(self.path).query)
        return self.headers.get("x-atlas-token") == TOKEN or q.get("token", [None])[0] == TOKEN

    def _send(self, code, body, ctype="application/json", extra=None):
        data = body if isinstance(body, bytes) else json.dumps(body, default=str).encode()
        self.send_response(code)
        self.send_header("content-type", ctype)
        self.send_header("content-length", str(len(data)))
        self.send_header("cache-control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def _dispatch(self, method):
        u = urlparse(self.path)
        if u.path.startswith("/api/") and not self._authorised():
            return self._send(401, {"error": "access token required"})
        if u.path == "/api/stream":
            return self._stream()
        if u.path == "/api/system/backup":
            return self._send(200, system.backup(), "application/zip",
                              {"content-disposition": f'attachment; filename="atlas-backup-{time.strftime("%Y%m%d")}.zip"'})
        m = re.match(r"^/api/systems/(\d+)/download$", u.path)
        if m:
            data, fn = architect.zip_system(int(m.group(1)))
            return self._send(200, data, "application/zip", {"content-disposition": f'attachment; filename="{fn}"'})
        if u.path.startswith("/api/"):
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            body = {}
            if method == "POST":
                n = int(self.headers.get("content-length") or 0)
                if n > 30_000_000:
                    return self._send(413, {"error": "too large"})
                raw = self.rfile.read(n) if n else b""
                try:
                    body = json.loads(raw or b"{}")
                except ValueError:
                    return self._send(400, {"error": "invalid JSON"})
            for meth, rx, fn in ROUTES:
                mm = rx.match(u.path)
                if meth == method and mm:
                    try:
                        return self._send(200, fn(q, body, **mm.groupdict()))
                    except HTTPError as e:
                        return self._send(e.code, {"error": str(e)})
                    except (control.PermissionDenied, economy.BudgetExceeded) as e:
                        return self._send(403, {"error": str(e)})
                    except (providers.ProviderError, ValueError, KeyError) as e:
                        return self._send(400, {"error": f"{type(e).__name__}: {e}"})
                    except Exception as e:
                        traceback.print_exc()
                        db.log("error", "api", f"{method} {u.path}: {e}", traceback.format_exc()[-4000:])
                        return self._send(500, {"error": str(e)})
            return self._send(404, {"error": "no such endpoint"})
        return self._static(u.path)

    def _static(self, path):
        path = "/index.html" if path in ("/", "") else path
        full = os.path.normpath(os.path.join(WEB, path.lstrip("/")))
        if not full.startswith(WEB) or not os.path.isfile(full):
            return self._send(404, b"not found", "text/plain")
        ctype = {".html": "text/html", ".js": "application/javascript", ".css": "text/css", ".svg": "image/svg+xml",
                 ".json": "application/json", ".png": "image/png", ".webmanifest": "application/manifest+json"}.get(
            os.path.splitext(full)[1], "application/octet-stream")
        with open(full, "rb") as f:
            self._send(200, f.read(), ctype + ("; charset=utf-8" if ctype.startswith("text") or "javascript" in ctype else ""))

    def _stream(self):
        self.send_response(200)
        self.send_header("content-type", "text/event-stream")
        self.send_header("cache-control", "no-cache")
        self.send_header("connection", "keep-alive")
        self.end_headers()
        sub = db.subscribe()
        try:
            self.wfile.write(b": connected\n\n")
            self.wfile.flush()
            while True:
                try:
                    ev = sub.get(timeout=15)
                    self.wfile.write(f"data: {json.dumps(ev, default=str)}\n\n".encode())
                except Exception:
                    self.wfile.write(b": ping\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            db.unsubscribe(sub)


def serve(host="127.0.0.1", port=8600):
    os.makedirs(db.DATA_DIR, exist_ok=True)
    restored = system.apply_pending_restore()
    db.connect()
    if restored:
        db.log("info", "system", "backup restored at startup")
    compute.register_local()
    agents.ensure_seed()
    control.AUTOPILOT.ensure()
    market.init()
    automations.SCHEDULER.ensure()
    threading.Thread(target=system.sync_ollama_models, daemon=True).start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    db.emit("system", "started", "atlas", host=host, port=port)
    return httpd
