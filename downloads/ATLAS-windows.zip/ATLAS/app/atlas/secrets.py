"""Credential vault.

Keys are read from environment variables first, then from
~/.atlas/secrets.json (created with owner-only 0600 permissions).
Keys are never written to the database, logs or events, and the API
only ever reports whether a key is set, never its value.
"""
import json
import os
import stat

VAULT = os.path.join(os.path.expanduser("~"), ".atlas", "secrets.json")

KNOWN = {
    "ANTHROPIC_API_KEY": "Claude models (Anthropic)",
    "OPENAI_API_KEY": "GPT models (OpenAI)",
    "GEMINI_API_KEY": "Gemini models (Google)",
    "OLLAMA_HOST": "Local open-source models via Ollama (default http://localhost:11434)",
    "ALPACA_API_KEY": "Alpaca market data (paper only, optional)",
    "ALPACA_SECRET_KEY": "Alpaca market data secret (optional)",
}


def _load():
    try:
        with open(VAULT) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def get(name):
    return os.environ.get(name) or _load().get(name)


def set_secret(name, value):
    if name not in KNOWN:
        raise ValueError(f"unknown credential {name}")
    os.makedirs(os.path.dirname(VAULT), exist_ok=True)
    data = _load()
    if value:
        data[name] = value.strip()
    else:
        data.pop(name, None)
    with open(VAULT, "w") as f:
        json.dump(data, f)
    os.chmod(VAULT, stat.S_IRUSR | stat.S_IWUSR)


def status():
    return [{"name": k, "purpose": v, "set": bool(get(k)),
             "source": "env" if os.environ.get(k) else ("vault" if _load().get(k) else None)}
            for k, v in KNOWN.items()]
