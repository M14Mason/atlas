"""AI economy: spending limits, cost accounting and model routing.

Routing rule: pick the cheapest available model whose measured
reputation for this category clears the bar for the task's difficulty.
Reputation comes only from verified Arena results and graded tasks, so
cheap models earn more work by proving themselves.
"""
import time

from . import db

DEFAULTS = {"daily_limit_usd": 1.00, "per_call_limit_usd": 0.10, "require_approval_over_usd": 0.50}


class BudgetExceeded(Exception):
    pass


def limits():
    return {**DEFAULTS, **db.setting("limits", {})}


def spent_since(seconds):
    row = db.one("SELECT COALESCE(SUM(cost),0) c FROM ledger WHERE ts>?", (time.time() - seconds,))
    return row["c"]


def check_budget(estimate):
    lim = limits()
    if estimate > lim["per_call_limit_usd"]:
        raise BudgetExceeded(f"call estimate ${estimate:.4f} exceeds per-call limit ${lim['per_call_limit_usd']}")
    today = spent_since(86400)
    if today + estimate > lim["daily_limit_usd"]:
        db.emit("economy", "budget_block", estimate=estimate, spent_today=today)
        raise BudgetExceeded(f"daily limit ${lim['daily_limit_usd']} reached (spent ${today:.4f})")


def reputation(model, category="general"):
    """Evidence for THIS category only (falling back to 'general'). Skill in
    one category never counts as proof in another."""
    r = db.one("SELECT score, n FROM reputation WHERE model=? AND category=?", (model, category))
    if not r and category != "general":
        r = db.one("SELECT score, n FROM reputation WHERE model=? AND category='general'", (model,))
    if not r or r["score"] is None:
        return 0.5, 0  # unproven prior
    return r["score"], r["n"]


def record_result(model, category, score):
    """Exponential moving average so recent evidence counts more."""
    r = db.one("SELECT score, n FROM reputation WHERE model=? AND category=?", (model, category))
    if r:
        n = r["n"] + 1
        alpha = max(0.1, 1 / n)
        new = r["score"] * (1 - alpha) + score * alpha
        db.execute("UPDATE reputation SET score=?, n=? WHERE model=? AND category=?", (new, n, model, category))
    else:
        db.insert("reputation", model=model, category=category, score=score, n=1)
    db.emit("arena", "reputation_update", model, category=category, score=score)


DIFFICULTY_BAR = {"easy": 0.5, "medium": 0.7, "hard": 0.85}


def route(category="general", difficulty="medium", exclude_local=False):
    from . import providers
    models = [m for m in providers.available_models() if not (exclude_local and m["provider"] == "local")]
    if not models:
        raise RuntimeError("no models available")
    bar = DIFFICULTY_BAR.get(difficulty, 0.7)
    models.sort(key=lambda m: (m["in"] + m["out"], -m["tier"]))
    for m in models:
        score, n = reputation(m["id"], category)
        if n >= 3 and score >= bar:
            return m["id"], f"cheapest model with proven {category} score {score:.2f} >= {bar}"
    # nothing proven: use tier heuristic, skipping the local engine for open-ended work
    llms = [m for m in models if m["provider"] != "local"]
    if llms:
        want = {"easy": 1, "medium": 2, "hard": 3}.get(difficulty, 2)
        pick = min(llms, key=lambda m: (abs(m["tier"] - want), m["in"] + m["out"]))
        return pick["id"], f"no model proven for {category}; tier heuristic picked tier {pick['tier']}"
    return "atlas-local", "only the local engine is available"


def summary():
    by_model = db.query("SELECT model, COUNT(*) calls, SUM(cost) cost, SUM(tokens_in) tin, SUM(tokens_out) tout, "
                        "AVG(latency) latency FROM ledger GROUP BY model ORDER BY cost DESC")
    by_agent = db.query("""SELECT a.id, a.name, a.model, COUNT(t.id) tasks,
        SUM(CASE WHEN t.status='done' THEN 1 ELSE 0 END) ok, COALESCE(SUM(t.cost),0) cost, AVG(t.quality) quality
        FROM agents a LEFT JOIN tasks t ON t.agent_id=a.id GROUP BY a.id""")
    for a in by_agent:
        a["cost_per_success"] = (a["cost"] / a["ok"]) if a["ok"] else None
    return {"limits": limits(), "today": spent_since(86400), "week": spent_since(7 * 86400),
            "total": db.one("SELECT COALESCE(SUM(cost),0) c FROM ledger")["c"],
            "by_model": by_model, "by_agent": by_agent,
            "reputation": db.query("SELECT * FROM reputation ORDER BY category, score DESC")}
