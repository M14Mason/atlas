"""System health: diagnostics, self-tests, logs, backup and restore,
and the Ollama model manager (free local AI)."""
import json
import os
import platform
import shutil
import sqlite3
import tempfile
import time
import urllib.request
import zipfile

import numpy as np

from . import __version__, db, providers

# ------------------------------------------------------------ Ollama manager
RECOMMENDED = [
    {"name": "llama3.2", "size_gb": 2.0, "why": "Fast general model from Meta. Great default for agents and chat."},
    {"name": "qwen2.5", "size_gb": 4.7, "why": "Strong at math, code and following formats. Second council member."},
    {"name": "nomic-embed-text", "size_gb": 0.3, "why": "Embedding model: upgrades Knowledge search to understand meaning."},
    {"name": "llama3.2:1b", "size_gb": 1.3, "why": "Tiny and very fast. Good for cheap specialist agents."},
    {"name": "deepseek-r1:7b", "size_gb": 4.7, "why": "Reasoning model that thinks step by step. Slower."},
    {"name": "gemma3", "size_gb": 3.3, "why": "Google's open model. Adds variety to the council."},
]


def ollama_status():
    ol = providers.ADAPTERS["ollama"]
    providers.Ollama._checked = 0
    if not ol.available():
        return {"running": False, "host": ol.host(), "models": [], "recommended": RECOMMENDED,
                "install_url": "https://ollama.com/download"}
    tags = json.loads(urllib.request.urlopen(ol.host() + "/api/tags", timeout=3).read())
    models = [{"name": m["name"], "size_gb": round(m.get("size", 0) / 1e9, 2)} for m in tags.get("models", [])]
    have = {m["name"].split(":")[0] for m in models} | {m["name"] for m in models}
    for r in RECOMMENDED:
        r["installed"] = r["name"] in have
    return {"running": True, "host": ol.host(), "models": models, "recommended": RECOMMENDED}


def ollama_pull(name, progress=lambda p, **k: None):
    """Streams Ollama's pull progress into the job progress bar."""
    ol = providers.ADAPTERS["ollama"]
    req = urllib.request.Request(ol.host() + "/api/pull", data=json.dumps({"model": name, "stream": True}).encode(),
                                 headers={"content-type": "application/json"}, method="POST")
    last = None
    with urllib.request.urlopen(req, timeout=3600) as r:
        for line in r:
            if not line.strip():
                continue
            ev = json.loads(line)
            if ev.get("error"):
                raise RuntimeError(ev["error"])
            if ev.get("total"):
                progress(ev.get("completed", 0) / ev["total"], status=ev.get("status"))
            last = ev.get("status")
    _register_ollama_model(name)
    db.emit("system", "model_installed", "ollama", model=name)
    return {"model": name, "status": last}


def _register_ollama_model(name):
    """Make any pulled Ollama model selectable everywhere in ATLAS."""
    if name == "nomic-embed-text":
        return
    mid = "ollama:" + name
    if not any(m["id"] == mid for m in providers.MODELS):
        providers.MODELS.append({"id": mid, "provider": "ollama", "name": f"{name} (local)", "tier": 1, "in": 0, "out": 0})


def sync_ollama_models():
    try:
        st = ollama_status()
        for m in st["models"]:
            base = m["name"][:-7] if m["name"].endswith(":latest") else m["name"]
            if "embed" not in base:
                _register_ollama_model(base)
    except Exception:
        pass


# ------------------------------------------------------------ diagnostics
def diagnostics():
    """Runs real checks and returns pass/fail with details."""
    from . import economy, market, neural
    checks = []

    def check(name, fn):
        t = time.time()
        try:
            ok, detail = fn()
        except Exception as e:
            ok, detail = False, f"{type(e).__name__}: {e}"
        checks.append({"name": name, "ok": bool(ok), "detail": detail, "ms": round((time.time() - t) * 1000)})

    check("Database integrity", lambda: (db.one("PRAGMA quick_check")["quick_check"] == "ok", db.DB_PATH))

    def write_test():
        i = db.insert("settings", key=f"_diag_{time.time()}", value="1")
        db.execute("DELETE FROM settings WHERE key LIKE '_diag_%'")
        return True, "read/write ok"
    check("Database write", write_test)

    def disk():
        free = shutil.disk_usage(db.DATA_DIR).free / 1e9
        return free > 1, f"{free:.1f} GB free in data folder"
    check("Disk space", disk)
    check("numpy", lambda: (True, np.__version__))

    def grad():
        m = neural.MLP(3, [5], 2, "tanh", "classification", seed=1)
        X = np.random.default_rng(0).normal(size=(6, 3)); y = np.array([0, 1, 0, 1, 1, 0])
        out, c = m.forward(X); _, g = m.loss_grad(out, y); gW, _ = m.backward(c, g, 0)
        e = 1e-6; m.W[0][0, 0] += e; lp = m.loss_grad(m.forward(X)[0], y)[0]; m.W[0][0, 0] -= 2 * e
        lm = m.loss_grad(m.forward(X)[0], y)[0]; m.W[0][0, 0] += e
        err = abs((lp - lm) / (2 * e) - gW[0][0, 0])
        return err < 1e-6, f"backprop vs numerical gradient error {err:.1e}"
    check("Neural network math", grad)

    def leak():
        p, _ = market.synthetic(300, 2); q = p.copy(); q[200:] *= 2
        return np.allclose(market.features(p)[:200], market.features(q)[:200]), "indicators ignore future prices"
    check("Market Lab: no future leakage", leak)

    def data():
        h = market.load_history()
        return len(h) >= 5, f"{len(h)} price series: {', '.join(sorted(h))}"
    check("Market data", data)

    def train():
        r = neural.train({"dataset": "moons", "epochs": 40, "hidden": [16]})
        return r["metrics"]["val"] > 0.8, f"moons validation accuracy {r['metrics']['val']:.2f}"
    check("Training pipeline", train)

    def models():
        av = [m["id"] for m in providers.available_models()]
        llm = [m for m in av if m != "atlas-local"]
        return True, (f"{len(llm)} AI models online: {', '.join(llm)}" if llm else
                      "Only the Local Engine. Install Ollama (Settings) for free AI models.")
    check("AI models", models)
    check("Ollama", lambda: (True, "running, models: " + ", ".join(m["name"] for m in ollama_status()["models"])
                             if ollama_status()["running"] else "not running (optional, free)"))
    check("Spending guard", lambda: (economy.limits()["daily_limit_usd"] > 0,
                                     f"${economy.spent_since(86400):.4f} of ${economy.limits()['daily_limit_usd']} today"))
    errs = db.one("SELECT COUNT(*) n FROM logs WHERE level='error' AND ts>?", (time.time() - 86400,))["n"]
    checks.append({"name": "Errors in last 24h", "ok": errs == 0, "detail": f"{errs} logged", "ms": 0})
    return {"checks": checks, "passed": sum(c["ok"] for c in checks), "total": len(checks), "info": info()}


def info():
    return {"version": __version__, "python": platform.python_version(), "os": f"{platform.system()} {platform.release()}",
            "machine": platform.machine(), "data_dir": db.DATA_DIR, "app_dir": db.APP_DIR,
            "db_size_mb": round(os.path.getsize(db.DB_PATH) / 1e6, 2) if os.path.exists(db.DB_PATH) else 0}


def logs(level=None, limit=200):
    if level:
        return db.query("SELECT * FROM logs WHERE level=? ORDER BY id DESC LIMIT ?", (level, limit))
    return db.query("SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,))


# ------------------------------------------------------------ backup / restore
def backup():
    """Consistent snapshot of the database plus built systems, as zip bytes."""
    tmp = tempfile.mkdtemp()
    snap = os.path.join(tmp, "atlas.db")
    src = sqlite3.connect(db.DB_PATH)
    dst = sqlite3.connect(snap)
    src.backup(dst)
    dst.close(); src.close()
    path = os.path.join(tmp, "backup.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(snap, "atlas.db")
        z.writestr("atlas-backup.json", json.dumps({"version": __version__, "created": time.time()}))
        for sub in ("systems", "market_user"):
            base = os.path.join(db.DATA_DIR, sub)
            for root, _, files in os.walk(base):
                for fn in files:
                    full = os.path.join(root, fn)
                    z.write(full, os.path.relpath(full, db.DATA_DIR))
        lab = os.path.join(db.DATA_DIR, "market_lab.json")
        if os.path.exists(lab):
            z.write(lab, "market_lab.json")
    with open(path, "rb") as f:
        data = f.read()
    shutil.rmtree(tmp, ignore_errors=True)
    return data


def stage_restore(data):
    """Validates a backup and stages it. It is applied on the next start,
    after the current data is moved to a dated safety folder (not deleted)."""
    import io
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = z.namelist()
        if "atlas.db" not in names or "atlas-backup.json" not in names:
            raise ValueError("not an ATLAS backup")
        if any(n.startswith("/") or ".." in n for n in names):
            raise ValueError("unsafe paths in backup")
    with open(os.path.join(db.DATA_DIR, "restore_pending.zip"), "wb") as f:
        f.write(data)
    db.emit("system", "restore_staged", "user")
    return {"staged": True, "message": "Restart ATLAS to apply. Your current data will be kept in a 'before-restore' folder."}


def apply_pending_restore():
    pend = os.path.join(db.DATA_DIR, "restore_pending.zip")
    if not os.path.exists(pend):
        return False
    keep = os.path.join(db.DATA_DIR, "before-restore-" + time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(keep)
    for name in ("atlas.db", "atlas.db-wal", "atlas.db-shm", "market_lab.json", "systems", "market_user"):
        p = os.path.join(db.DATA_DIR, name)
        if os.path.exists(p):
            shutil.move(p, os.path.join(keep, name))
    with zipfile.ZipFile(pend) as z:
        z.extractall(db.DATA_DIR)
    os.remove(os.path.join(db.DATA_DIR, "atlas-backup.json"))
    os.remove(pend)
    return True


# ------------------------------------------------------------ update check
UPDATE_URL = "https://m14mason.github.io/atlas/version.json"
_update_cache = {"t": 0, "v": None}


def check_update():
    """Compares this version with the download site's version.json. Quiet on any failure."""
    if time.time() - _update_cache["t"] < 3600:
        return _update_cache["v"]
    _update_cache["t"] = time.time()
    try:
        v = json.loads(urllib.request.urlopen(db.setting("update_url", UPDATE_URL), timeout=4).read())
        cur = [int(x) for x in __version__.split(".")]
        new = [int(x) for x in str(v["version"]).split(".")]
        _update_cache["v"] = {"available": new > cur, "latest": v["version"], "current": __version__,
                              "url": UPDATE_URL.rsplit("/", 1)[0] + "/#download", "notes": v.get("notes", [])}
    except Exception:
        _update_cache["v"] = {"available": False, "current": __version__, "latest": None}
    return _update_cache["v"]
