"""Evolutionary Market Lab: artificial-life trading research.

VIRTUAL MONEY ONLY. Nothing here connects to a broker.

How a generation works
  1. The environment is a price window: either a slice of REAL history
     (replayed forward in time, one window per generation) or a
     SYNTHETIC market (regime-switching random walk with optional
     crashes). Every result is labelled with its data source.
  2. Each bot's DNA is a set of weights over 8 indicators plus trading
     genes (entry/exit thresholds, size, stop-loss, shorting).
  3. Indicators at day t use only prices up to day t. The position
     chosen at day t's close earns day t+1's return. That ordering is
     what prevents future-data leakage, and a unit test checks it.
  4. Costs: every change in position pays commission + slippage.
  5. Fitness = Sharpe - drawdown penalty + small return term.
  6. The bottom half dies. Elites survive. The rest of the next
     generation is born from tournament-selected parents by crossover
     and mutation. Parents are recorded so you can see family trees.
  7. Honesty check: the generation's champion is also scored on the
     NEXT, unseen window (out-of-sample). If in-sample keeps improving
     while out-of-sample does not, the population is overfitting.
"""
import csv
import json
import math
import os
import threading
import time

import numpy as np

from . import db

DATA = os.path.join(db.APP_DIR, "data", "market")          # bundled, read-only


def user_dir():
    d = os.path.join(db.DATA_DIR, "market_user")           # downloaded / imported prices
    os.makedirs(d, exist_ok=True)
    return d
FEATURES = ["mom5", "mom20", "mom60", "zscore20", "rsi14", "macd", "vol20", "trend50"]
SPECIES = {0: "Sprinter", 1: "Surfer", 2: "Navigator", 3: "Contrarian", 4: "Contrarian", 5: "Surfer",
           6: "Hedger", 7: "Navigator"}  # named by dominant gene


# ---------------------------------------------------------------- data
def load_history():
    out = {}
    path = os.path.join(DATA, "daily_2007_2016.csv")
    with open(path) as f:
        rows = list(csv.DictReader(f))
    dates = [r["Date"] for r in rows]
    for col in ("AAPL", "MSFT", "IBM", "SBUX", "GSPC"):
        out[col] = (np.array([float(r[col]) for r in rows]), dates)
    for folder in (DATA, user_dir()):  # user-imported / downloaded CSVs: Date,Close
        for fn in sorted(os.listdir(folder)):
            if fn.startswith("user_") and fn.endswith(".csv"):
                with open(os.path.join(folder, fn)) as f:
                    rr = [r for r in csv.DictReader(f) if r.get("Close")]
                if len(rr) > 130:
                    out[fn[5:-4].upper()] = (np.array([float(r["Close"]) for r in rr]), [r["Date"] for r in rr])
    return out


def synthetic(n, seed, crash=False, vol_mult=1.0):
    """Regime-switching returns with volatility clustering and fat tails."""
    rng = np.random.default_rng(seed)
    regimes = [(0.0006, 0.009), (-0.0008, 0.02), (0.0001, 0.006)]  # bull, bear, sideways (drift, vol)
    r, state, vol = np.zeros(n), 0, 0.01
    for t in range(n):
        if rng.random() < 0.01:
            state = rng.integers(0, 3)
        mu, base = regimes[state]
        vol = 0.94 * vol + 0.06 * base * vol_mult
        r[t] = mu + vol * rng.standard_t(4) / math.sqrt(2)
    crash_at = None
    if crash:
        crash_at = int(rng.integers(n // 4, 3 * n // 4))
        r[crash_at:crash_at + 6] = rng.normal(-0.06, 0.02, min(6, n - crash_at))
    return 100 * np.exp(np.cumsum(r)), crash_at


def features(p):
    """Causal indicators: row t only uses p[0..t]. Returns (T, 8), scaled to ~[-1, 1]."""
    T = len(p)
    lp = np.log(p)
    F = np.zeros((T, 8))

    def lag(x, k):
        y = np.full_like(x, np.nan)
        y[k:] = x[:-k]
        return y

    def roll(x, k, fn):
        y = np.full(T, np.nan)
        for t in range(k - 1, T):
            y[t] = fn(x[t - k + 1:t + 1])
        return y

    ret = np.r_[0, np.diff(lp)]
    F[:, 0] = (lp - lag(lp, 5)) * 10
    F[:, 1] = (lp - lag(lp, 20)) * 5
    F[:, 2] = (lp - lag(lp, 60)) * 3
    m20, s20 = roll(p, 20, np.mean), roll(p, 20, np.std)
    F[:, 3] = (p - m20) / (s20 + 1e-9) / 2
    up = np.maximum(ret, 0)
    dn = np.maximum(-ret, 0)
    au, ad = roll(up, 14, np.mean), roll(dn, 14, np.mean)
    F[:, 4] = (100 - 100 / (1 + au / (ad + 1e-12)) - 50) / 50
    def ema(x, k):
        a, y = 2 / (k + 1), np.zeros(T)
        y[0] = x[0]
        for t in range(1, T):
            y[t] = a * x[t] + (1 - a) * y[t - 1]
        return y
    macd = ema(p, 12) - ema(p, 26)
    F[:, 5] = (macd - ema(macd, 9)) / (p * 0.01)
    F[:, 6] = roll(ret, 20, np.std) * 40 - 0.5
    F[:, 7] = (p / roll(p, 50, np.mean) - 1) * 10
    F = np.nan_to_num(np.clip(F, -3, 3))
    F[:60] = 0  # warm-up: not enough history, bots sit out
    return F


# ---------------------------------------------------------------- simulation
GENES = 8 + 6  # weights + bias, enter, exit, size, stop, short


def random_dna(n, rng):
    dna = np.zeros((n, GENES))
    dna[:, :8] = rng.normal(0, 1, (n, 8))
    dna[:, 8] = rng.normal(0, 0.3, n)          # bias
    dna[:, 9] = rng.uniform(0.05, 0.8, n)      # enter threshold
    dna[:, 10] = rng.uniform(0.0, 0.5, n)      # exit threshold (fraction of enter)
    dna[:, 11] = rng.uniform(0.2, 1.0, n)      # position size
    dna[:, 12] = rng.uniform(0.02, 0.25, n)    # stop-loss
    dna[:, 13] = rng.uniform(0, 1, n)          # short gene (>0.7 allows shorting)
    return dna


def simulate(dna, prices, F, cost_bps=7.0, capital=10_000.0):
    """Vectorised over bots, stepped through time. Position at t earns r[t+1]."""
    N, T = len(dna), len(prices)
    sig = np.tanh(F @ dna[:, :8].T * 0.5 + dna[:, 8])  # (T, N)
    r = np.r_[np.diff(prices) / prices[:-1], 0]       # r[t] = return from t to t+1
    enter, exitf, size, stop = dna[:, 9], dna[:, 9] * dna[:, 10], dna[:, 11], dna[:, 12]
    can_short = dna[:, 13] > 0.7
    pos = np.zeros(N)
    entry_eq = np.ones(N)
    eq = np.ones(N)
    curve = np.ones((T, N))
    trades = np.zeros(N)
    cost = cost_bps / 1e4
    for t in range(T - 1):
        s = sig[t]
        target = np.where(s > enter, size, np.where((s < -enter) & can_short, -size, pos))
        target = np.where(np.abs(s) < exitf, 0, target)
        stopped = (pos != 0) & (eq / entry_eq - 1 < -stop)
        target = np.where(stopped, 0, target)
        change = np.abs(target - pos)
        opened = (pos == 0) & (target != 0)
        eq = eq * (1 - change * cost)
        trades += change > 0
        entry_eq = np.where(opened, eq, entry_eq)
        pos = target
        eq = eq * (1 + pos * r[t])
        curve[t + 1] = eq
    rets = np.diff(curve, axis=0) / curve[:-1]
    sharpe = rets.mean(0) / (rets.std(0) + 1e-12) * math.sqrt(252)
    peak = np.maximum.accumulate(curve, axis=0)
    mdd = ((peak - curve) / peak).max(0)
    total = curve[-1] - 1
    # consistency: share of 20-day blocks with positive return
    blocks = curve[::20]
    consist = (np.diff(blocks, axis=0) > 0).mean(0) if len(blocks) > 2 else np.zeros(N)
    fitness = sharpe - 2.0 * mdd + 0.3 * np.log1p(np.maximum(total, -0.99)) + 0.3 * consist
    fitness = np.where(trades == 0, -1.0, fitness)  # bots that never trade are not strategies
    return {"fitness": fitness, "sharpe": sharpe, "mdd": mdd, "total": total, "trades": trades,
            "consistency": consist, "final_capital": capital * curve[-1], "curve": curve}


def species_of(dna_row):
    return SPECIES[int(np.argmax(np.abs(dna_row[:8])))]


# ---------------------------------------------------------------- the lab
class Lab:
    def __init__(self):
        self.lock = threading.Lock()
        self.thread = None
        self.reset({})

    def reset(self, cfg):
        self.cfg = {"population": 500, "mode": "historical", "asset": "AAPL", "window": 250, "cost_bps": 7.0,
                    "mutation": 0.15, "elite": 0.05, "survival": 0.5, "seed": 42, "generations": 60, "delay": 0.3,
                    **cfg}
        self.rng = np.random.default_rng(int(self.cfg["seed"]))
        n = int(self.cfg["population"])
        self.dna = random_dna(n, self.rng)
        self.ids = np.arange(1, n + 1)
        self.next_id = n + 1
        self.bots = {int(i): {"id": int(i), "born": 0, "parents": [], "died": None, "history": []} for i in self.ids}
        self.gen = 0
        self.history = []
        self.running = False
        self.paused = False
        self.pending = set()
        self.status = "ready"
        self.last = None
        self.hist = load_history()

    # environment for a generation
    def environment(self, g, offset=0):
        c = self.cfg
        W = int(c["window"])
        challenge = None
        if c["mode"] == "historical":
            prices, dates = self.hist[c["asset"]]
            warm = 60
            span = W + warm
            maxstart = len(prices) - span - 1
            step = max(20, (maxstart) // max(1, int(c["generations"])))
            start = min(maxstart, ((g + offset) * step) % max(1, maxstart))
            p = prices[start:start + span]
            label = f"historical {c['asset']} {dates[start + warm]} to {dates[start + span - 1]}"
            return p, label, None, (start, start + span)
        crash = "crash" in self.pending or self.rng.random() < 0.15
        vol = 2.0 if "volatility" in self.pending else 1.0
        if "crash" in self.pending or vol > 1:
            challenge = sorted(self.pending & {"crash", "volatility"})
        seed = int(c["seed"]) * 1000 + g * 7 + offset
        p, crash_at = synthetic(W + 60, seed, crash, vol)
        return p, f"synthetic seed {seed}" + (f", crash day {crash_at - 60}" if crash_at else ""), challenge, None

    def step(self):
        c = self.cfg
        cost = c["cost_bps"] * (5 if "cost_shock" in self.pending else 1)
        p, label, challenge, rng_idx = self.environment(self.gen)
        F = features(p)
        res = simulate(self.dna, p[59:], F[59:], cost)
        fit = res["fitness"]
        order = np.argsort(-fit)
        champ = order[0]
        # out-of-sample check on the next window for the champion
        p2, label2, _, _ = self.environment(self.gen, offset=1)
        F2 = features(p2)
        oos = simulate(self.dna[[champ]], p2[59:], F2[59:], c["cost_bps"])
        bh = p[-1] / p[59] - 1
        n = len(self.dna)
        species = {}
        for i in range(n):
            s = species_of(self.dna[i])
            species[s] = species.get(s, 0) + 1
        for rank, i in enumerate(order):
            b = self.bots[int(self.ids[i])]
            b["history"].append({"gen": self.gen, "fitness": round(float(fit[i]), 4), "return": round(float(res["total"][i]), 4),
                                 "sharpe": round(float(res["sharpe"][i]), 3), "mdd": round(float(res["mdd"][i]), 4),
                                 "trades": int(res["trades"][i]), "rank": rank + 1})
            b["history"] = b["history"][-40:]
        stats = {"gen": self.gen, "env": label, "source": c["mode"], "challenge": challenge, "cost_bps": cost,
                 "best_fitness": float(fit[champ]), "median_fitness": float(np.median(fit)),
                 "best_return": float(res["total"][champ]), "median_return": float(np.median(res["total"])),
                 "buy_hold": float(bh), "best_sharpe": float(res["sharpe"][champ]), "best_mdd": float(res["mdd"][champ]),
                 "champion": int(self.ids[champ]), "oos_env": label2, "oos_return": float(oos["total"][0]),
                 "oos_sharpe": float(oos["sharpe"][0]), "species": species,
                 "pct_beat_bh": float((res["total"] > bh).mean()),
                 "fitness_hist": np.histogram(np.clip(fit, -3, 4), bins=24, range=(-3, 4))[0].tolist()}
        step_curve = max(1, len(p) // 150)
        self.last = {"stats": stats, "prices": (p[59:] / p[59]).tolist()[::step_curve],
                     "champion_curve": res["curve"][:, champ].tolist()[::step_curve],
                     "population": [{"id": int(self.ids[i]), "fitness": round(float(fit[i]), 3),
                                     "capital": round(float(res["final_capital"][i]), 0), "species": species_of(self.dna[i]),
                                     "age": self.gen - self.bots[int(self.ids[i])]["born"],
                                     "parents": self.bots[int(self.ids[i])]["parents"]} for i in range(n)]}
        self.history.append(stats)
        self.last_dna = {int(self.ids[i]): self.dna[i].copy() for i in range(n)}
        self._reproduce(order, fit)
        alive = set(int(i) for i in self.ids)
        for b in self.last["population"]:
            b["survived"] = b["id"] in alive
        self.pending.clear()
        if self.gen % 5 == 4:
            self.snapshot()
        db.emit("market", "generation", "market-lab", **{k: v for k, v in stats.items() if k != "fitness_hist"})
        self.gen += 1
        return stats

    def _reproduce(self, order, fit):
        c, rng = self.cfg, self.rng
        n = len(self.dna)
        n_elite = max(1, int(n * c["elite"]))
        n_keep = max(n_elite, int(n * c["survival"]))
        survivors = order[:n_keep]
        for i in order[n_keep:]:
            self.bots[int(self.ids[i])]["died"] = self.gen
        new_dna, new_ids = [self.dna[survivors]], [self.ids[survivors]]
        children = []
        for _ in range(n - n_keep):
            pa = max(rng.choice(survivors, 3), key=lambda i: fit[i])  # tournament
            pb = max(rng.choice(survivors, 3), key=lambda i: fit[i])
            mask = rng.random(GENES) < 0.5
            child = np.where(mask, self.dna[pa], self.dna[pb])
            mut = rng.random(GENES) < c["mutation"]
            child = child + mut * rng.normal(0, 0.3, GENES)
            child[9] = np.clip(child[9], 0.02, 0.95)
            child[10] = np.clip(child[10], 0, 0.9)
            child[11] = np.clip(child[11], 0.05, 1.0)
            child[12] = np.clip(child[12], 0.01, 0.4)
            cid = self.next_id
            self.next_id += 1
            self.bots[cid] = {"id": cid, "born": self.gen + 1, "parents": [int(self.ids[pa]), int(self.ids[pb])],
                              "died": None, "history": []}
            children.append(child)
            new_ids.append(np.array([cid]))
        if children:
            new_dna.append(np.array(children))
        self.dna = np.vstack(new_dna)
        self.ids = np.concatenate(new_ids)
        # forget long-dead bots with no living descendants beyond 40 generations to bound memory
        if len(self.bots) > 40 * n:
            cutoff = self.gen - 40
            self.bots = {k: v for k, v in self.bots.items() if v["died"] is None or v["died"] > cutoff}

    # ---- control
    def start(self, cfg=None):
        with self.lock:
            if self.running:
                return
            if cfg:
                self.reset(cfg)
            self.running, self.paused, self.status = True, False, "running"
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()

    def _loop(self):
        try:
            while self.running and self.gen < int(self.cfg["generations"]):
                if self.paused:
                    time.sleep(0.1)
                    continue
                self.step()
                time.sleep(float(self.cfg["delay"]))
            self.status = "finished" if self.gen >= int(self.cfg["generations"]) else "stopped"
            self.snapshot()
            if self.status == "finished":
                self.save_run()
        except Exception as e:
            self.status = f"error: {e}"
            db.emit("market", "error", "market-lab", error=str(e))
        finally:
            self.running = False

    def save_run(self):
        db.insert("experiments", name=f"market {self.cfg['mode']} {self.cfg.get('asset','')}", kind="market",
                  config=self.cfg, seed=int(self.cfg["seed"]), status="done",
                  results={"history": [{k: v for k, v in h.items() if k != "fitness_hist"} for h in self.history]},
                  created=time.time(), finished=time.time())

    # ---- persistence: the lab survives restarts
    def _path(self):
        return os.path.join(db.DATA_DIR, "market_lab.json")

    def snapshot(self):
        try:
            alive = set(int(i) for i in self.ids)
            bots = {k: (v if k in alive else {**v, "history": v["history"][-3:]}) for k, v in self.bots.items()}
            state = {"cfg": self.cfg, "gen": self.gen, "history": self.history[-300:], "next_id": self.next_id,
                     "ids": self.ids.tolist(), "dna": self.dna.round(6).tolist(), "bots": bots, "last": self.last,
                     "rng": self.rng.bit_generator.state}
            tmp = self._path() + ".tmp"
            with open(tmp, "w") as f:
                json.dump(state, f, default=float)
            os.replace(tmp, self._path())
        except Exception as e:
            db.emit("market", "error", "market-lab", error=f"snapshot failed: {e}")

    def restore(self):
        try:
            with open(self._path()) as f:
                st = json.load(f)
        except (OSError, ValueError):
            return False
        self.cfg, self.gen, self.history, self.next_id = st["cfg"], st["gen"], st["history"], st["next_id"]
        self.ids, self.dna = np.array(st["ids"]), np.array(st["dna"])
        self.bots = {int(k): v for k, v in st["bots"].items()}
        self.last = st["last"]
        self.rng = np.random.default_rng()
        self.rng.bit_generator.state = st["rng"]
        self.status = "restored (paused)" if self.gen < int(self.cfg["generations"]) else "finished"
        self.paused = False
        return True

    def bot(self, bid):
        b = self.bots.get(int(bid))
        if not b:
            return None
        out = dict(b)
        alive = np.where(self.ids == int(bid))[0]
        d = self.dna[alive[0]] if len(alive) else getattr(self, "last_dna", {}).get(int(bid))
        if d is not None:
            out["dna"] = {**{f: round(float(d[i]), 3) for i, f in enumerate(FEATURES)}, "bias": round(float(d[8]), 3),
                          "enter": round(float(d[9]), 3), "exit_frac": round(float(d[10]), 3), "size": round(float(d[11]), 3),
                          "stop_loss": round(float(d[12]), 3), "can_short": bool(d[13] > 0.7)}
            out["species"] = species_of(d)
        out["alive"] = bool(len(alive))
        out["family"] = self.family(int(bid))
        return out

    def family(self, bid, depth=4):
        def up(i, d):
            b = self.bots.get(i)
            if not b or d == 0:
                return {"id": i}
            return {"id": i, "born": b["born"], "parents": [up(p, d - 1) for p in b["parents"]]}
        kids = [k for k, v in self.bots.items() if bid in v["parents"]][:20]
        return {"ancestors": up(bid, depth), "children": kids}

    def state(self):
        return {"cfg": self.cfg, "gen": self.gen, "status": self.status, "paused": self.paused,
                "assets": sorted(self.hist), "history": self.history[-200:], "last": self.last}


def backtest(dna_dict, asset, cost_bps=7.0):
    """Run one strategy over an asset's whole history (any asset, not just
    the one it evolved on). Same causal rules as evolution."""
    prices, dates = load_history()[asset]
    row = np.zeros(GENES)
    row[:8] = [dna_dict[f] for f in FEATURES]
    row[8:13] = [dna_dict["bias"], dna_dict["enter"], dna_dict["exit_frac"], dna_dict["size"], dna_dict["stop_loss"]]
    row[13] = 1.0 if dna_dict["can_short"] else 0.0
    F = features(prices)
    r = simulate(row[None, :], prices[59:], F[59:], cost_bps)
    curve = r["curve"][:, 0]
    bh = prices[59:] / prices[59]
    step = max(1, len(curve) // 300)
    yrs = len(curve) / 252
    return {"asset": asset, "from": dates[59], "to": dates[-1], "dates": dates[59::step],
            "curve": curve[::step].round(4).tolist(), "buy_hold": bh[::step].round(4).tolist(),
            "total": float(curve[-1] - 1), "buy_hold_total": float(bh[-1] - 1),
            "cagr": float(curve[-1] ** (1 / yrs) - 1), "bh_cagr": float(bh[-1] ** (1 / yrs) - 1),
            "sharpe": float(r["sharpe"][0]), "max_dd": float(r["mdd"][0]), "trades": int(r["trades"][0])}


def enshrine(lab, bot_id, note=""):
    """Save a bot to the Hall of Fame with its out-of-sample record."""
    b = lab.bot(bot_id)
    if not b or not b.get("dna"):
        raise ValueError("bot DNA not available")
    h = next((x for x in reversed(lab.history) if x["champion"] == bot_id), lab.history[-1] if lab.history else {})
    hid = db.insert("hall_of_fame", bot_id=bot_id, asset=lab.cfg.get("asset"), mode=lab.cfg.get("mode"), gen=h.get("gen"),
                    in_sample=h.get("best_return"), oos=h.get("oos_return"), buy_hold=h.get("buy_hold"), dna=b["dna"],
                    note=note, ts=time.time())
    db.emit("market", "hall_of_fame", "market-lab", bot_id=bot_id, id=hid)
    return hid


def export_system(hof_id):
    """Turn a Hall of Fame strategy into an ATLAS system (callable, downloadable)."""
    from . import architect
    h = db.one("SELECT * FROM hall_of_fame WHERE id=?", (hof_id,))
    bt = backtest(h["dna"], h["asset"] if h["asset"] in load_history() else "GSPC")
    passed = bt["total"] > bt["buy_hold_total"]
    pkg = {"type": "strategy", "dna": h["dna"], "asset": bt["asset"], "features": FEATURES}
    metrics = {"oos_mean": h["oos"], "buy_hold_mean": h["buy_hold"], "full_history_total": bt["total"],
               "full_history_buy_hold": bt["buy_hold_total"], "passed": passed,
               "log": [{"stage": "package", "msg": f"Exported Hall of Fame bot #{h['bot_id']}. Full-history backtest "
                        f"{bt['total']:.1%} vs buy & hold {bt['buy_hold_total']:.1%}.", "ts": time.time()}]}
    sid = db.insert("systems", name=f"Evolved strategy #{h['bot_id']} ({bt['asset']})", description="Exported from the Market Lab Hall of Fame",
                    approach="strategy-evolved", status="deployed" if passed else "failed-test", version=1, package=pkg,
                    metrics=metrics, created=time.time())
    architect.package(sid, f"strategy-{h['bot_id']}", "Market Lab export", {"package": pkg, "metrics": metrics,
                      "approach": "strategy-evolved", "passed": passed})
    return {"system_id": sid, "passed": passed, **{k: bt[k] for k in ("total", "buy_hold_total")}}


LAB = Lab()


def init():
    """Called at server start, after the database is connected."""
    LAB.restore()
