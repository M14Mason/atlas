"""Automations: recurring jobs ATLAS runs on its own while it is open.

Schedules: {"every_minutes": N} or {"daily_at": "HH:MM"} (local time).
Kinds map to existing job handlers, so an automation is just a
scheduled compute.submit(). Every run is logged with its result.
"""
import threading
import time
from datetime import datetime, timedelta

from . import compute, db

KINDS = {
    "task": "Give a task to the workforce (payload: text)",
    "council": "Ask the council a recurring question (payload: question)",
    "arena": "Re-benchmark a model (payload: model, category, n)",
    "market_update": "Download the latest prices for every ticker you've downloaded",
    "market_evolve": "Run a Market Lab evolution (payload: config)",
    "autopilot": "Run one self-improvement cycle",
    "web_digest": "Research a topic on the web and file a dated summary in Knowledge (payload: topic)",
}

TEMPLATES = [
    {"name": "Morning market data refresh", "kind": "market_update", "payload": {}, "schedule": {"daily_at": "06:30"}},
    {"name": "Weekly evolution on S&P 500", "kind": "market_evolve", "schedule": {"every_minutes": 10080},
     "payload": {"config": {"mode": "historical", "asset": "GSPC", "population": 500, "generations": 60, "delay": 0}}},
    {"name": "Autopilot every 2 hours", "kind": "autopilot", "payload": {}, "schedule": {"every_minutes": 120}},
    {"name": "Daily AI news digest", "kind": "web_digest", "payload": {"topic": "latest AI model releases"},
     "schedule": {"daily_at": "07:00"}},
]


def next_run(schedule, after=None):
    after = after or time.time()
    if "every_minutes" in schedule:
        return after + max(1, float(schedule["every_minutes"])) * 60
    if "daily_at" in schedule:
        hh, mm = [int(x) for x in schedule["daily_at"].split(":")]
        now = datetime.fromtimestamp(after)
        t = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
        if t.timestamp() <= after:
            t += timedelta(days=1)
        return t.timestamp()
    raise ValueError("schedule needs every_minutes or daily_at")


def create(name, kind, payload=None, schedule=None, enabled=True):
    if kind not in KINDS:
        raise ValueError(f"unknown kind {kind}")
    schedule = schedule or {"every_minutes": 60}
    aid = db.insert("automations", name=name, kind=kind, payload=payload or {}, schedule=schedule, enabled=int(enabled),
                    last_run=None, next_run=next_run(schedule), last_status="never run", runs=0, created=time.time())
    db.emit("automations", "created", "user", id=aid, name=name, kind=kind)
    return aid


def update(aid, **f):
    a = db.one("SELECT * FROM automations WHERE id=?", (aid,))
    if "schedule" in f:
        f["next_run"] = next_run(f["schedule"])
    if "enabled" in f:
        f["enabled"] = int(bool(f["enabled"]))
        if f["enabled"] and not a["enabled"]:
            f["next_run"] = next_run(f.get("schedule", a["schedule"]))
    db.update("automations", aid, **{k: v for k, v in f.items() if k in ("name", "payload", "schedule", "enabled", "next_run")})


def delete(aid):
    db.execute("DELETE FROM automations WHERE id=?", (aid,))


def run_now(aid):
    a = db.one("SELECT * FROM automations WHERE id=?", (aid,))
    jid = compute.submit("automation", f"automation: {a['name']}", {"automation_id": aid})
    db.update("automations", aid, last_run=time.time(), next_run=next_run(a["schedule"]), runs=(a["runs"] or 0) + 1,
              last_status=f"running (job {jid})")
    db.emit("automations", "triggered", "scheduler", id=aid, name=a["name"], job=jid)
    return jid


@compute.handler("automation")
def _run(p, progress):
    from . import agents, arena, control, council, market, marketdata, web, knowledge
    a = db.one("SELECT * FROM automations WHERE id=?", (p["automation_id"],))
    k, pl = a["kind"], a["payload"] or {}
    try:
        if k == "task":
            r = agents.run_task(a["name"], pl["text"])
            res = {"task_id": r["task_id"], "quality": r["quality"]}
        elif k == "council":
            r = council.deliberate(pl["question"])
            res = {"session": r["session"], "winner": r.get("winner")}
        elif k == "arena":
            res = arena.run_model(pl["model"], pl.get("category", "general"), int(pl.get("n", 3)))
        elif k == "market_update":
            res = marketdata.refresh_all()
        elif k == "market_evolve":
            if market.LAB.running:
                raise RuntimeError("Market Lab is busy")
            market.LAB.start(pl.get("config") or {})
            res = {"started": True}
        elif k == "autopilot":
            res = {"actions": control.AUTOPILOT.cycle()}
        elif k == "web_digest":
            r = web.research(pl["topic"], pages=3)
            body = f"Topic: {pl['topic']}\nDate: {time.strftime('%Y-%m-%d')}\n\n" + r["context"]
            did = knowledge.add_doc(f"Digest: {pl['topic']} {time.strftime('%Y-%m-%d')}", body, "digests")
            res = {"doc_id": did, "sources": len(r["sources"])}
        else:
            raise ValueError(k)
        db.update("automations", a["id"], last_status="ok")
        return res
    except Exception as e:
        db.update("automations", a["id"], last_status=f"error: {e}"[:300])
        db.log("error", "automation", f"{a['name']}: {e}")
        raise


class Scheduler:
    def __init__(self):
        self.thread = None

    def ensure(self):
        if not self.thread or not self.thread.is_alive():
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()

    def tick(self):
        for a in db.query("SELECT * FROM automations WHERE enabled=1 AND next_run<=?", (time.time(),)):
            try:
                run_now(a["id"])
            except Exception as e:
                db.log("error", "scheduler", f"could not start {a['name']}: {e}")

    def _loop(self):
        while True:
            try:
                self.tick()
            except Exception as e:
                db.log("error", "scheduler", str(e))
            time.sleep(20)


SCHEDULER = Scheduler()
