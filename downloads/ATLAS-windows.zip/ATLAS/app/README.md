# PROJECT ATLAS

An AI ecosystem command center: model council, self-organizing agent workforce,
AI Architect, from-scratch neural networks, research lab, evolutionary market lab,
knowledge universe, compute center and AI economy. Runs locally. No cloud bill.

## Install as an app (easiest)
- **Mac:** unzip `ATLAS-mac.zip`, drag ATLAS.app to Applications, open it. First open: System Settings > Privacy & Security > Open Anyway (the app is unsigned). First launch sets up Python in about a minute.
- **Windows:** extract `ATLAS-windows.zip`, run `ATLAS.exe`. SmartScreen: More info > Run anyway. Python is bundled.
- Build both yourself: `packaging/build.sh` (outputs to `dist/`).

## Start from source (Mac)
```bash
cd atlas
python3 -m pip install numpy pillow pypdf      # pillow/pypdf optional
python3 run.py                                  # opens http://localhost:8600
```
Phone on the same Wi-Fi: `python3 run.py --lan` and open the printed link (keep it private).

## Connect AI models
- **Free, local (recommended first):** install Ollama from ollama.com, then `ollama pull llama3.2` and `ollama pull qwen2.5`. ATLAS detects it in ~30s. Two local models are enough for the Council.
- **Paid:** Settings → Credentials → paste an Anthropic / OpenAI / Gemini key. Keep the daily limit low ($1 default).

## What works without any model
Architect (tabular, text, forecast, strategy, pattern systems), Ground-Up AI, Research Lab,
Market Lab, Knowledge Universe, Arena (local engine), Workforce math/retrieval tasks, Workspace finance/photo tools.

## Tests
```bash
python3 tests/test_core.py        # math + leakage + reproducibility invariants
python3 tests/test_api.py         # end-to-end through HTTP (temp data dir)
python3 tests/fake_ollama.py &    # optional: fake LLM so council/delegation paths run
OLLAMA_HOST=http://127.0.0.1:11500 python3 tests/test_api.py --fake-llm
```

## What's in v0.2
Ask ATLAS chat (knowledge + web sources), web research for agents, peer review, automations (scheduled jobs),
live market data downloads (Alpaca / Yahoo / Stooq), Market Lab Hall of Fame + cross-asset backtests + export as AI system,
one-click free model downloads (Ollama), setup wizard, ⌘K command palette, job tray, System Health (diagnostics,
error log, debug report, backup/restore), desktop notifications, Mac and Windows apps.

## Layout
`atlas/` backend modules (one per department) · `web/` UI (no build step) · `data/` database, market data, built systems ·
`worker.py` remote compute worker · `RESUME.md` build state and next steps.
