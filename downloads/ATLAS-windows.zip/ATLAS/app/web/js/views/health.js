import { api, fileToB64, fmt, h, icon, learn, put, safe, toast, waitJob } from "../core.js";

export async function render(root) {
  const info = await api("/api/system/info");
  const checks = h("div"); const logBox = h("div"); const summary = h("div");
  const run = h("button", { class: "btn primary" }, icon("pulse"), " Run all diagnostics");
  run.onclick = () => safe(async () => {
    run.disabled = true; checks.innerHTML = ""; checks.append(h("div", { class: "typing" }, h("span"), h("span"), h("span")));
    try {
      const r = await waitJob((await api("/api/system/diagnostics", {})).job);
      checks.innerHTML = "";
      summary.innerHTML = "";
      summary.append(h("div", { class: "kpi" }, h("div", { class: "v " + (r.passed === r.total ? "green" : "amber") }, `${r.passed}/${r.total}`), h("div", { class: "l" }, "checks passed")));
      r.checks.forEach((c) => checks.append(h("div", { class: "check-row" }, h("span", { class: c.ok ? "ok" : "bad" }, icon(c.ok ? "check" : "x")),
        h("div", {}, h("b", {}, c.name), h("div", { class: "faint", style: { fontSize: "12px" } }, c.detail)), h("span", { class: "faint mono" }, c.ms + " ms"))));
    } finally { run.disabled = false; }
  });
  const lvl = h("select", {}, h("option", { value: "" }, "All levels"), h("option", { value: "error" }, "Errors"), h("option", { value: "warn" }, "Warnings"));
  async function loadLogs() {
    const l = await api("/api/system/logs" + (lvl.value ? "?level=" + lvl.value : ""));
    logBox.innerHTML = "";
    if (!l.length) return logBox.append(h("div", { class: "empty" }, "No log entries. That's good."));
    logBox.append(h("div", { class: "feed", style: { maxHeight: "420px" } }, l.map((x) => h("details", { class: "ev", style: { display: "block" } },
      h("summary", {}, h("span", { class: "t" }, new Date(x.ts * 1000).toLocaleString()), " ", h("span", { class: x.level === "error" ? "red" : x.level === "warn" ? "amber" : "dim" }, x.level.toUpperCase()), " ",
        h("span", { class: "cyan" }, x.source), " ", x.message), x.detail ? h("pre", {}, typeof x.detail === "string" ? x.detail : JSON.stringify(x.detail, null, 1)) : null))));
  }
  lvl.onchange = loadLogs;
  const copy = h("button", { class: "btn" }, "Copy debug report");
  copy.onclick = () => safe(async () => {
    const l = await api("/api/system/logs?level=error&limit=30");
    const txt = `ATLAS debug report\n${JSON.stringify(info, null, 1)}\n\nRecent errors:\n` + l.map((x) => `${new Date(x.ts * 1000).toISOString()} [${x.source}] ${x.message}\n${typeof x.detail === "string" ? x.detail.slice(-800) : ""}`).join("\n\n");
    await navigator.clipboard.writeText(txt); toast("Debug report copied. Paste it to Claude to get help.");
  });
  const restoreIn = h("input", { type: "file", accept: ".zip" });
  const restore = h("button", { class: "btn danger" }, "Restore from backup");
  restore.onclick = () => safe(async () => {
    if (!restoreIn.files[0]) throw new Error("choose a backup .zip first");
    const c = await api("/api/system/restore", {});
    if (!confirm("Restore replaces ALL current ATLAS data on next restart. Your current data is kept in a 'before-restore' folder. Continue?")) return;
    if (!confirm("Second confirmation: replace current data with this backup?")) return;
    const r = await api("/api/system/restore", { confirm_token: c.confirm_token, file_b64: await fileToB64(restoreIn.files[0]) });
    toast(r.message);
  });
  put(root, h("div", { class: "hero" }, h("h1", {}, icon("pulse", 22), "System Health"), h("div", { class: "row" }, copy, run)),
    h("p", { class: "sub" }, "Self-tests that check ATLAS's real math and data, the error log, and backups. If something breaks, run diagnostics and copy the debug report."),
    learn("what the diagnostics actually test", "They re-run real checks: database integrity, the neural network's gradients against numerical math, that Market Lab indicators can't see future prices, that a model can still train, which AI models are reachable, and how much of today's budget is used."),
    h("div", { class: "grid g3" },
      h("div", { class: "card span2" }, h("div", { class: "row between" }, h("h3", {}, "Diagnostics"), summary), checks.childElementCount ? checks : (checks.append(h("div", { class: "empty" }, "Press Run all diagnostics.")), checks)),
      h("div", { class: "card" }, h("h3", {}, "This installation"), h("table", {}, h("tbody", {}, [["Version", info.version], ["Python", info.python], ["System", `${info.os} (${info.machine})`], ["Database size", info.db_size_mb + " MB"], ["Data folder", info.data_dir]].map(([k, v]) => h("tr", {}, h("td", { class: "dim" }, k), h("td", { class: "mono", style: { wordBreak: "break-all" } }, v))))),
        h("h3", { style: { marginTop: "16px" } }, "Backup"), h("a", { class: "btn", href: "/api/system/backup" }, icon("download"), " Download full backup"),
        h("p", { class: "faint", style: { fontSize: "12px" } }, "Includes agents, chats, knowledge, experiments, built AIs and Market Lab state."),
        h("h3", { style: { marginTop: "12px" } }, "Restore"), h("div", { class: "col" }, restoreIn, restore))),
    h("div", { class: "card", style: { marginTop: "14px" } }, h("div", { class: "row between" }, h("h3", {}, "Error & event log"), h("div", { class: "row" }, lvl, h("button", { class: "btn sm", onclick: loadLogs }, "Refresh"))), logBox));
  loadLogs();
  run.click();
}
