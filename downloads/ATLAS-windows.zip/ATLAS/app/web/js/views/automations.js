import { api, bus, emptyState, fmt, h, icon, learn, put, safe, tag, toast } from "../core.js";

export async function render(root) {
  const box = h("div");
  const name = h("input", { placeholder: "Name" });
  const kind = h("select", {});
  const payload = h("textarea", { style: { minHeight: "60px" }, placeholder: "Details, e.g. the task text or question" });
  const every = h("select", {}, [["daily", "Every day at…"], ["15", "Every 15 minutes"], ["60", "Every hour"], ["360", "Every 6 hours"], ["1440", "Every day (from now)"], ["10080", "Every week"]].map(([v, t]) => h("option", { value: v }, t)));
  const at = h("input", { type: "time", value: "07:00" });
  const add = h("button", { class: "btn primary" }, icon("plus"), " Create automation");
  const FIELD = { task: "text", council: "question", web_digest: "topic", arena: "model" };
  add.onclick = () => safe(async () => {
    if (!name.value) throw new Error("name it");
    const k = kind.value; const p = {};
    if (FIELD[k]) { if (!payload.value.trim()) throw new Error("add the details"); p[FIELD[k]] = payload.value.trim(); }
    if (k === "arena") p.category = "general";
    const schedule = every.value === "daily" ? { daily_at: at.value } : { every_minutes: +every.value };
    await api("/api/automations", { name: name.value, kind: k, payload: p, schedule }); name.value = payload.value = ""; load();
  }, "Automation created");
  const sched = (s) => s.daily_at ? `daily at ${s.daily_at}` : s.every_minutes >= 1440 ? `every ${s.every_minutes / 1440} day(s)` : s.every_minutes >= 60 ? `every ${s.every_minutes / 60} h` : `every ${s.every_minutes} min`;
  async function load() {
    const d = await api("/api/automations");
    if (!kind.options.length) Object.entries(d.kinds).forEach(([k, v]) => kind.append(h("option", { value: k }, v)));
    box.innerHTML = "";
    put(box, h("h3", {}, "One-click templates"), h("div", { class: "row", style: { marginBottom: "16px" } }, d.templates.map((t) =>
      h("button", { class: "btn sm", onclick: () => safe(async () => { await api("/api/automations", t); load(); }, "Added: " + t.name) }, icon("plus"), " " + t.name))),
      d.automations.length ? h("table", {}, h("thead", {}, h("tr", {}, ["", "Automation", "Kind", "Schedule", "Next run", "Last result", "Runs", ""].map((c) => h("th", {}, c)))),
        h("tbody", {}, d.automations.map((a) => h("tr", {},
          h("td", {}, h("input", { type: "checkbox", checked: !!a.enabled, title: "Enabled", onchange: (e) => safe(() => api(`/api/automations/${a.id}/update`, { enabled: e.target.checked }), e.target.checked ? "Enabled" : "Paused") })),
          h("td", {}, h("b", {}, a.name)), h("td", { class: "mono" }, a.kind), h("td", {}, sched(a.schedule)),
          h("td", { class: "dim" }, a.enabled ? new Date(a.next_run * 1000).toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit" }) : "paused"),
          h("td", {}, tag(a.last_status?.startsWith("error") ? "error" : a.last_status === "ok" ? "ok" : a.last_status || "-", a.last_status?.startsWith("error") ? "error" : a.last_status === "ok" ? "ok" : "x"), a.last_status?.startsWith("error") ? h("div", { class: "faint", style: { fontSize: "11px" } }, a.last_status) : null),
          h("td", {}, a.runs || 0),
          h("td", {}, h("div", { class: "row" }, h("button", { class: "btn sm", onclick: () => safe(async () => { await api(`/api/automations/${a.id}/run`, {}); toast("Started"); setTimeout(load, 800); }) }, icon("play", 12), " Run now"),
            h("button", { class: "btn sm danger", onclick: () => safe(async () => { const c = await api(`/api/automations/${a.id}/delete`, {}); if (!confirm(`Delete "${a.name}"?`) || !confirm("Second confirmation: delete permanently?")) return; await api(`/api/automations/${a.id}/delete`, { confirm_token: c.confirm_token }); load(); }) }, "Delete")))))))
        : emptyState("clock", "No automations yet", "Add a template above or create your own. ATLAS runs them while it's open."));
  }
  const off = bus.on((ev) => { if (ev.dept === "automations" || (ev.dept === "compute" && ev.kind === "job_done")) load(); });
  every.onchange = () => (at.style.display = every.value === "daily" ? "" : "none");
  put(root, h("div", { class: "hero" }, h("h1", {}, icon("clock", 22), "Automations")),
    h("p", { class: "sub" }, "Recurring work ATLAS does on its own: refresh market data every morning, evolve strategies weekly, research a topic daily, re-test models. Runs happen while ATLAS is open and every run is logged."),
    learn("how automations stay safe", "Each run goes through the same permission checks and spending limits as everything else. A run that fails is logged in System Health and does not retry in a loop: it simply waits for its next scheduled time."),
    h("div", { class: "grid g3" }, h("div", { class: "card span2" }, box),
      h("div", { class: "card" }, h("h3", {}, "New automation"), h("div", { class: "col" }, name, kind, payload, h("div", { class: "row" }, every, at), add))));
  load();
  return off;
}
