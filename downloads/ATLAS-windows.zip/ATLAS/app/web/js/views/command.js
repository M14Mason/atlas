import { put, api, bus, canvas, describe, DEPT_COLOR, fmt, h, icon, kpi, learn, lineChart } from "../core.js";

export async function render(root) {
  const o = await api("/api/overview");
  const ob = await api("/api/onboarding").catch(() => null);
  const noLLM = o.models_available.filter((m) => m !== "atlas-local").length === 0;
  const feed = h("div", { class: "feed" });
  const pulse = canvas(250);
  const ask = h("input", { placeholder: "Ask ATLAS anything, or describe an AI to build…", style: { flex: 1, fontSize: "15px", padding: "11px 14px" } });
  const goAsk = (where) => { if (!ask.value.trim()) return; sessionStorage.setItem("atlas_prefill", ask.value); location.hash = where; };
  ask.onkeydown = (e) => e.key === "Enter" && goAsk("chat");
  const QUICK = [["spark", "Build an AI", "build"], ["dna", "Evolve traders", "market"], ["org", "Assign a task", "workforce"], ["hex", "Convene council", "council"],
    ["flask", "Run an experiment", "lab"], ["book", "Add knowledge", "knowledge"], ["clock", "Automate something", "automations"], ["pulse", "Check health", "health"]];
  put(root,
    h("h1", {}, "Command Center"),
    h("p", { class: "sub" }, "Live state of the whole ecosystem. Every number and event here comes from the database and the live event stream."),
    h("div", { class: "card glow", style: { marginBottom: "14px" } }, h("div", { class: "row" }, icon("spark", 20), ask,
      h("button", { class: "btn primary", onclick: () => goAsk("chat") }, "Ask"), h("button", { class: "btn", onclick: () => goAsk("build") }, "Build it")),
      h("div", { class: "row", style: { marginTop: "12px", gap: "8px" } }, QUICK.map(([i, t, v]) => h("a", { class: "btn sm", href: "#" + v, style: { textDecoration: "none", color: "inherit", display: "inline-flex", gap: "6px", alignItems: "center" } }, icon(i, 14), t)))),
    ob ? checklist(ob) : null,
    noLLM ? h("div", { class: "card glow", style: { marginBottom: "14px", borderColor: "rgba(255,190,61,.5)" } },
      h("h2", { class: "amber" }, "Connect a model to unlock the Council and open-ended agents"),
      h("p", { class: "dim" }, "Right now only the built-in Local Engine (math, retrieval, splitting) is available. Free option: install Ollama on your Mac, run ",
        h("span", { class: "mono" }, "ollama pull llama3.2"), ", and ATLAS detects it. Paid options: add an API key in Settings. Everything else (Architect, Ground-Up AI, Market Lab, Research Lab, Knowledge) already works offline."),
      h("a", { href: "#settings" }, "Open Settings →")) : null,
    h("div", { class: "grid g6" },
      kpi("Agents", o.agents, o.agents_by_status.map((s) => `${s.n} ${s.status}`).join(" · ")),
      kpi("Tasks", o.tasks, `${o.tasks_running} running`),
      kpi("AI systems built", o.systems.reduce((a, s) => a + s.n, 0), o.systems.map((s) => `${s.n} ${s.status}`).join(" · ") || "none yet"),
      kpi("Models online", `${o.models_available.length}/${o.models_total}`, o.models_available.join(", ")),
      kpi("Spend today", fmt.usd(o.cost.today), `limit ${fmt.usd(o.cost.limit)} · all-time ${fmt.usd(o.cost.total)}`),
      kpi("Market Lab", "Gen " + o.market.gen, o.market.status)),
    h("div", { class: "grid g3", style: { marginTop: "14px" } },
      h("div", { class: "card span2" }, h("h3", {}, "Activity pulse (events per 10s, live)"), pulse,
        h("div", { class: "legend", id: "pulseLegend" })),
      h("div", { class: "card" }, h("h3", {}, "System health"),
        h("table", {}, h("tbody", {},
          o.health.credentials.map((c) => h("tr", {}, h("td", {}, h("span", { class: "dot " + (c.set ? "on" : "") }), " ", c.purpose.split("(")[0]),
            h("td", { class: c.set ? "green" : "faint" }, c.set ? "configured" : "not set"))),
          h("tr", {}, h("td", {}, "Compute nodes"), h("td", {}, o.nodes)),
          h("tr", {}, h("td", {}, "Autopilot"), h("td", {}, o.health.autopilot ? "on" : "off")),
          h("tr", {}, h("td", {}, "Jobs"), h("td", {}, o.jobs.map((j) => `${j.n} ${j.status}`).join(", ") || "none")))))),
    h("div", { class: "grid g2", style: { marginTop: "14px" } },
      h("div", { class: "card" }, h("h3", {}, "Live event stream"), feed),
      h("div", { class: "card" }, h("h3", {}, "Where to start"),
        h("ol", { class: "dim", style: { paddingLeft: "18px", lineHeight: "1.9" } },
          h("li", {}, h("a", { href: "#build" }, "Build & Architect"), ": describe an AI and watch it get designed, trained, tested and packaged."),
          h("li", {}, h("a", { href: "#market" }, "Market Lab"), ": evolve 500 trading bots on real 2007-2016 data."),
          h("li", {}, h("a", { href: "#build" }, "Ground-Up AI"), ": build a neural network layer by layer and watch it learn."),
          h("li", {}, h("a", { href: "#workforce" }, "AI Workforce"), ": give the Director a task and watch it delegate."),
          h("li", {}, h("a", { href: "#arena" }, "Arena"), ": benchmark models; scores set council voting weight.")),
        learn("what is ATLAS actually doing?",
          "ATLAS is a set of real systems that share one database and one event stream. When an agent delegates, a model is called, or a neural net finishes an epoch, an event is written. The animations you see elsewhere are drawn from those events, so if nothing is happening, nothing moves."))));
  const add = (ev) => {
    if (ev.kind === "epoch" || ev.kind === "item_scored") return;
    feed.prepend(h("div", { class: "ev" }, h("span", { class: "t" }, fmt.time(ev.ts)),
      h("span", { class: "d", style: { color: DEPT_COLOR[ev.dept] || "#8a97b0" } }, ev.dept), h("span", {}, describe(ev))));
    while (feed.children.length > 120) feed.lastChild.remove();
  };
  o.events.slice().reverse().forEach(add);
  // activity pulse from real events
  const buckets = {}; const N = 36;
  const now = () => Math.floor(Date.now() / 10000);
  o.events.forEach((ev) => { const b = Math.floor(ev.ts / 10); (buckets[ev.dept] ||= {})[b] = (buckets[ev.dept][b] || 0) + 1; });
  const off = bus.on((ev) => { add(ev); const b = now(); (buckets[ev.dept] ||= {})[b] = ((buckets[ev.dept] || {})[b] || 0) + 1; });
  const draw = () => {
    const t = now();
    const depts = Object.keys(buckets);
    lineChart(pulse, depts.map((d) => ({ color: DEPT_COLOR[d] || "#888", data: Array.from({ length: N }, (_, i) => buckets[d][t - N + 1 + i] || 0) })), { y: [0, Math.max(5, ...depts.flatMap((d) => Object.values(buckets[d])))] });
    const lg = document.getElementById("pulseLegend");
    if (lg) { lg.innerHTML = ""; depts.forEach((d) => lg.append(h("span", {}, h("i", { style: { background: DEPT_COLOR[d] } }), d))); if (!depts.length) lg.append(h("span", {}, "Waiting for activity. Start something in any department.")); }
  };
  draw();
  const iv = setInterval(draw, 2000);
  return () => { off(); clearInterval(iv); };
}

function checklist(ob) {
  const llm = ob.models.some((m) => m.startsWith("ollama:") || !m.startsWith("atlas"));
  const items = [
    ["Install Ollama (free AI)", "Runs AI models on your computer", ob.ollama, "settings"],
    ["Download a free model", "One click in Settings", llm, "settings"],
    ["Build your first AI", "Describe it to the Architect", ob.systems > 0, "build"],
    ["Evolve trading bots", "Start a Market Lab run", ob.market_gens > 0, "market"],
    ["Ask ATLAS a question", "Chat with sources", ob.chats > 0, "chat"],
    ["Give your team a task", "Watch agents delegate", ob.tasks > 0, "workforce"],
    ["Teach ATLAS something", "Add a note or document", ob.docs > 0, "knowledge"],
    ["Benchmark a model", "Run the Arena", ob.arena_runs > 0, "arena"],
    ["Automate something", "Schedule a recurring job", ob.automations > 0, "automations"],
  ];
  const done = items.filter((i) => i[2]).length;
  if (done === items.length) return null;
  const pct = Math.round(done / items.length * 100);
  return h("div", { class: "card", style: { marginBottom: "16px" } },
    h("div", { class: "row between", style: { marginBottom: "12px" } },
      h("div", {}, h("h2", { style: { margin: 0, fontSize: "17px" } }, "Getting started"), h("div", { class: "dim", style: { fontSize: "13px" } }, `${done} of ${items.length} done. Each step takes about a minute.`)),
      h("div", { class: "progress-ring" }, h("div", { class: "bar", style: { width: "160px", height: "8px" } }, h("i", { style: { width: pct + "%" } })), h("b", {}, pct + "%"))),
    h("div", { class: "checklist" }, items.map(([t, d, ok, v]) => h("a", { class: "ck" + (ok ? " done" : ""), href: "#" + v, style: { textDecoration: "none" } },
      h("span", { class: "box" }, ok ? icon("check", 14) : null), h("div", {}, h("b", {}, t), h("span", {}, d))))));
}
