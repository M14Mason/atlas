import { put, api, bus, fmt, h, learn, safe, tag, toast, waitJob } from "../core.js";

export async function render(root) {
  const models = await api("/api/models");
  let data = await api("/api/arena");
  const model = h("select", {}, models.map((m) => h("option", { value: m.id, disabled: !m.available }, `${m.name}${m.available ? "" : " (not configured)"}`)));
  const cats = data.categories.map((c) => h("label", { class: "inline" }, h("input", { type: "checkbox", value: c, checked: c !== "code" }), c));
  const n = h("input", { type: "number", value: 5, min: 1, max: 20, style: { width: "70px" } });
  const live = h("div", { class: "feed", style: { maxHeight: "260px" } });
  const board = h("div"), rep = h("div"), runs = h("div");
  const go = h("button", { class: "btn primary" }, "Run benchmarks");
  go.onclick = () => safe(async () => {
    const categories = cats.map((l) => l.querySelector("input")).filter((i) => i.checked).map((i) => i.value);
    if (!categories.length) throw new Error("pick a category");
    go.disabled = true;
    const { jobs } = await api("/api/arena/run", { model: model.value, categories, n: +n.value });
    toast(`${jobs.length} benchmark jobs started`);
    try { await Promise.all(jobs.map((j) => waitJob(j))); } finally { go.disabled = false; load(); }
  });
  const off = bus.on((ev) => {
    if (ev.dept !== "arena") return;
    if (ev.kind === "item_scored") live.prepend(h("div", { class: "ev", style: { gridTemplateColumns: "1fr 90px 50px" } }, h("span", {}, ev.actor), h("span", { class: "dim" }, ev.data.category + " #" + ev.data.i), h("span", { class: ev.data.score ? "green" : "red" }, ev.data.score ? "✓" : "✗")));
    if (ev.kind === "run_done") load();
  });
  async function load() {
    data = await api("/api/arena");
    board.innerHTML = ""; rep.innerHTML = ""; runs.innerHTML = "";
    board.append(data.leaderboard.length ? h("table", {}, h("thead", {}, h("tr", {}, ["Category", "Model", "Accuracy", "Avg latency", "Cost", "Items"].map((c) => h("th", {}, c)))),
      h("tbody", {}, data.leaderboard.map((r) => h("tr", {}, h("td", {}, r.category), h("td", { class: "mono" }, r.model),
        h("td", {}, h("div", { class: "row" }, h("div", { class: "bar", style: { width: "80px" } }, h("i", { style: { width: r.accuracy * 100 + "%" } })), fmt.pct(r.accuracy, 0))),
        h("td", {}, fmt.num(r.latency, 2) + "s"), h("td", {}, fmt.usd(r.cost)), h("td", {}, r.n))))) : h("div", { class: "empty" }, "No benchmark runs yet. The Local Engine can be benchmarked for free (it should ace math and fail the rest)."));
    const ms = [...new Set(data.reputation.map((r) => r.model))], cs = [...new Set(data.reputation.map((r) => r.category))];
    rep.append(ms.length ? h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "model"), cs.map((c) => h("th", {}, c)))),
      h("tbody", {}, ms.map((m) => h("tr", {}, h("td", { class: "mono" }, m), cs.map((c) => { const r = data.reputation.find((x) => x.model === m && x.category === c);
        return h("td", { style: { background: r ? `rgba(${Math.round(255 * (1 - r.score))},${Math.round(200 * r.score)},140,.18)` : "" } }, r ? `${r.score.toFixed(2)} (${r.n})` : ""); }))))) : h("div", { class: "empty" }, "Reputation appears after benchmarks or graded tasks."));
    runs.append(h("table", {}, h("tbody", {}, data.runs.map((r) => h("tr", { class: "click", onclick: () => detail(r) }, h("td", {}, r.name), h("td", {}, fmt.pct(r.results.summary.accuracy, 0)), h("td", { class: "faint" }, fmt.ago(r.created)))))));
  }
  const det = h("div");
  function detail(r) { det.innerHTML = ""; det.append(h("div", { class: "card", style: { marginTop: "14px" } }, h("h3", {}, r.name + " · seed " + r.results.summary.seed),
    r.results.items.map((i) => h("div", { class: "msg" }, h("div", { class: "who" }, i.score ? "✓ correct" : "✗ wrong", h("span", { class: "to" }, ` ${fmt.num(i.latency, 2)}s ${fmt.usd(i.cost)}`)), h("b", {}, i.q), "\n", i.out)))); }
  put(root, h("h1", {}, "Intelligence Arena"), h("p", { class: "sub" }, "Benchmarks with objective, automatic grading: exact numbers, keyword facts, JSON validity, and real unit tests for code. Results update reputation, which drives Council voting weight and cost-based routing."),
    learn("why only verifiable benchmarks?", "If a model grades its own homework you learn nothing. Every Arena item has a checkable answer. Code answers are executed in a separate, time-limited process against unit tests (you can switch code execution off in Settings).",
      "Reputation is an exponential moving average, so recent results count more. A cheap model that keeps scoring well will start receiving work that used to go to an expensive one. That is the AI economy."),
    h("div", { class: "card", style: { marginBottom: "14px" } }, h("div", { class: "row" }, model, cats, h("label", { class: "inline" }, "items", n), go)),
    h("div", { class: "grid g3" }, h("div", { class: "card span2" }, h("h3", {}, "Leaderboard"), board), h("div", { class: "card" }, h("h3", {}, "Live scoring"), live)),
    h("div", { class: "grid g2", style: { marginTop: "14px" } }, h("div", { class: "card" }, h("h3", {}, "Reputation (score, evidence count)"), rep), h("div", { class: "card" }, h("h3", {}, "Recent runs"), runs)), det);
  load();
  return off;
}
