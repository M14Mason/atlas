import { put, api, barChart, canvas, fmt, h, kpi, learn } from "../core.js";

export async function render(root) {
  const e = await api("/api/economy");
  const daily = canvas(140);
  put(root, h("h1", {}, "AI Economy"), h("p", { class: "sub" }, "What intelligence costs. Every model call is metered from the token counts the provider returns, priced with the table in Settings."),
    learn("how ATLAS keeps costs down", "1) Free first: the Local Engine and Ollama models cost $0. 2) Routing: for each task category ATLAS picks the cheapest model that has <b>proven</b> it scores above the bar for that difficulty (3+ graded results). 3) Hard limits: a per-call and daily cap block calls before they happen. 4) Evolution: proven repetitive work is handed to cheaper specialist agents once they pass an exam.",
      "<b>Cost per successful task</b> is the real productivity metric: an expensive model that gets it right first time can be cheaper than a cheap one that fails."),
    h("div", { class: "grid g4" }, kpi("Today", fmt.usd(e.today), "limit " + fmt.usd(e.limits.daily_limit_usd)), kpi("7 days", fmt.usd(e.week)), kpi("All time", fmt.usd(e.total)), kpi("Per-call cap", fmt.usd(e.limits.per_call_limit_usd))),
    h("div", { class: "card", style: { marginTop: "14px" } }, h("h3", {}, "Daily spend (last 30 days with activity)"), daily),
    h("div", { class: "grid g2", style: { marginTop: "14px" } },
      h("div", { class: "card" }, h("h3", {}, "By model"), e.by_model.length ? h("table", {}, h("thead", {}, h("tr", {}, ["Model", "Calls", "Tokens in/out", "Avg latency", "Cost"].map((c) => h("th", {}, c)))),
        h("tbody", {}, e.by_model.map((m) => h("tr", {}, h("td", { class: "mono" }, m.model), h("td", {}, m.calls), h("td", {}, `${m.tin} / ${m.tout}`), h("td", {}, fmt.num(m.latency, 2) + "s"), h("td", {}, fmt.usd(m.cost)))))) : h("div", { class: "empty" }, "No model calls yet")),
      h("div", { class: "card" }, h("h3", {}, "Agent productivity"), h("table", {}, h("thead", {}, h("tr", {}, ["Agent", "Tasks", "Succeeded", "Quality", "Cost", "Cost / success"].map((c) => h("th", {}, c)))),
        h("tbody", {}, e.by_agent.filter((a) => a.tasks).map((a) => h("tr", {}, h("td", {}, a.name), h("td", {}, a.tasks), h("td", {}, a.ok), h("td", {}, a.quality == null ? "-" : a.quality.toFixed(2)), h("td", {}, fmt.usd(a.cost)), h("td", {}, a.cost_per_success == null ? "-" : fmt.usd(a.cost_per_success)))))))));
  barChart(daily, e.daily.slice().reverse().map((d) => d.cost), { color: "#ffbe3d", labels: e.daily.length ? [new Date(e.daily[e.daily.length - 1].day * 864e5).toLocaleDateString(), new Date(e.daily[0].day * 864e5).toLocaleDateString()] : ["", ""] });
}
