import { put, api, bus, fileToB64, fmt, h, learn, safe, tag, toast } from "../core.js";

export async function render(root) {
  const title = h("input", { placeholder: "Title" });
  const project = h("input", { placeholder: "Project (e.g. trading, school)", value: "general" });
  const content = h("textarea", { placeholder: "Paste notes, an article, research..." });
  const file = h("input", { type: "file", accept: ".txt,.md,.csv,.html,.json,.pdf" });
  const add = h("button", { class: "btn primary" }, "Add to knowledge");
  const q = h("input", { placeholder: "Search everything ATLAS knows...", style: { flex: 1 } });
  const results = h("div"); const docs = h("div"); const mems = h("div");
  const graphC = h("canvas", { style: { height: "420px" } });
  const mk = h("select", {}, h("option", { value: "memory" }, "memory (a fact)"), h("option", { value: "skill" }, "skill (a procedure)"));
  const msub = h("input", { placeholder: "Subject" }), mtext = h("textarea", { placeholder: "What to remember / how to do it", style: { minHeight: "60px" } });
  add.onclick = () => safe(async () => {
    const body = { title: title.value, project: project.value };
    if (file.files[0]) { body.file_b64 = await fileToB64(file.files[0]); body.filename = file.files[0].name; } else body.content = content.value;
    await api("/api/knowledge/docs", body); content.value = ""; title.value = ""; file.value = ""; load();
  }, "Added and indexed");
  const search = async () => {
    const r = await api("/api/knowledge/search?q=" + encodeURIComponent(q.value));
    results.innerHTML = "";
    results.append(r.length ? r.map((x) => h("div", { class: "msg" }, h("div", { class: "who" }, x.title, h("span", { class: "to" }, ` ${x.project} · relevance ${x.score.toFixed(3)}`)), x.snippet)) : h("div", { class: "empty" }, "No matches"));
  };
  q.onkeydown = (e) => e.key === "Enter" && search();
  const saveMem = h("button", { class: "btn" }, "Store");
  saveMem.onclick = () => safe(async () => { await api("/api/knowledge/memory", { kind: mk.value, subject: msub.value, content: mtext.value }); msub.value = mtext.value = ""; load(); }, "Stored");

  const modeEl = h("span", { class: "tag ok" }, "");
  async function load() {
    const k = await api("/api/knowledge");
    modeEl.textContent = "search: " + k.stats.search_mode;
    docs.innerHTML = ""; mems.innerHTML = "";
    docs.append(k.docs.length ? h("table", {}, h("tbody", {}, k.docs.map((d) => h("tr", {}, h("td", {}, d.title), h("td", {}, tag(d.project, "x")), h("td", { class: "faint" }, d.chars + " chars"),
      h("td", {}, h("button", { class: "btn sm danger", onclick: () => safe(async () => { const c = await api(`/api/knowledge/docs/${d.id}/delete`, {}); if (!confirm(c.message)) return; if (!confirm("Second confirmation: delete this document?")) return; await api(`/api/knowledge/docs/${d.id}/delete`, { confirm_token: c.confirm_token }); load(); }) }, "Delete")))))) : h("div", { class: "empty" }, "No documents yet"));
    const groups = { memory: [], skill: [], parameter: [] }; k.memories.forEach((m) => groups[m.kind]?.push(m));
    mems.append(h("div", { class: "grid g3" }, Object.entries(groups).map(([kind, list]) => h("div", {}, h("h3", {}, kind + " (" + list.length + ")"),
      list.slice(0, 12).map((m) => h("div", { class: "msg", style: { fontSize: "12px" } }, h("div", { class: "who" }, m.subject, h("span", { class: "to" }, " " + m.source)), m.content.slice(0, 220)))))));
    drawGraph(await api("/api/knowledge/graph"));
  }
  let raf, sim;
  function drawGraph(g) {
    cancelAnimationFrame(raf);
    const W = graphC.clientWidth || 800, H = 420, dpr = devicePixelRatio || 1; graphC.width = W * dpr; graphC.height = H * dpr;
    const x = graphC.getContext("2d");
    const N = g.nodes.map((n, i) => ({ ...n, x: W / 2 + Math.cos(i) * 150, y: H / 2 + Math.sin(i) * 150, vx: 0, vy: 0 }));
    const idx = Object.fromEntries(N.map((n, i) => [n.id, i]));
    const E = g.edges.map((e) => [idx[e.a], idx[e.b], e.w]).filter((e) => e[0] != null && e[1] != null);
    let iter = 0;
    const step = () => {
      if (iter++ < 400) {
        for (let i = 0; i < N.length; i++) for (let j = i + 1; j < N.length; j++) { const a = N[i], b = N[j]; let dx = a.x - b.x, dy = a.y - b.y; const d2 = dx * dx + dy * dy + 0.01, f = 900 / d2; a.vx += dx * f / 30; a.vy += dy * f / 30; b.vx -= dx * f / 30; b.vy -= dy * f / 30; }
        for (const [i, j, w] of E) { const a = N[i], b = N[j]; const dx = b.x - a.x, dy = b.y - a.y; const k = 0.004 * Math.min(3, w); a.vx += dx * k; a.vy += dy * k; b.vx -= dx * k; b.vy -= dy * k; }
        for (const n of N) { n.vx += (W / 2 - n.x) * 0.002; n.vy += (H / 2 - n.y) * 0.002; n.vx *= 0.82; n.vy *= 0.82; n.x = Math.max(20, Math.min(W - 20, n.x + n.vx)); n.y = Math.max(20, Math.min(H - 20, n.y + n.vy)); }
      }
      x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, W, H);
      for (const [i, j, w] of E) { x.strokeStyle = `rgba(91,140,255,${Math.min(0.6, 0.12 * w)})`; x.beginPath(); x.moveTo(N[i].x, N[i].y); x.lineTo(N[j].x, N[j].y); x.stroke(); }
      for (const n of N) { const r = 3 + Math.min(10, Math.sqrt(n.weight) * 1.6); const c = n.type === "doc" ? "#ff6bd5" : "#3ee0ff";
        x.fillStyle = c; x.shadowColor = c; x.shadowBlur = 8; x.beginPath(); x.arc(n.x, n.y, r, 0, 7); x.fill(); x.shadowBlur = 0;
        x.fillStyle = "#cfd8ea"; x.font = "10px Inter"; x.fillText(n.id.replace("doc:", "📄 ").slice(0, 26), n.x + r + 3, n.y + 3); }
      if (!N.length) { x.fillStyle = "#5b6782"; x.font = "13px Inter"; x.fillText("Add documents to grow the knowledge graph", W / 2 - 130, H / 2); }
      raf = requestAnimationFrame(step);
    };
    step();
  }
  const off = bus.on((ev) => { if (ev.dept === "knowledge") load(); });
  put(root, h("h1", {}, "Knowledge Universe"), h("p", { class: "sub" }, "Persistent memory for the whole ecosystem. Documents are chunked and indexed for semantic search; agents with the knowledge tool consult it automatically."),
    learn("how search and the graph work", "Search uses <b>TF-IDF</b>: words that are rare across your documents but common in one passage get high weight, and passages are compared by angle (cosine similarity). It's local and free. It matches related wording well but not pure synonyms; run <code>ollama pull nomic-embed-text</code> on your Mac and ATLAS automatically switches to <b>hybrid</b> search (neural embeddings that understand meaning, blended with TF-IDF). Embeddings are cached so each passage is only embedded once.",
      "The graph links named things (capitalised terms) that appear in the same passage. Pink = documents, cyan = entities. Bigger = mentioned more."),
    h("div", { class: "grid g2" },
      h("div", { class: "card" }, h("h3", {}, "Add knowledge"), h("div", { class: "grid g2" }, title, project), h("div", { style: { margin: "8px 0" } }, content), h("div", { class: "row" }, file, add)),
      h("div", { class: "card" }, h("div", { class: "row between" }, h("h3", {}, "Semantic search"), modeEl), h("div", { class: "row" }, q, h("button", { class: "btn", onclick: search }, "Search")), h("div", { style: { marginTop: "10px", maxHeight: "300px", overflow: "auto" } }, results))),
    h("div", { class: "card", style: { marginTop: "14px" } }, h("h3", {}, "Knowledge graph"), h("div", { class: "canvas-wrap" }, graphC)),
    h("div", { class: "grid g3", style: { marginTop: "14px" } }, h("div", { class: "card span2" }, h("h3", {}, "Memory, skills and parameters"), mems),
      h("div", { class: "card" }, h("h3", {}, "Teach ATLAS"), h("div", { class: "col" }, mk, msub, mtext, saveMem), h("p", { class: "faint", style: { fontSize: "12px" } }, "Parameter changes are recorded automatically when a model is trained or fine-tuned."))),
    h("div", { class: "card", style: { marginTop: "14px" } }, h("h3", {}, "Documents"), docs));
  load();
  return () => { cancelAnimationFrame(raf); off(); };
}
