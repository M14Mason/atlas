import { put, api, fmt, h, icon, learn, safe, tag, toast, waitJob } from "../core.js";

export async function render(root) {
  const creds = await api("/api/credentials"); const p = await api("/api/permissions"); const models = await api("/api/models");
  const credBox = h("div");
  const drawCreds = (list) => { credBox.innerHTML = ""; list.forEach((c) => { const inp = h("input", { type: "password", placeholder: c.set ? "•••••• (set, " + c.source + ")" : "not set", style: { flex: 1 } });
    credBox.append(h("div", { class: "row", style: { margin: "6px 0" } }, h("span", { style: { width: "190px" }, class: "mono" }, c.name), inp,
      h("button", { class: "btn sm", onclick: () => safe(async () => { drawCreds(await api("/api/credentials", { name: c.name, value: inp.value })); }, "Saved") }, "Save"),
      c.set && c.source === "vault" ? h("button", { class: "btn sm danger", onclick: () => safe(async () => { if (!confirm("Remove " + c.name + "?")) return; if (!confirm("Second confirmation: remove the key?")) return; drawCreds(await api("/api/credentials", { name: c.name, value: "" })); }, "Removed") }, "Remove") : null,
      h("span", { class: "faint", style: { fontSize: "12px" } }, c.purpose))); }); };
  drawCreds(creds);
  const perm = Object.fromEntries(Object.entries(p.permissions).map(([k, v]) => [k, typeof v === "boolean" ? h("input", { type: "checkbox", checked: v }) : h("input", { type: "number", value: v, style: { width: "80px" } })]));
  const lim = Object.fromEntries(Object.entries(p.limits).map(([k, v]) => [k, h("input", { type: "number", value: v, step: 0.01, style: { width: "100px" } })]));
  const savePerm = h("button", { class: "btn primary" }, "Save controls");
  savePerm.onclick = () => safe(async () => { await api("/api/permissions", { permissions: Object.fromEntries(Object.entries(perm).map(([k, el]) => [k, el.type === "checkbox" ? el.checked : +el.value])), limits: Object.fromEntries(Object.entries(lim).map(([k, el]) => [k, +el.value])) }); }, "Saved");
  const runAuto = h("button", { class: "btn" }, "Run one autopilot cycle now");
  runAuto.onclick = () => safe(async () => { runAuto.disabled = true; try { const { job } = await api("/api/autopilot/run", {}); const r = await waitJob(job); toast((r.actions || []).join("; ") || "nothing to do"); } finally { runAuto.disabled = false; } });
  // ---- free local model manager (Ollama)
  const ol = await api("/api/ollama").catch(() => ({ running: false, models: [], recommended: [] }));
  const custom = h("input", { placeholder: "any Ollama model, e.g. mistral" });
  const pullBtn = (name, label = "Download") => { const b = h("button", { class: "btn sm primary" }, icon("download", 12), " " + label);
    const bar = h("div", { class: "bar", style: { width: "110px" } }, h("i", { style: { width: "0%" } }));
    b.onclick = () => safe(async () => { b.disabled = true; const { job } = await api("/api/ollama/pull", { model: name }); await waitJob(job, (j) => (bar.firstChild.style.width = j.progress * 100 + "%")); b.textContent = "Installed"; }, "Downloaded " + name);
    return h("div", { class: "row" }, bar, b); };
  const modelMgr = h("div", { class: "card glow", style: { marginBottom: "14px" } }, h("div", { class: "row between" }, h("h3", {}, "Free AI models (Ollama, runs on your computer)"),
      tag(ol.running ? "Ollama running" : "Ollama not running", ol.running ? "ok" : "warn")),
    ol.running ? h("div", {}, h("table", {}, h("tbody", {}, ol.recommended.map((r) => h("tr", {}, h("td", {}, h("b", {}, r.name), h("div", { class: "faint", style: { fontSize: "12px" } }, r.why)),
        h("td", { class: "dim" }, r.size_gb + " GB"), h("td", {}, r.installed ? tag("installed", "ok") : pullBtn(r.name)))))),
      h("div", { class: "row", style: { marginTop: "10px" } }, custom, h("button", { class: "btn", onclick: () => custom.value && modelMgr.append(h("div", { style: { marginTop: "8px" } }, h("b", {}, custom.value + " "), pullBtn(custom.value.trim(), "Start download"))) }, "Add")),
      h("p", { class: "faint", style: { fontSize: "12px" } }, "Installed: " + (ol.models.map((m) => m.name).join(", ") || "none")))
    : h("ol", { class: "steps-list" }, h("li", {}, "Download Ollama (free): ", h("a", { href: "https://ollama.com/download", target: "_blank" }, "ollama.com/download")),
        h("li", {}, "Open it once. It runs quietly in your menu bar / tray."), h("li", {}, "Reopen this page. One-click model downloads appear here.")));
  const accents = ["cyan", "violet", "green", "amber"];
  const COL = { cyan: "#3ee0ff", violet: "#a27bff", green: "#3ddc97", amber: "#ffbe3d" };
  const cur = (() => { try { return localStorage.getItem("atlas_accent") || "cyan"; } catch { return "cyan"; } })();
  const look = h("div", { class: "card", style: { marginBottom: "14px" } }, h("h3", {}, "Appearance & help"),
    h("div", { class: "row" }, h("span", { class: "dim" }, "Accent colour"), accents.map((a) => h("span", { class: "swatch" + (a === cur ? " on" : ""), style: { background: COL[a] },
      onclick: (e) => { window.atlasSetAccent(a); [...e.target.parentNode.querySelectorAll(".swatch")].forEach((x) => x.classList.remove("on")); e.target.classList.add("on"); } })),
      h("button", { class: "btn sm", style: { marginLeft: "auto" }, onclick: () => window.atlasOnboarding() }, "Replay setup wizard")),
    h("p", { class: "faint", style: { fontSize: "12px" } }, "Tip: press ⌘K / Ctrl+K anywhere to search and jump."));
  const LABELS = {
    allow_web_access: "Allow web research (search + read public pages)", agents_can_create_agents: "Agents may create subordinate agents", allow_paid_models: "Allow paid API models", allow_code_execution: "Allow running model-written code (Arena tests, sandboxed)", autopilot: "Autopilot (self-improvement loop)", autopilot_interval_min: "Autopilot interval (minutes)",
    daily_limit_usd: "Daily spending limit (USD)", per_call_limit_usd: "Max cost per model call (USD)", require_approval_over_usd: "Approval threshold (USD, reserved)" };
  put(root, h("h1", {}, "Settings & Control"), modelMgr, look, h("p", { class: "sub" }, "Credentials, permissions, spending limits and autonomy. These are enforced in the backend at the moment of action, not just hidden in the UI."),
    h("div", { class: "card", style: { marginBottom: "14px" } }, h("h3", {}, "Credentials"),
      h("p", { class: "dim" }, "Keys are stored in ~/.atlas/secrets.json with owner-only permissions (or read from environment variables). They are never sent back to the browser, logged or put in the database."),
      h("p", { class: "amber" }, "⚠ Paid API keys spend real money. Keep the daily limit low while learning. Ollama is free: install from ollama.com, run `ollama pull llama3.2`, ATLAS detects it within 30 seconds."),
      credBox),
    h("div", { class: "grid g2" },
      h("div", { class: "card" }, h("h3", {}, "Permissions & autonomy"), h("table", {}, h("tbody", {}, Object.entries(perm).map(([k, el]) => h("tr", {}, h("td", {}, LABELS[k] || k), h("td", {}, el))))),
        learn("what autopilot does", "Every interval it (1) benchmarks configured models that have little evidence yet, using small cheap samples, and (2) examines agents on probation so good ones become trusted. It obeys every limit above. Off by default."),
        h("div", { class: "row" }, savePerm, runAuto), h("div", { class: "feed", style: { marginTop: "10px" } }, p.autopilot_log.map((l) => h("div", { class: "ev", style: { gridTemplateColumns: "80px 1fr" } }, h("span", { class: "t" }, fmt.time(l.ts)), h("span", {}, l.actions.join("; ") || "nothing to do"))))),
      h("div", { class: "card" }, h("h3", {}, "Spending limits"), h("table", {}, h("tbody", {}, Object.entries(lim).map(([k, el]) => h("tr", {}, h("td", {}, LABELS[k] || k), h("td", {}, el))))),
        h("h3", { style: { marginTop: "14px" } }, "Model price table (USD per million tokens, estimates: verify on vendor sites)"),
        h("table", {}, h("thead", {}, h("tr", {}, ["Model", "Status", "In", "Out", ""].map((c) => h("th", {}, c)))), h("tbody", {}, models.map((m) => { const i = h("input", { type: "number", value: m.in, step: 0.01, style: { width: "70px" } }), o = h("input", { type: "number", value: m.out, step: 0.01, style: { width: "70px" } });
          return h("tr", {}, h("td", {}, m.name, h("div", { class: "faint mono" }, m.id)), h("td", {}, tag(m.available ? "online" : "offline", m.available ? "ok" : "x")), h("td", {}, i), h("td", {}, o), h("td", {}, h("button", { class: "btn sm", onclick: () => safe(() => api("/api/models/prices", { model: m.id, in: +i.value, out: +o.value }), "Price saved") }, "Save"))); }))))));
}
