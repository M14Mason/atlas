import { put, api, bus, fmt, h, learn, micButton, safe, tag, waitJob } from "../core.js";

export async function render(root) {
  const models = (await api("/api/models")).filter((m) => m.provider !== "local");
  const avail = models.filter((m) => m.available);
  const q = h("textarea", { placeholder: "Ask the council a question or a decision to make..." });
  const rounds = h("select", {}, h("option", { value: 1 }, "1 critique round"), h("option", { value: 2 }, "2 critique rounds"), h("option", { value: 0 }, "no critique"));
  const boxes = models.map((m) => h("label", { class: "inline" }, h("input", { type: "checkbox", value: m.id, checked: m.available, disabled: !m.available }),
    m.name, m.available ? null : h("span", { class: "faint" }, "(not configured)")));
  const live = h("div");
  const transcript = h("div");
  const sessions = h("div");
  const go = h("button", { class: "btn primary" }, "Convene council");
  go.onclick = () => safe(async () => {
    const members = boxes.map((b) => b.querySelector("input")).filter((i) => i.checked).map((i) => i.value);
    if (!q.value.trim()) throw new Error("ask something first");
    go.disabled = true;
    live.innerHTML = ""; transcript.innerHTML = "";
    const { job } = await api("/api/council", { question: q.value, members, rounds: +rounds.value });
    const off = bus.on((ev) => {
      if (ev.dept !== "council" || ev.kind !== "statement") return;
      live.append(h("div", { class: "msg phase-" + ev.data.phase }, h("div", { class: "who" }, ev.actor, " ", h("span", { class: "to" }, ev.data.phase)), ev.data.preview + (ev.data.preview.length >= 200 ? "…" : "")));
    });
    try { const r = await waitJob(job); showResult(r); } finally { off(); go.disabled = false; loadSessions(); }
  });

  function showResult(r) {
    transcript.innerHTML = "";
    if (r.note) transcript.append(h("div", { class: "card", style: { borderColor: "rgba(255,190,61,.5)" } }, h("p", { class: "amber" }, r.note)));
    if (r.tally && Object.keys(r.tally).length) {
      const max = Math.max(...Object.values(r.tally), 1e-9);
      transcript.append(h("div", { class: "card" }, h("h3", {}, "Weighted vote"),
        Object.entries(r.tally).sort((a, b) => b[1] - a[1]).map(([m, v]) => h("div", { style: { margin: "6px 0" } },
          h("div", { class: "row between" }, h("span", {}, m, m === r.winner ? h("span", { class: "green" }, "  ★ decision") : null), h("span", { class: "mono" }, v.toFixed(3))),
          h("div", { class: "bar" }, h("i", { style: { width: (v / max * 100) + "%" } })))),
        h("p", { class: "faint", style: { fontSize: "12px" } }, "Weights: ", Object.entries(r.weights || {}).map(([m, w]) => `${m} ${w}`).join(" · "), ". Self-votes are discarded.")));
    }
    if (r.decision) transcript.append(h("div", { class: "card glow" }, h("h3", {}, "Council decision"), h("div", { class: "msg" }, r.decision)));
    api("/api/thread/council-" + r.session).then((msgs) => transcript.append(h("div", { class: "card" }, h("h3", {}, "Full transcript"),
      msgs.map((m) => h("div", { class: "msg" }, h("div", { class: "who" }, m.sender), m.content)))));
  }

  async function loadSessions() {
    const s = await api("/api/council/sessions");
    sessions.innerHTML = "";
    sessions.append(s.length ? h("table", {}, h("tbody", {}, s.map((x) => h("tr", { class: "click", onclick: () => showResult({ ...(x.results || {}), session: x.id }) },
      h("td", {}, x.config.question.slice(0, 70)), h("td", {}, tag(x.status)), h("td", { class: "faint" }, fmt.ago(x.created)))))) : h("div", { class: "empty" }, "No sessions yet"));
  }

  put(root, h("h1", {}, "AI Council"), h("p", { class: "sub" }, "Several models answer independently, read each other's answers anonymously, critique and revise, then vote. Each vote is weighted by that model's measured Arena performance in the question's category."),
    learn("why weight votes by reputation?", "A model that has proven itself on verified benchmarks in this category gets more say. Unproven models start at a neutral 0.5. This is how ATLAS avoids letting a confident-but-wrong model dominate.",
      "Answers are labelled A, B, C during critique and voting so models judge content rather than names. A model voting for its own answer is ignored."),
    avail.length < 2 ? h("div", { class: "card", style: { marginBottom: "14px", borderColor: "rgba(255,190,61,.5)" } }, h("p", { class: "amber" },
      `The council needs at least 2 configured models. Available: ${avail.map((m) => m.name).join(", ") || "none"}. Add keys or start Ollama in Settings.`)) : null,
    h("div", { class: "grid g3" },
      h("div", { class: "card span2" }, h("h3", {}, "Question"), h("div", { class: "row", style: { alignItems: "flex-start" } }, q, micButton(q)),
        h("div", { class: "row", style: { marginTop: "10px" } }, rounds, go),
        h("h3", { style: { marginTop: "16px" } }, "Live deliberation"), live),
      h("div", { class: "card" }, h("h3", {}, "Members"), h("div", { class: "col" }, boxes), h("h3", { style: { marginTop: "16px" } }, "Past sessions"), sessions)),
    h("div", { style: { marginTop: "14px" } }, transcript));
  loadSessions();
}
