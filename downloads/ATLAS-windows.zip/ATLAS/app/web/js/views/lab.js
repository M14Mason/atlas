import { put, api, canvas, fmt, h, learn, lineChart, safe, tag, toast, waitJob } from "../core.js";

export async function render(root) {
  const ds = h("select", {}, ["spiral", "moons", "circles", "xor", "blobs", "sine"].map((d) => h("option", {}, d)));
  const variable = h("select", {}, [["lr", "learning rate", "0.001, 0.01, 0.05, 0.2"], ["hidden", "architecture", "[4], [16], [32,32], [64,64,64]"], ["activation", "activation", "relu, tanh, sigmoid, gelu"],
    ["dropout", "dropout", "0, 0.1, 0.3, 0.5"], ["noise", "data noise", "0.05, 0.2, 0.4"], ["optimizer", "optimizer", "sgd, momentum, adam"], ["l2", "L2 regularisation", "0, 0.0001, 0.01, 0.1"]].map(([v, t, ex]) => h("option", { value: v, "data-ex": ex }, t)));
  const values = h("input", { style: { flex: 1 } });
  const seeds = h("input", { type: "number", value: 3, min: 1, max: 10, style: { width: "70px" } });
  const epochs = h("input", { type: "number", value: 120, style: { width: "80px" } });
  variable.onchange = () => (values.value = variable.selectedOptions[0].dataset.ex);
  variable.onchange();
  const chart = canvas(240); const concl = h("div"); const prog = h("div", { class: "bar" }, h("i", { style: { width: "0%" } }));
  const exps = h("div");
  const go = h("button", { class: "btn primary" }, "Run controlled experiment");
  go.onclick = () => safe(async () => {
    const v = variable.value;
    const vals = v === "hidden" ? JSON.parse("[" + values.value + "]") : values.value.split(",").map((s) => s.trim()).map((s) => (isNaN(+s) ? s : +s));
    go.disabled = true;
    const { job } = await api("/api/lab/sweep", { base: { dataset: ds.value, epochs: +epochs.value, hidden: [32, 32], lr: 0.01 }, variable: v, values: vals, seeds: [...Array(+seeds.value).keys()] });
    try { const r = await waitJob(job, (j) => (prog.firstChild.style.width = j.progress * 100 + "%")); show(r, v); load(); } finally { go.disabled = false; }
  });
  function show(r, v) {
    const xs = r.rows.map((_, i) => i);
    lineChart(chart, [{ data: r.rows.map((p, i) => [i, p.mean]), color: "#3ee0ff", dots: true, width: 2 }, { data: r.rows.map((p, i) => [i, p.mean + p.std]), color: "#3ee0ff55", dash: [3, 3] }, { data: r.rows.map((p, i) => [i, p.mean - p.std]), color: "#3ee0ff55", dash: [3, 3] }],
      { xlabels: [JSON.stringify(r.rows[0].value), JSON.stringify(r.rows[r.rows.length - 1].value)] });
    concl.innerHTML = "";
    concl.append(h("div", { class: "card " + (r.clear_winner ? "glow" : "") }, h("h3", {}, "Conclusion"), h("p", {}, r.conclusion),
      h("table", {}, h("thead", {}, h("tr", {}, ["value", "mean val", "± std", "runs"].map((c) => h("th", {}, c)))), h("tbody", {}, r.rows.map((p) => h("tr", {}, h("td", { class: "mono" }, JSON.stringify(p.value)), h("td", {}, fmt.num(p.mean)), h("td", {}, fmt.num(p.std)), h("td", { class: "faint mono" }, p.runs.map((x) => x.toFixed(3)).join(" "))))))));
  }
  async function load() {
    const e = await api("/api/lab/experiments");
    exps.innerHTML = "";
    exps.append(h("table", {}, h("thead", {}, h("tr", {}, ["#", "Name", "Kind", "Seed", "Status", ""].map((c) => h("th", {}, c)))), h("tbody", {}, e.map((x) => h("tr", {},
      h("td", {}, x.id), h("td", {}, x.name), h("td", {}, x.kind), h("td", {}, x.seed), h("td", {}, tag(x.status)),
      h("td", {}, x.kind === "train" ? h("button", { class: "btn sm", onclick: () => safe(async () => { const r = await api("/api/lab/reproduce/" + x.id, {}); toast(r.identical ? `Reproduced exactly (${r.rerun})` : `Mismatch! ${r.original} vs ${r.rerun}`, !r.identical); }) }, "Reproduce") :
        x.kind === "sweep" ? h("button", { class: "btn sm", onclick: async () => { const d = await api("/api/experiments/" + x.id); show(d.results, d.config.variable); } }, "View") : ""))))));
  }
  put(root, h("h1", {}, "Research Lab"), h("p", { class: "sub" }, "Controlled, reproducible AI experiments. Change one variable, hold everything else fixed, repeat across random seeds, and let the numbers say whether a difference is real."),
    learn("the scientific method for AI", "A single training run can be lucky. Running each setting with several <b>seeds</b> (different random starting weights and data splits) shows the spread. If two settings' ranges overlap, the lab tells you the difference is <b>within noise</b>.",
      "Every experiment stores its full config and seed. <b>Reproduce</b> re-runs it and compares a fingerprint of the training history. Identical fingerprints prove the result is reproducible."),
    h("div", { class: "card", style: { marginBottom: "14px" } }, h("div", { class: "row" }, h("label", {}, "Dataset", ds), h("label", {}, "Variable to test", variable), h("label", { style: { flex: 1 } }, "Values (comma separated)", values),
      h("label", {}, "Seeds", seeds), h("label", {}, "Epochs", epochs)), h("div", { class: "row", style: { marginTop: "10px" } }, go, h("div", { style: { flex: 1 } }, prog))),
    h("div", { class: "grid g2" }, h("div", { class: "card" }, h("h3", {}, "Validation score by setting (mean ± 1 std)"), chart), concl),
    h("div", { class: "card", style: { marginTop: "14px" } }, h("h3", {}, "Experiment log"), exps));
  load();
}
