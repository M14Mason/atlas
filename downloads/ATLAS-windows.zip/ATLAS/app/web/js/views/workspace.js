import { put, api, barChart, canvas, fileToB64, fileToText, fmt, h, learn, lineChart, micButton, safe, waitJob } from "../core.js";

export async function render(root) {
  const st = await api("/api/market");
  const tabs = [["finance", "Finance"], ["learning", "Learning"], ["photo", "Photography"], ["docs", "Documents"], ["code", "Software"], ["research", "Research"]];
  const body = h("div");
  const bar = h("div", { class: "tabs" }, tabs.map(([k, t]) => h("button", { "data-k": k, onclick: () => open(k) }, t)));
  function open(k) { [...bar.children].forEach((b) => b.classList.toggle("active", b.dataset.k === k)); body.innerHTML = ""; ({ finance, learning, photo, docs, code, research })[k](body, st); }
  put(root, h("h1", {}, "Personal AI Workspace"), h("p", { class: "sub" }, "Everyday tools that run on ATLAS's systems."), bar, body);
  open("finance");
}

function finance(root, st) {
  const asset = h("select", {}, st.assets.map((a) => h("option", {}, a)));
  const priceC = canvas(260), mcC = canvas(140); const stats = h("div"); const mc = h("div");
  const imp = h("input", { type: "file", accept: ".csv" }), impName = h("input", { placeholder: "Ticker name" });
  const load = () => safe(async () => {
    const t = await api("/api/workspace/ta?asset=" + asset.value);
    lineChart(priceC, [{ data: t.close, color: "#e6ecf7", width: 1.6 }, { data: t.sma20, color: "#3ee0ff" }, { data: t.sma50, color: "#ffbe3d" }], { xlabels: [t.dates[0], t.dates[t.dates.length - 1]] });
    stats.innerHTML = "";
    stats.append(h("table", {}, h("tbody", {}, [["As of", t.last_date], ["RSI(14)", t.rsi14], ["Annualised volatility (60d)", fmt.pct(t.vol_annual)], ["1-year return", fmt.pct(t.return_1y)], ["1-year max drawdown", fmt.pct(t.max_drawdown_1y)]].map(([k, v]) => h("tr", {}, h("td", { class: "dim" }, k), h("td", { class: "mono" }, v))))),
      h("h3", { style: { marginTop: "10px" } }, "Indicator readings (scaled)"), h("table", {}, h("tbody", {}, Object.entries(t.signals).map(([k, v]) => h("tr", {}, h("td", { class: "mono" }, k), h("td", { class: v > 0 ? "green" : "red" }, v))))), h("p", { class: "faint" }, t.note));
    const m = await api("/api/workspace/montecarlo?asset=" + asset.value);
    barChart(mcC, m.hist, { color: (i) => (i < 10 ? "#ff5d73" : "#3ddc97"), labels: ["-80%", "+150%"] });
    mc.innerHTML = ""; mc.append(h("p", { class: "dim" }, `${m.paths} one-year paths, ${m.method}. Median ${fmt.pct(m.percentiles.p50)}, 5th pct ${fmt.pct(m.percentiles.p5)}, 95th ${fmt.pct(m.percentiles.p95)}. Probability of loss ${fmt.pct(m.prob_loss)}. Past returns do not predict future ones.`));
  });
  asset.onchange = load;
  put(root, learn("reading these indicators", "<b>SMA</b> (simple moving average) smooths price; price above the 50-day SMA is a common uptrend definition. <b>RSI</b> above 70 is called overbought, below 30 oversold, but in strong trends it can stay extreme. <b>Monte Carlo</b> re-samples real past daily returns to show a range of outcomes, not a forecast."),
    h("div", { class: "row", style: { marginBottom: "12px" } }, asset, h("span", { class: "dim" }, "Import a CSV (Date,Close):"), impName, imp, h("button", { class: "btn", onclick: () => safe(async () => { const r = await api("/api/workspace/import", { name: impName.value || "custom", csv: await fileToText(imp.files[0]) }); asset.append(h("option", {}, r.asset)); asset.value = r.asset; load(); }, "Imported") }, "Import")),
    h("div", { class: "grid g3" }, h("div", { class: "card span2" }, h("h3", {}, "Price with SMA20 (cyan) and SMA50 (amber)"), priceC, h("h3", { style: { marginTop: "12px" } }, "Monte Carlo: 1-year return distribution"), mcC, mc), h("div", { class: "card" }, stats)));
  load();
}

async function learning(root) {
  const k = await api("/api/knowledge");
  const sel = h("select", {}, k.docs.map((d) => h("option", { value: d.id }, d.title)));
  const cards = h("div", { class: "cards" });
  const go = h("button", { class: "btn primary" }, "Make flashcards");
  go.onclick = () => safe(async () => { const r = await api("/api/workspace/flashcards", { doc_id: +sel.value }); cards.innerHTML = "";
    if (!r.cards.length) cards.append(h("div", { class: "empty" }, "No definitional sentences found. Connect a model for better cards."));
    r.cards.forEach((c) => { const el = h("div", { class: "flash", onclick: () => el.classList.toggle("flip") }, h("div", { class: "in" }, h("div", { class: "f" }, c.q), h("div", { class: "b" }, c.a))); cards.append(el); });
    cards.append(h("div", { class: "faint", style: { gridColumn: "1/-1", fontSize: "12px" } }, "Method: " + r.method)); });
  put(root, k.docs.length ? h("div", { class: "row", style: { marginBottom: "12px" } }, sel, go) : h("div", { class: "empty" }, "Add a document in the Knowledge Universe first (class notes work well)."), cards);
}

function photo(root) {
  const f = h("input", { type: "file", accept: "image/*" }); const out = h("div"); const prev = h("img", { style: { maxWidth: "100%", borderRadius: "10px", display: "none" } }); const hc = canvas(120);
  f.onchange = () => safe(async () => {
    const file = f.files[0]; prev.src = URL.createObjectURL(file); prev.style.display = "block";
    const r = await api("/api/workspace/image", { file_b64: await fileToB64(file) });
    if (r.error) throw new Error(r.error);
    out.innerHTML = "";
    out.append(h("table", {}, h("tbody", {}, [["Size", r.size.join(" × ")], ["Brightness", r.brightness + " / 255"], ["Contrast (std)", r.contrast], ["Clipped highlights", fmt.pct(r.clipped_highlights)], ["Crushed shadows", fmt.pct(r.clipped_shadows)], ...Object.entries(r.exif)].map(([k, v]) => h("tr", {}, h("td", { class: "dim" }, k), h("td", { class: "mono" }, v))))),
      h("h3", { style: { marginTop: "10px" } }, "Suggestions"), h("ul", {}, r.tips.map((t) => h("li", {}, t))), h("p", { class: "faint" }, r.method));
    barChart(hc, r.histogram, { color: "#a27bff", labels: ["shadows", "highlights"] });
  });
  put(root, learn("the histogram", "It counts pixels at each brightness from black (left) to white (right). A tall spike at either edge means detail was lost there (clipping). Most well-exposed photos spread across the middle."),
    h("div", { class: "grid g2" }, h("div", { class: "card" }, f, h("div", { style: { marginTop: "10px" } }, prev)), h("div", { class: "card" }, h("h3", {}, "Exposure histogram"), hc, out)));
}

function docs(root) {
  const p = h("textarea", { placeholder: "e.g. A one-page study guide on the causes of World War I" }); const out = h("div");
  const go = h("button", { class: "btn primary" }, "Draft document");
  go.onclick = () => safe(async () => { go.disabled = true; try { const { job } = await api("/api/workspace/document", { prompt: p.value }); const r = await waitJob(job); out.innerHTML = ""; out.append(h("div", { class: "msg" }, r.output), h("p", { class: "faint" }, `quality ${r.quality == null ? "ungraded" : r.quality.toFixed(2)} · cost ${fmt.usd(r.cost)} · see the Workforce for who wrote it`)); } finally { go.disabled = false; } });
  put(root, h("div", { class: "card" }, h("div", { class: "row", style: { alignItems: "flex-start" } }, p, micButton(p)), h("div", { style: { marginTop: "8px" } }, go), h("div", { style: { marginTop: "10px" } }, out)));
}

function code(root) {
  const p = h("textarea", { placeholder: "e.g. Write a Python function rsi(prices, n=14) that returns the RSI list" });
  const tests = h("textarea", { placeholder: "Optional unit tests, e.g. assert len(rsi([1,2,3]*10)) > 0", style: { minHeight: "60px" } });
  const out = h("div"); const go = h("button", { class: "btn primary" }, "Write code");
  go.onclick = () => safe(async () => { go.disabled = true; try { const { job } = await api("/api/tasks", { text: p.value + "\nReturn the code in a ```python block.", title: "code" }); const r = await waitJob(job); out.innerHTML = ""; out.append(h("pre", {}, r.output)); } finally { go.disabled = false; } });
  put(root, h("div", { class: "card" }, p, h("div", { style: { margin: "8px 0" } }, tests), go, h("p", { class: "faint", style: { fontSize: "12px" } }, "Code tasks route to a code specialist. Code benchmarks with tests run in the Arena."), out));
}

function research(root) {
  put(root, h("div", { class: "card" }, h("p", {}, "For research, use the ", h("a", { href: "#council" }, "AI Council"), " for decisions that benefit from several models, or the ", h("a", { href: "#workforce" }, "Workforce"), " for multi-step research tasks. Both consult your Knowledge Universe automatically.")));
}
