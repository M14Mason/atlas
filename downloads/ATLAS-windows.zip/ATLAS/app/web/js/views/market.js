import { put, api, barChart, bus, canvas, drawer, emptyState, fmt, h, icon, learn, legend, lineChart, safe, tag, toast, waitJob } from "../core.js";

const SP = { Sprinter: "#3ee0ff", Surfer: "#5b8cff", Navigator: "#a27bff", Contrarian: "#ff6bd5", Hedger: "#ffbe3d" };

export async function render(root) {
  let st = await api("/api/market");
  const world = h("canvas", { style: { height: "420px", cursor: "pointer" } });
  const eqC = canvas(200), fitC = canvas(200), spC = canvas(160), histC = canvas(120);
  const info = h("div"); const genLbl = h("b", {}, "");
  const slider = h("input", { type: "range", min: 0, max: 0, value: 0, style: { width: "100%" } });
  const mode = h("select", {}, h("option", { value: "historical" }, "Real history (replayed in order)"), h("option", { value: "synthetic" }, "Synthetic markets"));
  const asset = h("select", {}, st.assets.map((a) => h("option", { selected: a === st.cfg.asset }, a)));
  const pop = h("input", { type: "number", value: 500, min: 50, max: 2000 });
  const gens = h("input", { type: "number", value: 60, min: 5, max: 500 });
  const cost = h("input", { type: "number", value: 7, step: 0.5 });
  const mut = h("input", { type: "number", value: 0.15, step: 0.01 });
  const seed = h("input", { type: "number", value: 42 });
  const speed = h("input", { type: "range", min: 0, max: 1.5, step: 0.05, value: 0.3 });
  const status = h("span", {});
  const btn = (t, f, cls = "btn") => h("button", { class: cls, onclick: () => safe(f) }, t);
  const start = btn("Start new evolution", async () => { await api("/api/market/start", { config: { mode: mode.value, asset: asset.value, population: +pop.value, generations: +gens.value, cost_bps: +cost.value, mutation: +mut.value, seed: +seed.value, delay: +speed.value } }); refresh(); }, "btn primary");
  speed.oninput = () => api("/api/market/speed", { delay: +speed.value }).catch(() => {});

  // creatures: one per bot, from the latest real generation results
  const creatures = new Map(); let pop_ = [];
  function sync(last) {
    if (!last) return;
    pop_ = last.population;
    const W = world.clientWidth || 900, H = 420;
    const fits = pop_.map((b) => b.fitness); const fmin = Math.min(...fits), fmax = Math.max(...fits);
    const alive = new Set();
    const sp = Object.keys(SP);
    pop_.forEach((b, i) => {
      alive.add(b.id);
      // x: species territory, y: fitness (top = fitter)
      const zone = sp.indexOf(b.species); const zw = W / sp.length;
      const tx = zw * zone + zw * 0.1 + ((b.id * 9301 + 49297) % 233280) / 233280 * zw * 0.8;
      const ty = 30 + (1 - (b.fitness - fmin) / (fmax - fmin + 1e-9)) * (H - 60);
      const c = creatures.get(b.id) || { x: tx, y: H + 20, phase: Math.random() * 7, born: performance.now() };
      Object.assign(c, { tx, ty, b, r: 2 + Math.min(7, Math.sqrt(Math.max(0, b.capital) / 10000) * 3.2) });
      creatures.set(b.id, c);
    });
    for (const [id, c] of creatures) if (!alive.has(id)) { c.dying = c.dying || performance.now(); if (performance.now() - c.dying > 900) creatures.delete(id); }
  }
  let raf;
  function draw(now) {
    const dpr = devicePixelRatio || 1, W = world.clientWidth, H = 420;
    if (world.width !== W * dpr) { world.width = W * dpr; world.height = H * dpr; }
    const x = world.getContext("2d"); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, W, H);
    const sp = Object.keys(SP); const zw = W / sp.length;
    sp.forEach((s, i) => { x.fillStyle = SP[s] + "0c"; x.fillRect(i * zw, 0, zw, H); x.fillStyle = SP[s] + "aa"; x.font = "11px Inter"; x.fillText(s, i * zw + 8, H - 8); });
    x.fillStyle = "#5b6782"; x.font = "10px monospace"; x.fillText("↑ fitter", 6, 14);
    for (const c of creatures.values()) {
      c.x += (c.tx - c.x) * 0.05; c.y += (c.ty - c.y) * 0.05;
      const wob = Math.sin(now / 400 + c.phase) * 1.5;
      const col = SP[c.b.species] || "#fff";
      x.globalAlpha = c.dying ? Math.max(0, 1 - (now - c.dying) / 900) : c.b.survived === false ? 0.28 : 0.9;
      x.fillStyle = col; x.shadowColor = col; x.shadowBlur = c.b.id === st.last?.stats?.champion ? 18 : 4;
      x.beginPath(); x.ellipse(c.x, c.y + wob, c.r * 1.25, c.r, 0, 0, 7); x.fill();
      if (c.r > 4) { x.fillStyle = "#070a12"; x.beginPath(); x.arc(c.x + c.r * 0.45, c.y + wob - c.r * 0.2, Math.max(1, c.r * 0.22), 0, 7); x.fill(); }
      if (c.b.age === 0 && !c.dying) { x.strokeStyle = "#fff"; x.globalAlpha = 0.3; x.beginPath(); x.arc(c.x, c.y + wob, c.r + 3, 0, 7); x.stroke(); }
    }
    x.globalAlpha = 1; x.shadowBlur = 0;
    const champ = [...creatures.values()].find((c) => c.b.id === st.last?.stats?.champion);
    if (champ) { x.strokeStyle = "#fff"; x.lineWidth = 1.2; x.beginPath(); x.arc(champ.x, champ.y, champ.r + 7, 0, 7); x.stroke(); x.fillStyle = "#fff"; x.font = "11px Inter"; x.fillText("champion #" + champ.b.id, champ.x + 12, champ.y - 8); }
    raf = requestAnimationFrame(draw);
  }
  raf = requestAnimationFrame(draw);
  world.onclick = (e) => {
    const r = world.getBoundingClientRect(); const mx = e.clientX - r.left, my = e.clientY - r.top;
    let best = null, bd = 14;
    for (const c of creatures.values()) { const d = Math.hypot(c.x - mx, c.y - my); if (d < bd) { bd = d; best = c; } }
    if (best) inspect(best.b.id);
  };

  async function inspect(id) {
    const b = await safe(() => api("/api/market/bot/" + id));
    const hc = canvas(140);
    const dna = b.dna || {};
    const weights = ["mom5", "mom20", "mom60", "zscore20", "rsi14", "macd", "vol20", "trend50"];
    const tree = (n, d = 0) => h("div", { style: { marginLeft: d * 14 + "px", fontSize: "12px" } }, h("a", { href: "javascript:void 0", onclick: () => inspect(n.id) }, "#" + n.id), n.born != null ? h("span", { class: "faint" }, ` born gen ${n.born}`) : null, (n.parents || []).map((p) => tree(p, d + 1)));
    drawer(h("div", {}, h("h2", {}, `Bot #${b.id} `, b.species ? h("span", { style: { color: SP[b.species] } }, b.species) : null), h("div", { class: "row" }, tag(b.alive ? "alive" : "died gen " + b.died, b.alive ? "ok" : "failed"), h("span", { class: "faint" }, "born generation " + b.born)),
      h("h3", { style: { marginTop: "14px" } }, "Strategy DNA: indicator weights"),
      b.dna ? h("div", { class: "col" }, weights.map((w) => { const v = dna[w]; const pct = Math.min(50, Math.abs(v) * 20); return h("div", { class: "dna" }, h("span", { class: "mono" }, w),
        h("div", { class: "track" }, h("i", { style: { left: v >= 0 ? "50%" : 50 - pct + "%", width: pct + "%", background: v >= 0 ? "#3ddc97" : "#ff5d73" } })), h("span", { class: "mono" }, v)); }),
        h("table", {}, h("tbody", {}, [["bias", dna.bias], ["enter threshold", dna.enter], ["exit (fraction of enter)", dna.exit_frac], ["position size", dna.size], ["stop-loss", fmt.pct(dna.stop_loss)], ["can short", String(dna.can_short)]].map(([k, v]) => h("tr", {}, h("td", { class: "dim" }, k), h("td", { class: "mono" }, v)))))) : h("p", { class: "faint" }, "DNA is kept for living bots and the most recent generation."),
      h("p", { class: "faint", style: { fontSize: "12px" } }, "Signal = tanh(0.5 × Σ weight × indicator + bias). Above +enter: long. Below −enter (if shorting allowed): short. Near zero: flat."),
      h("h3", { style: { marginTop: "14px" } }, "Performance history"), hc,
      h("table", {}, h("thead", {}, h("tr", {}, ["gen", "return", "sharpe", "max DD", "trades", "rank"].map((c) => h("th", {}, c)))), h("tbody", {}, b.history.slice(-10).reverse().map((r) => h("tr", {}, h("td", {}, r.gen), h("td", { class: r.return >= 0 ? "green" : "red" }, fmt.pct(r.return)), h("td", {}, r.sharpe), h("td", {}, fmt.pct(r.mdd)), h("td", {}, r.trades), h("td", {}, r.rank))))),
      h("h3", { style: { marginTop: "14px" } }, "Family tree (ancestors)"), tree(b.family.ancestors),
      h("h3", { style: { marginTop: "10px" } }, "Children"), h("div", {}, b.family.children.length ? b.family.children.map((c) => h("a", { href: "javascript:void 0", style: { marginRight: "8px" }, onclick: () => inspect(c) }, "#" + c)) : h("span", { class: "faint" }, "none yet"))));
    lineChart(hc, [{ data: b.history.map((r) => [r.gen, r.return]), color: "#3ddc97", dots: true }], { zero: true, yfmt: (v) => fmt.pct(v, 1) });
    if (b.dna) {
      const btAsset = h("select", {}, st.assets.map((a) => h("option", {}, a)));
      const btC = canvas(170); const btInfo = h("div", { class: "dim", style: { fontSize: "12px" } });
      const runBt = () => safe(async () => {
        const r = await api("/api/market/backtest", { bot_id: id, asset: btAsset.value });
        lineChart(btC, [{ data: r.curve, color: "#3ee0ff", width: 2 }, { data: r.buy_hold, color: "#8a97b0", dash: [4, 3] }], { yfmt: (v) => v.toFixed(1) + "x", xlabels: [r.from, r.to] });
        btInfo.textContent = `${r.asset} ${r.from} to ${r.to}: bot ${fmt.pct(r.total)} (CAGR ${fmt.pct(r.cagr)}) vs buy & hold ${fmt.pct(r.buy_hold_total)} (CAGR ${fmt.pct(r.bh_cagr)}). Sharpe ${r.sharpe.toFixed(2)}, max drawdown ${fmt.pct(r.max_dd)}, ${r.trades} trades.`;
      });
      btAsset.onchange = runBt;
      const save = h("button", { class: "btn primary" }, icon("star", 14), " Save to Hall of Fame");
      save.onclick = () => safe(async () => { await api("/api/market/hall", { bot_id: id }); loadHall(); }, "Saved to Hall of Fame");
      document.getElementById("drawerBody").append(h("h3", { style: { marginTop: "16px" } }, "Test this strategy on another stock (full history)"),
        h("div", { class: "row" }, btAsset, save), btC, legend([["#3ee0ff", "bot"], ["#8a97b0", "buy & hold"]]), btInfo,
        h("p", { class: "faint", style: { fontSize: "12px" } }, "A strategy that only works on the stock it evolved on is probably memorising noise. One that holds up across stocks is more interesting."));
      runBt();
    }
  }

  function drawCharts(hist, last) {
    if (last) {
      lineChart(eqC, [{ data: last.champion_curve, color: "#3ee0ff", width: 2 }, { data: last.prices, color: "#8a97b0", dash: [4, 3] }], { yfmt: (v) => v.toFixed(2) + "x" });
    }
    lineChart(fitC, [{ data: hist.map((g) => [g.gen, g.best_return]), color: "#3ee0ff" }, { data: hist.map((g) => [g.gen, g.median_return]), color: "#5b8cff" },
      { data: hist.map((g) => [g.gen, g.oos_return]), color: "#ffbe3d", width: 2 }, { data: hist.map((g) => [g.gen, g.buy_hold]), color: "#8a97b0", dash: [4, 3] }], { zero: true, yfmt: (v) => fmt.pct(v, 0) });
    const names = Object.keys(SP);
    lineChart(spC, names.map((n) => ({ data: hist.map((g) => [g.gen, g.species?.[n] || 0]), color: SP[n] })));
    if (last?.stats?.fitness_hist) barChart(histC, last.stats.fitness_hist, { color: (i) => i < 9 ? "#ff5d73" : "#3ddc97", labels: ["fitness -3", "+4"] });
  }
  function showGen(g) {
    const s = st.history.find((x) => x.gen === g) || st.history[st.history.length - 1];
    if (!s) { info.innerHTML = ""; info.append(h("div", { class: "empty" }, "Start an evolution to populate the world.")); return; }
    genLbl.textContent = `Generation ${s.gen}`;
    info.innerHTML = "";
    info.append(h("div", { class: "row" }, tag(s.source === "historical" ? "REAL HISTORICAL DATA" : "SYNTHETIC MARKET", s.source === "historical" ? "ok" : "warn"), s.challenge ? tag("challenge: " + s.challenge.join(", "), "failed") : null),
      h("p", { class: "dim", style: { margin: "8px 0" } }, s.env),
      h("table", {}, h("tbody", {},
        [["Champion", "#" + s.champion], ["Champion return (in-sample)", fmt.pct(s.best_return)], ["Champion return next window (out-of-sample)", fmt.pct(s.oos_return)],
         ["Buy & hold same window", fmt.pct(s.buy_hold)], ["Median bot return", fmt.pct(s.median_return)], ["Bots beating buy & hold", fmt.pct(s.pct_beat_bh, 0)],
         ["Champion Sharpe / max drawdown", `${fmt.num(s.best_sharpe, 2)} / ${fmt.pct(s.best_mdd)}`], ["Transaction cost", s.cost_bps + " bps per trade"]].map(([k, v]) => h("tr", {}, h("td", { class: "dim" }, k), h("td", { class: "mono" }, v))))));
  }
  async function refresh() {
    st = await api("/api/market");
    status.innerHTML = ""; status.append(tag(st.status, st.status === "running" ? "running" : st.status.startsWith("error") ? "error" : "x"), " ", h("span", { class: "dim" }, `gen ${st.gen}/${st.cfg.generations} · ${st.cfg.population} bots · ${st.cfg.mode} ${st.cfg.mode === "historical" ? st.cfg.asset : ""}`));
    slider.max = Math.max(0, st.history.length - 1); slider.value = slider.max;
    sync(st.last); drawCharts(st.history, st.last); showGen(st.history.length ? st.history[st.history.length - 1].gen : 0);
  }
  slider.oninput = () => { const g = st.history[+slider.value]; if (g) showGen(g.gen); };
  let pend;
  const off = bus.on((ev) => { if (ev.dept === "market") { clearTimeout(pend); pend = setTimeout(refresh, 100); } });
  // ---- live data + hall of fame
  const syms = h("input", { placeholder: "Tickers, e.g. NVDA, TSLA, SPY", style: { flex: 1 } });
  const dl = h("button", { class: "btn primary" }, icon("download", 14), " Download latest prices");
  const dlBar = h("div", { class: "bar", style: { width: "100%", marginTop: "8px" } }, h("i", { style: { width: "0%" } }));
  dl.onclick = () => safe(async () => {
    if (!syms.value.trim()) throw new Error("enter at least one ticker");
    dl.disabled = true;
    try {
      const { job } = await api("/api/market/download", { symbols: syms.value });
      const r = await waitJob(job, (j) => (dlBar.firstChild.style.width = j.progress * 100 + "%"));
      toast(`Downloaded ${r.downloaded.map((d) => `${d.asset} (${d.rows} days to ${d.last})`).join(", ")}` + (r.failed.length ? `. Failed: ${r.failed.join("; ")}` : ""));
      st = await api("/api/market"); asset.innerHTML = ""; st.assets.forEach((a) => asset.append(h("option", {}, a)));
    } finally { dl.disabled = false; }
  });
  const hall = h("div");
  async function loadHall() {
    const rows = await api("/api/market/hall");
    hall.innerHTML = "";
    if (!rows.length) return hall.append(emptyState("star", "Hall of Fame is empty", "Click a creature, then Save to Hall of Fame. Strategies here can be exported as callable AI systems."));
    hall.append(h("table", {}, h("thead", {}, h("tr", {}, ["Bot", "Evolved on", "In-sample", "Out-of-sample", "Buy & hold", ""].map((c) => h("th", {}, c)))),
      h("tbody", {}, rows.map((r) => h("tr", {}, h("td", {}, "#" + r.bot_id), h("td", {}, `${r.asset} (${r.mode}) gen ${r.gen}`), h("td", {}, fmt.pct(r.in_sample)),
        h("td", { class: r.oos > r.buy_hold ? "green" : "red" }, fmt.pct(r.oos)), h("td", {}, fmt.pct(r.buy_hold)),
        h("td", {}, h("button", { class: "btn sm", onclick: () => safe(async () => { const x = await api(`/api/market/hall/${r.id}/export`, {}); toast(`Exported as system #${x.system_id} (${x.passed ? "beat" : "did not beat"} buy & hold over full history). Open it in Build > Built Systems.`); }) }, "Export as AI system")))))));
  }
  loadHall();

  put(root, h("h1", {}, "Evolutionary Market Lab"),
    h("p", { class: "sub" }, "Artificial life for trading research. Hundreds of bots with random strategy DNA compete with virtual money; the weak die, the strong reproduce and mutate. ", h("b", { class: "amber" }, "Virtual money only. Not connected to any broker. Not investment advice.")),
    learn("how to read this honestly", "<b>In-sample</b> is the window the bots were selected on, so the champion will always look good there. The amber <b>out-of-sample</b> line is the same champion on the NEXT window it has never seen. That is the number that matters. If it hugs zero or sits below buy & hold (grey dashed), the population is overfitting noise.",
      "No future data leaks in: indicators on day t use only prices up to day t, and the position chosen at day t's close earns day t+1's return. Real history comes from daily 2007-2016 prices (including the 2008 crash). Synthetic markets are labelled as such.",
      "Each creature is one bot. Colour = species (its dominant indicator). Height = fitness. Size = ending capital. White ring = newborn. Faded = eliminated by selection at the end of this generation. Click any creature to see its DNA and family tree."),
    h("div", { class: "card", style: { marginBottom: "14px" } }, h("div", { class: "grid g6" }, h("label", {}, "Environment", mode), h("label", {}, "Asset", asset), h("label", {}, "Population", pop), h("label", {}, "Generations", gens), h("label", {}, "Cost (bps)", cost), h("label", {}, "Mutation rate", mut)),
      h("div", { class: "row", style: { marginTop: "10px" } }, h("label", {}, "Seed", seed), h("label", { style: { flex: 1 } }, "Speed (delay between generations)", speed), start,
        btn("Pause", async () => { await api("/api/market/pause", {}); refresh(); }), btn("Resume", async () => { await api("/api/market/resume", {}); refresh(); }),
        btn("Step 1 gen", async () => { await api("/api/market/step", {}); refresh(); }), btn("Stop", async () => { await api("/api/market/stop", {}); refresh(); })),
      h("div", { class: "row", style: { marginTop: "10px" } }, h("span", { class: "dim" }, "Environmental challenges (synthetic mode):"),
        btn("Market crash", () => api("/api/market/challenge", { kind: "crash" }), "btn sm danger"), btn("Volatility spike", () => api("/api/market/challenge", { kind: "volatility" }), "btn sm"),
        btn("Cost shock ×5", () => api("/api/market/challenge", { kind: "cost_shock" }), "btn sm"), status)),
    h("div", { class: "grid g3" },
      h("div", { class: "card span2" }, h("div", { class: "row between" }, h("h3", {}, "Population world"), legend(Object.entries(SP).map(([n, c]) => [c, n]))), h("div", { class: "canvas-wrap" }, world)),
      h("div", { class: "card" }, h("div", { class: "row between" }, genLbl, h("span", { class: "faint" }, "replay")), slider, info)),
    h("div", { class: "grid g2", style: { marginTop: "14px" } },
      h("div", { class: "card" }, h("h3", {}, "Champion equity vs asset (current generation)"), eqC, legend([["#3ee0ff", "champion"], ["#8a97b0", "buy & hold"]])),
      h("div", { class: "card" }, h("h3", {}, "Returns by generation"), fitC, legend([["#3ee0ff", "champion in-sample"], ["#5b8cff", "median bot"], ["#ffbe3d", "champion out-of-sample"], ["#8a97b0", "buy & hold"]])),
      h("div", { class: "card" }, h("h3", {}, "Species population over time"), spC),
      h("div", { class: "card" }, h("h3", {}, "Fitness distribution (current generation)"), histC)),
    h("div", { class: "grid g3", style: { marginTop: "14px" } },
      h("div", { class: "card" }, h("h3", {}, "Live market data"), h("p", { class: "dim", style: { fontSize: "13px" } }, "Download up to 10 years of daily prices (Alpaca if your keys are set, otherwise Yahoo Finance or Stooq). New tickers appear in every asset menu. Automate a daily refresh in Automations."),
        h("div", { class: "row" }, syms, dl), dlBar),
      h("div", { class: "card span2" }, h("h3", {}, "Hall of Fame"), hall)));
  refresh();
  return () => { cancelAnimationFrame(raf); off(); };
}
