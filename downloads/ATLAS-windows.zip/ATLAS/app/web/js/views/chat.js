import { api, emptyState, fmt, h, icon, micButton, put, safe, toast, waitJob } from "../core.js";

export async function render(root) {
  const models = await api("/api/models");
  let conv = null;
  const list = h("div", { class: "chat-list" });
  const log = h("div", { class: "chat-log" });
  const input = h("textarea", { placeholder: "Ask anything… (Enter to send, Shift+Enter for a new line)", rows: 1 });
  const model = h("select", {}, h("option", { value: "auto" }, "Auto (cheapest capable)"),
    models.map((m) => h("option", { value: m.id, disabled: !m.available }, m.name + (m.available ? "" : " (offline)"))));
  const useK = h("input", { type: "checkbox", checked: true }), useW = h("input", { type: "checkbox" });
  const send = h("button", { class: "btn primary", title: "Send" }, icon("send"));

  function bubble(m) {
    const meta = m.role === "assistant" ? h("div", { class: "meta" }, h("span", {}, m.model), m.cost ? h("span", {}, fmt.usd(m.cost)) : h("span", {}, "free"),
      (m.sources || []).map((s) => s.url ? h("a", { class: "src", href: s.url, target: "_blank" }, `${s.tag} ${s.title.slice(0, 40)}`) : h("span", { class: "src" }, `${s.tag} ${s.title.slice(0, 40)}`)),
      h("a", { href: "javascript:void 0", onclick: () => { navigator.clipboard?.writeText(m.content); toast("Copied"); } }, "copy")) : null;
    return h("div", { class: "bubble " + (m.role === "user" ? "user" : "ai") }, m.content, meta);
  }
  async function loadList() {
    const c = await api("/api/chat/conversations");
    list.innerHTML = "";
    list.append(h("button", { class: "btn", style: { width: "100%", marginBottom: "8px" }, onclick: () => open(null) }, icon("plus"), " New chat"));
    c.forEach((x) => list.append(h("div", { class: "chat-item" + (x.id === conv ? " on" : ""), onclick: () => open(x.id), title: x.title }, x.title)));
  }
  async function open(id) {
    conv = id; log.innerHTML = "";
    if (!id) {
      log.append(emptyState("chat", "Ask ATLAS anything", "Answers use your Knowledge Universe automatically. Turn on Web to research live pages with cited sources."),
        h("div", { class: "row", style: { justifyContent: "center", marginTop: "10px" } }, ["Explain how a neural network learns", "What caused the 2008 crisis?", "Calculate 1250 * 1.07^5", "Give me 5 trading strategy ideas to test in the Market Lab"].map((s) =>
          h("button", { class: "btn sm", onclick: () => { input.value = s; go(); } }, s))));
    } else (await api("/api/chat/" + id)).forEach((m) => log.append(bubble(m)));
    log.scrollTop = log.scrollHeight; loadList();
  }
  async function go() {
    const text = input.value.trim(); if (!text) return;
    if (!conv) log.innerHTML = "";
    input.value = ""; send.disabled = true;
    log.append(bubble({ role: "user", content: text }));
    const typing = h("div", { class: "bubble ai typing" }, h("span"), h("span"), h("span"));
    log.append(typing); log.scrollTop = log.scrollHeight;
    try {
      const { job } = await api("/api/chat/send", { conv_id: conv, text, model: model.value, knowledge: useK.checked, web: useW.checked });
      const r = await waitJob(job);
      typing.remove();
      log.append(bubble({ role: "assistant", content: r.text, model: r.model, cost: r.cost, sources: r.sources }));
      if (!conv) { conv = r.conv_id; loadList(); }
    } catch (e) { typing.remove(); toast(e.message, true); }
    finally { send.disabled = false; log.scrollTop = log.scrollHeight; input.focus(); }
  }
  send.onclick = go;
  input.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); go(); } };
  input.oninput = () => { input.style.height = "auto"; input.style.height = Math.min(200, input.scrollHeight) + "px"; };
  const exp = h("button", { class: "btn sm" }, icon("download", 12), " Export");
  exp.onclick = () => safe(async () => {
    if (!conv) throw new Error("open a chat first");
    const ms = await api("/api/chat/" + conv);
    const md = ms.map((m) => `### ${m.role === "user" ? "You" : "ATLAS (" + m.model + ")"}\n\n${m.content}\n` + ((m.sources || []).length ? "\nSources: " + m.sources.map((s) => `${s.tag} ${s.url || s.title}`).join("; ") + "\n" : "")).join("\n");
    const a = h("a", { href: URL.createObjectURL(new Blob([md], { type: "text/markdown" })), download: `atlas-chat-${conv}.md` }); a.click();
  });
  const del = h("button", { class: "btn sm danger" }, "Delete chat");
  del.onclick = () => safe(async () => {
    if (!conv) return;
    const c = await api(`/api/chat/${conv}/delete`, {});
    if (!confirm("Delete this conversation? This cannot be undone.")) return;
    if (!confirm("Are you sure? Second confirmation.")) return;
    await api(`/api/chat/${conv}/delete`, { confirm_token: c.confirm_token }); open(null);
  }, "Deleted");
  put(root, h("div", { class: "hero" }, h("h1", {}, icon("chat", 22), "Ask ATLAS"), h("div", { class: "row" }, model,
      h("label", { class: "switch" }, useK, "Knowledge"), h("label", { class: "switch", title: "Search and read live web pages (needs internet)" }, useW, icon("globe", 14), "Web"), exp, del)),
    h("div", { class: "chat" }, h("div", { class: "card chat-list" }, list),
      h("div", { class: "chat-main" }, log, h("div", { class: "composer" }, input, micButton(input), send))));
  open(null);
  const pre = sessionStorage.getItem("atlas_prefill");
  if (pre) { sessionStorage.removeItem("atlas_prefill"); input.value = pre; go(); }
  input.focus();
}
