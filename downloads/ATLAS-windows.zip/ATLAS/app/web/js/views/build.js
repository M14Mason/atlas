import { put, api, bus, canvas, fileToText, fmt, h, learn, legend, lineChart, micButton, safe, tag, toast, waitJob } from "../core.js";

const STAGES = ["understand", "research", "design", "build", "train", "test", "debug", "package", "deploy"];

export async function render(root) {
  const body = h("div");
  const tabs = [["architect", "AI Architect + Cockpit"], ["systems", "Built Systems"], ["groundup", "Ground-Up AI"], ["agent", "Agent Builder"], ["model", "Model Builder"]];
  const bar = h("div", { class: "tabs" }, tabs.map(([k, t]) => h("button", { "data-k": k, onclick: () => open(k) }, t)));
  let cleanup = null;
  function open(k) {
    [...bar.children].forEach((b) => b.classList.toggle("active", b.dataset.k === k));
    if (cleanup) cleanup(); body.innerHTML = "";
    cleanup = { architect, systems, groundup, agent, model }[k](body) || null;
  }
  put(root, h("h1", {}, "Build"), h("p", { class: "sub" }, "Create AI systems: describe one to the Architect, design a network by hand, configure agents, or train and fine-tune models."), bar, body);
  open("architect");
  return () => cleanup && cleanup();
}

// ------------------------------------------------------------------ Architect + Cockpit
const EXAMPLES = [
  ["Pattern classifier", "Build an AI that learns to classify the spiral pattern"],
  ["Spam detector", "Spam detector for my texts:\nWIN a FREE iPhone now -> spam\nClaim your cash prize today -> spam\nCheap meds online click here -> spam\nYou won $1000 click link -> spam\nLimited offer buy now FREE -> spam\nURGENT your account prize winner -> spam\nFree money no catch click -> spam\nAre we still meeting for lunch -> ham\nCan you send the homework -> ham\nPractice is at 5 today -> ham\nMom says dinner at 7 -> ham\nDid you finish the essay -> ham\nSee you at school tomorrow -> ham\nCan I borrow your charger -> ham"],
  ["Market forecaster", "Predict whether the S&P 500 (GSPC) goes up tomorrow"],
  ["Evolved strategy", "Evolve a trading strategy for AAPL"],
  ["Tutor agent", "A tutor agent that explains algebra step by step"],
];

function architect(root) {
  const desc = h("textarea", { placeholder: "Describe the AI you want. For a tabular model, attach a CSV. For a text classifier, list examples as: text -> label" , style: { minHeight: "120px" } });
  const name = h("input", { placeholder: "Name (optional)" });
  const csvIn = h("input", { type: "file", accept: ".csv,text/csv" });
  const target = h("input", { placeholder: "Target column (CSV only, default: last)" });
  const synth = h("input", { type: "checkbox", checked: true });
  const go = h("button", { class: "btn primary" }, "Build it");
  const stages = h("div", { class: "stages" }, STAGES.map((s) => h("div", { class: "stage", "data-s": s }, s)));
  const log = h("div", { class: "feed", style: { maxHeight: "340px" } });
  const chart = canvas(200);
  const verdict = h("div");
  const prog = h("div", { class: "bar" }, h("i", { style: { width: "0%" } }));
  let sysId = null; let trainSeries = [];
  const off = bus.on((ev) => {
    if (ev.dept !== "architect") return;
    if (sysId == null) sysId = ev.data.system_id;
    if (ev.data.system_id !== sysId) return;
    const d = ev.data; const i = STAGES.indexOf(d.stage);
    [...stages.children].forEach((el, k) => { el.classList.toggle("done", k < i); el.classList.toggle("active", k === i); });
    log.append(h("div", { class: "msg phase-" + (d.stage === "debug" ? "critique" : "answer") }, h("div", { class: "who" }, d.stage.toUpperCase(), " ", h("span", { class: "to" }, fmt.time(ev.ts))), d.msg));
    log.scrollTop = log.scrollHeight;
    if (d.history) { trainSeries.push({ name: d.msg.split(":")[0], data: d.history.map((r) => [r.epoch, r.val_metric]) }); drawTrain(); }
    if (d.stage === "test" && d.test != null) verdict.prepend(h("div", { class: "card " + (d.passed ? "glow" : ""), style: { borderColor: d.passed ? "rgba(61,220,151,.5)" : "rgba(255,93,115,.5)", marginBottom: "8px" } },
      h("div", { class: "row between" }, h("b", {}, d.passed ? "Passed held-out test" : "Did not beat baseline"), tag(d.passed ? "PASS" : "FAIL")),
      h("p", { class: "dim" }, `Test ${fmt.num(d.test)} vs baseline ${fmt.num(d.baseline)}`)));
  });
  const COLS = ["#3ee0ff", "#a27bff", "#ffbe3d", "#3ddc97", "#ff6bd5"];
  function drawTrain() { lineChart(chart, trainSeries.map((s, i) => ({ ...s, color: COLS[i % 5] })), { y: [0, 1] }); }
  go.onclick = () => safe(async () => {
    if (!desc.value.trim()) throw new Error("describe the AI first");
    let csv = null; if (csvIn.files[0]) csv = await fileToText(csvIn.files[0]);
    go.disabled = true; sysId = null; trainSeries = []; log.innerHTML = ""; verdict.innerHTML = "";
    [...stages.children].forEach((el) => el.className = "stage");
    const { job } = await api("/api/architect", { description: desc.value, name: name.value || null, csv, target: target.value || null, allow_synthetic: synth.checked });
    try {
      const r = await waitJob(job, (j) => (prog.firstChild.style.width = (j.progress * 100) + "%"));
      [...stages.children].forEach((el) => { el.classList.remove("active"); });
      verdict.append(h("div", { class: "card" }, h("div", { class: "row between" }, h("b", {}, "Result: ", r.status), r.system_id ? h("a", { href: "#build", onclick: () => toast("See the Built Systems tab") }, "System #" + r.system_id) : null),
        r.error ? h("p", { class: "red" }, r.error) : null));
    } finally { go.disabled = false; }
  });
  const pre = sessionStorage.getItem("atlas_prefill");
  if (pre) { sessionStorage.removeItem("atlas_prefill"); desc.value = pre; }
  put(root, learn("what the Architect does", "It reads your description, decides what kind of AI fits (tabular model, text classifier, forecaster, evolved strategy, pattern classifier or LLM agent), checks what ATLAS already knows, then runs a small <b>architecture search</b>: it trains several real networks and keeps the best on validation data.",
    "Then it tests on data the model never saw and compares against a <b>naive baseline</b> (e.g. always guessing the most common answer). It only deploys if it wins. If it loses, it tries to debug (simpler, more regularised model) and tells you honestly if it still fails."),
    h("div", { class: "grid g3" },
      h("div", { class: "card span2" }, h("h3", {}, "Describe the AI"), h("div", { class: "row", style: { alignItems: "flex-start" } }, desc, micButton(desc)),
        h("div", { class: "row", style: { marginTop: "8px" } }, EXAMPLES.map(([t, d]) => h("button", { class: "btn sm", onclick: () => (desc.value = d) }, t))),
        h("div", { class: "grid g3", style: { marginTop: "10px" } }, name, h("label", {}, "CSV data (optional)", csvIn), target),
        h("div", { class: "row", style: { marginTop: "10px" } }, h("label", { class: "inline" }, synth, "Allow model-generated training examples (marked synthetic)"), go)),
      h("div", { class: "card" }, h("h3", {}, "Progress"), prog, h("div", { style: { marginTop: "12px" } }, verdict))),
    h("div", { class: "card glow", style: { marginTop: "14px" } }, h("h3", {}, "AI Creation Cockpit (live)"), stages,
      h("div", { class: "grid g2", style: { marginTop: "12px" } },
        h("div", {}, h("h3", {}, "Decisions, experiments and debugging"), log),
        h("div", {}, h("h3", {}, "Training runs: validation score by epoch"), chart, h("p", { class: "faint", style: { fontSize: "12px" } }, "Each line is one real candidate architecture the Architect trained.")))));
  return off;
}

// ------------------------------------------------------------------ Built systems
function systems(root) {
  const list = h("div");
  const load = async () => {
    const s = await api("/api/systems");
    list.innerHTML = "";
    if (!s.length) return list.append(h("div", { class: "empty" }, "Nothing built yet. Use the Architect."));
    list.append(h("table", {}, h("thead", {}, h("tr", {}, ["#", "Name", "Approach", "Status", "Test vs baseline", "v", ""].map((c) => h("th", {}, c)))),
      h("tbody", {}, s.map((x) => h("tr", {}, h("td", {}, x.id), h("td", {}, x.name), h("td", { class: "mono" }, x.approach || "-"), h("td", {}, tag(x.status)),
        h("td", {}, x.summary.test != null ? `${fmt.num(x.summary.test)} vs ${fmt.num(x.summary.baseline)}` : x.summary.oos_mean != null ? `OOS ${fmt.pct(x.summary.oos_mean)} vs B&H ${fmt.pct(x.summary.buy_hold_mean)}` : x.summary.exam != null ? "exam " + fmt.num(x.summary.exam, 2) : x.summary.error || "-"),
        h("td", {}, x.version), h("td", {}, h("button", { class: "btn sm", onclick: () => detail(x.id) }, "Open")))))));
  };
  const panel = h("div", { style: { marginTop: "14px" } });
  async function detail(id) {
    const s = await api("/api/systems/" + id);
    const inp = h("textarea", { style: { minHeight: "60px" }, placeholder: s.package?.type === "mlp" && s.package.schema?.features && typeof s.package.schema.features[0] === "object" ? JSON.stringify(Object.fromEntries(s.package.schema.features.map((f) => [f.col, f.type === "num" ? 0 : f.values[0]]))) : s.package?.type === "mlp" && !s.package.schema?.features ? "type some text" : s.package?.schema?.dataset ? "[0.5, -0.2]" : "input" });
    const out = h("pre", {}, "");
    const run = h("button", { class: "btn primary" }, "Run");
    run.onclick = () => safe(async () => { let v = inp.value; try { v = JSON.parse(v); } catch {} out.textContent = JSON.stringify(await api(`/api/systems/${id}/predict`, { input: v }), null, 1); });
    const ft = h("input", { type: "file", accept: ".csv" });
    const ftb = h("button", { class: "btn" }, "Fine-tune on new CSV");
    ftb.onclick = () => safe(async () => { if (!ft.files[0]) throw new Error("choose a CSV"); const r = await api(`/api/systems/${id}/finetune`, { csv: await fileToText(ft.files[0]) }); toast(`v${r.version}: test ${fmt.num(r.test)} (was ${fmt.num(r.previous_test)})`); detail(id); load(); });
    const rb = h("button", { class: "btn" }, "Roll back version");
    rb.onclick = () => safe(async () => { await api(`/api/systems/${id}/rollback`, {}); detail(id); load(); }, "Rolled back");
    const hist = (s.metrics?.history || []);
    const c = canvas(180);
    panel.innerHTML = "";
    panel.append(h("div", { class: "card" }, h("div", { class: "row between" }, h("h2", {}, s.name), h("div", { class: "row" }, tag(s.status), h("a", { class: "btn sm", href: `/api/systems/${id}/download` }, "Download package (.zip)"))),
      h("p", { class: "dim" }, s.description.split("\n")[0]),
      h("div", { class: "grid g2" },
        h("div", {}, h("h3", {}, "Try it"), inp, h("div", { class: "row", style: { marginTop: "8px" } }, run), out,
          s.package?.type === "mlp" && !s.package.vocab ? h("div", { style: { marginTop: "10px" } }, h("h3", {}, "Model Builder"), h("div", { class: "row" }, ft, ftb, rb)) : null),
        h("div", {}, h("h3", {}, "Training curve"), c, h("h3", { style: { marginTop: "10px" } }, "Build log"),
          h("div", { class: "feed", style: { maxHeight: "220px" } }, (s.metrics?.log || []).map((l) => h("div", { class: "ev", style: { gridTemplateColumns: "80px 1fr" } }, h("span", { class: "d cyan" }, l.stage), h("span", {}, l.msg))))))));
    if (hist.length) lineChart(c, [{ data: hist.map((r) => [r.epoch, r.train_metric]), color: "#5b8cff" }, { data: hist.map((r) => [r.epoch, r.val_metric]), color: "#3ee0ff" }], { y: [0, 1] });
  }
  put(root, list, panel);
  load();
}

// ------------------------------------------------------------------ Ground-Up AI
function groundup(root) {
  let layers = [16, 16];
  const ds = h("select", {}, ["spiral", "moons", "circles", "xor", "blobs", "sine"].map((d) => h("option", {}, d)));
  const act = h("select", {}, ["relu", "tanh", "sigmoid", "gelu"].map((d) => h("option", {}, d)));
  const opt = h("select", {}, ["adam", "momentum", "sgd"].map((d) => h("option", {}, d)));
  const lr = h("input", { type: "number", value: 0.01, step: 0.001 });
  const ep = h("input", { type: "number", value: 200 });
  const noise = h("input", { type: "number", value: 0.2, step: 0.05 });
  const drop = h("input", { type: "number", value: 0, step: 0.05, min: 0, max: 0.8 });
  const seed = h("input", { type: "number", value: 0 });
  const remote = h("input", { type: "checkbox" });
  const layerBox = h("div", { class: "col" });
  const netC = canvas(200), lossC = canvas(200), boundC = canvas(300);
  const stats = h("div");
  const go = h("button", { class: "btn primary" }, "Train from scratch");
  const drawLayers = () => {
    layerBox.innerHTML = "";
    layers.forEach((u, i) => layerBox.append(h("div", { class: "row" }, h("span", { class: "dim", style: { width: "70px" } }, "Hidden " + (i + 1)),
      h("input", { type: "number", value: u, min: 1, max: 256, style: { width: "80px" }, oninput: (e) => { layers[i] = Math.max(1, +e.target.value | 0); drawNet(); } }),
      h("button", { class: "btn sm", onclick: () => { layers.splice(i, 1); drawLayers(); } }, "remove"))));
    layerBox.append(h("button", { class: "btn sm", onclick: () => { if (layers.length < 6) layers.push(8); drawLayers(); } }, "+ add layer"));
    drawNet();
  };
  function drawNet() {
    const dpr = devicePixelRatio || 1, W = netC.clientWidth || 500, H = 200; netC.width = W * dpr; netC.height = H * dpr;
    const x = netC.getContext("2d"); x.setTransform(dpr, 0, 0, dpr, 0, 0);
    const nOut = ds.value === "sine" ? 1 : ds.value === "spiral" ? 3 : ds.value === "blobs" ? 4 : 2;
    const sizes = [ds.value === "sine" ? 1 : 2, ...layers, nOut];
    const cols = sizes.map((s, i) => { const n = Math.min(s, 12); return Array.from({ length: n }, (_, k) => [30 + i * (W - 60) / (sizes.length - 1), H / 2 + (k - (n - 1) / 2) * Math.min(16, (H - 30) / n)]); });
    x.strokeStyle = "rgba(91,140,255,.18)";
    for (let i = 0; i < cols.length - 1; i++) for (const a of cols[i]) for (const b of cols[i + 1]) { x.beginPath(); x.moveTo(...a); x.lineTo(...b); x.stroke(); }
    cols.forEach((c, i) => { c.forEach(([px, py]) => { x.fillStyle = i === 0 ? "#3ee0ff" : i === cols.length - 1 ? "#ff6bd5" : "#a27bff"; x.beginPath(); x.arc(px, py, 5, 0, 7); x.fill(); });
      x.fillStyle = "#8a97b0"; x.font = "10px monospace"; x.textAlign = "center"; x.fillText(sizes[i] + (sizes[i] > 12 ? " (12 shown)" : ""), c[0][0], H - 4); });
    let params = 0; for (let i = 0; i < sizes.length - 1; i++) params += sizes[i] * sizes[i + 1] + sizes[i + 1];
    x.textAlign = "left"; x.fillText(params + " parameters", 6, 12);
  }
  ds.onchange = drawNet;
  const PAL = ["#3ee0ff", "#ff6bd5", "#ffbe3d", "#3ddc97"];
  function drawBoundary(snap, points) {
    const dpr = devicePixelRatio || 1, W = boundC.clientWidth || 300, H = 300; boundC.width = W * dpr; boundC.height = H * dpr;
    const x = boundC.getContext("2d"); x.setTransform(dpr, 0, 0, dpr, 0, 0);
    const S = Math.min(W, H), ox = (W - S) / 2, n = 40, cell = S / n;
    if (snap) for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { x.fillStyle = PAL[snap.grid[i * n + j]] + "33"; x.fillRect(ox + j * cell, S - (i + 1) * cell, cell + 0.5, cell + 0.5); }
    const sc = (v) => (v + 2.5) / 5 * S;
    if (points) points.X.forEach((p, k) => { x.fillStyle = PAL[points.y[k]] || "#fff"; x.beginPath(); x.arc(ox + sc(p[0]), S - sc(p[1]), 2.4, 0, 7); x.fill(); });
    if (snap) { x.fillStyle = "#e6ecf7"; x.font = "11px monospace"; x.fillText("epoch " + snap.epoch, ox + 6, 14); }
  }
  let replay;
  go.onclick = () => safe(async () => {
    go.disabled = true; clearInterval(replay);
    const cfg = { dataset: ds.value, hidden: layers, activation: act.value, optimizer: opt.value, lr: +lr.value, epochs: +ep.value, noise: +noise.value, dropout: +drop.value, seed: +seed.value };
    const live = []; let eid = null;
    const off = bus.on((ev) => {
      if (ev.dept !== "research") return;
      if (ev.kind === "experiment_started" && eid == null) eid = ev.data.experiment;
      if (ev.kind === "epoch" && ev.data.experiment === eid) { live.push(ev.data); lineChart(lossC, [{ data: live.map((r) => [r.epoch, r.loss]), color: "#ff6bd5" }, { data: live.map((r) => [r.epoch, r.val_loss]), color: "#3ee0ff", dash: [4, 3] }]); }
    });
    try {
      const { job } = await api("/api/lab/train", { config: cfg, remote: remote.checked });
      const r = await waitJob(job);
      lineChart(lossC, [{ data: r.history.map((x) => [x.epoch, x.loss]), color: "#ff6bd5" }, { data: r.history.map((x) => [x.epoch, x.val_loss]), color: "#3ee0ff", dash: [4, 3] }]);
      stats.innerHTML = "";
      stats.append(h("div", { class: "grid g4" }, ["train", "val", "test"].map((k) => h("div", { class: "card kpi" }, h("div", { class: "l" }, k + " " + r.metrics.metric_name), h("div", { class: "v" }, fmt.num(r.metrics[k])))),
        h("div", { class: "card kpi" }, h("div", { class: "l" }, "parameters"), h("div", { class: "v" }, r.params), h("div", { class: "s" }, "fingerprint " + r.fingerprint))));
      if (r.snapshots?.length) { let k = 0; replay = setInterval(() => { drawBoundary(r.snapshots[k], r.points); k++; if (k >= r.snapshots.length) clearInterval(replay); }, 350); }
      else drawBoundary(null, r.points?.X?.[0]?.length === 2 ? r.points : null);
    } finally { off(); go.disabled = false; }
  });
  put(root, learn("how a neural network learns", "Each layer computes <b>weights × inputs + bias</b>, then an <b>activation</b> (like ReLU) bends the result. Stacking layers lets the network draw curved boundaries.",
    "Training repeats: predict, measure the error (<b>loss</b>), use <b>backpropagation</b> to find how each weight affected the error, nudge every weight a little (<b>learning rate</b>). If validation loss rises while training loss falls, the network is memorising instead of learning (<b>overfitting</b>): add dropout or use fewer units.",
    "This is ATLAS's own numpy implementation, checked against numerical gradients. The boundary animation replays real snapshots captured during training."),
    h("div", { class: "grid g3" },
      h("div", { class: "card" }, h("h3", {}, "Architecture"), layerBox, h("div", { class: "grid g2", style: { marginTop: "10px" } },
        h("label", {}, "Dataset", ds), h("label", {}, "Activation", act), h("label", {}, "Optimizer", opt), h("label", {}, "Learning rate", lr),
        h("label", {}, "Epochs", ep), h("label", {}, "Noise", noise), h("label", {}, "Dropout", drop), h("label", {}, "Seed", seed)),
        h("label", { class: "inline", style: { marginTop: "8px" } }, remote, "Prefer a remote worker if one is online"),
        h("div", { style: { marginTop: "10px" } }, go)),
      h("div", { class: "card span2" }, h("h3", {}, "Network"), netC, h("div", { class: "grid g2", style: { marginTop: "10px" } },
        h("div", {}, h("h3", {}, "Loss (live)"), lossC, legend([["#ff6bd5", "training loss"], ["#3ee0ff", "validation loss"]])),
        h("div", {}, h("h3", {}, "Decision boundary over training"), boundC)))),
    h("div", { style: { marginTop: "14px" } }, stats));
  drawLayers();
  return () => clearInterval(replay);
}

// ------------------------------------------------------------------ Agent Builder
function agent(root) {
  (async () => {
    const agents = await api("/api/agents"); const models = await api("/api/models");
    const name = h("input", { placeholder: "e.g. Source Verifier" });
    const spec = h("select", {}, ["general", "research", "verification", "analysis", "writing", "code", "math", "finance"].map((s) => h("option", {}, s)));
    const parent = h("select", {}, h("option", { value: "" }, "independent"), agents.map((a) => h("option", { value: a.id }, a.name)));
    const model = h("select", {}, h("option", { value: "auto" }, "auto (cheapest proven)"), models.map((m) => h("option", { value: m.id }, `${m.name}${m.available ? "" : " (not configured)"}`)));
    const sys = h("textarea", { placeholder: "System prompt: who this agent is and how it should work" });
    const tools = ["knowledge", "calculator", "remember"].map((t) => h("label", { class: "inline" }, h("input", { type: "checkbox", value: t, checked: t !== "remember" }), t));
    const deleg = h("input", { type: "checkbox" });
    const make = h("button", { class: "btn primary" }, "Create agent");
    make.onclick = () => safe(async () => {
      if (!name.value) throw new Error("name required");
      const r = await api("/api/agents", { name: name.value, specialty: spec.value, parent_id: parent.value ? +parent.value : null, model: model.value, system: sys.value || null,
        tools: tools.map((l) => l.querySelector("input")).filter((i) => i.checked).map((i) => i.value), can_delegate: deleg.checked, role: deleg.checked ? "manager" : "specialist" });
      toast(`Agent #${r.id} created on probation. Evaluate it in the Workforce to make it trusted.`);
    });
    put(root, learn("memory vs skills vs parameters", "<b>Memory</b>: the agent stores facts it can look up later (tool: remember). <b>Skills</b>: reusable procedures stored in the Knowledge Universe. <b>Parameters</b>: actual model weights changed by training (Model Builder). Only training changes what the model itself is."),
      h("div", { class: "card", style: { maxWidth: "760px" } }, h("div", { class: "grid g2" }, h("label", {}, "Name", name), h("label", {}, "Specialty", spec), h("label", {}, "Manager", parent), h("label", {}, "Model", model)),
        h("label", { style: { marginTop: "10px" } }, "Instructions", sys), h("div", { class: "row", style: { marginTop: "8px" } }, h("span", { class: "dim" }, "Tools:"), tools, h("label", { class: "inline" }, deleg, "Can delegate (manager)")),
        h("div", { style: { marginTop: "10px" } }, make)));
  })();
}

// ------------------------------------------------------------------ Model Builder
function model(root) {
  const minq = h("input", { type: "number", value: 0.8, step: 0.05 });
  const out = h("pre", {}, "");
  const exp = h("button", { class: "btn primary" }, "Export training set from graded agent work");
  exp.onclick = () => safe(async () => { out.textContent = JSON.stringify(await api("/api/builder/export", { min_quality: +minq.value }), null, 1); });
  put(root, learn("three ways ATLAS changes models", "1) <b>ATLAS's own networks</b> (Architect / Ground-Up): trained right here in numpy, versioned, fine-tunable on new CSV rows from Built Systems, with rollback.",
    "2) <b>Open models on your Mac</b>: export a JSONL dataset of the workforce's best graded answers and fine-tune with MLX LoRA. Free, local, needs Apple Silicon.",
    "3) <b>Hosted models</b>: submit the same JSONL to OpenAI fine-tuning (costs money, needs a key). ATLAS never submits without you clicking."),
    h("div", { class: "grid g2" },
      h("div", { class: "card" }, h("h3", {}, "Workforce experience → training data"), h("label", {}, "Minimum quality grade", minq), h("div", { style: { marginTop: "10px" } }, exp), out),
      h("div", { class: "card" }, h("h3", {}, "Fine-tune ATLAS models"), h("p", { class: "dim" }, "Open a tabular system in Built Systems and use “Fine-tune on new CSV”. The previous version is kept for rollback."),
        h("h3", { style: { marginTop: "14px" } }, "Status of LLM fine-tuning"), h("p", { class: "amber" }, "OpenAI submission is implemented but untested in the build environment (no key). MLX command is generated, run it in Terminal on your Mac."))));
}
