import { put, api, bus, fmt, h, learn, safe, tag } from "../core.js";

export async function render(root) {
  const nodes = h("div", { class: "cards" }); const jobs = h("div");
  const name = h("input", { placeholder: "e.g. Kaggle notebook, Colab T4" }), cph = h("input", { type: "number", value: 0, step: 0.01 });
  async function load() {
    const c = await api("/api/compute");
    nodes.innerHTML = "";
    c.nodes.forEach((n) => nodes.append(h("div", { class: "card" + (n.status === "online" ? " glow" : "") }, h("div", { class: "row between" }, h("b", {}, n.name), tag(n.status, n.status === "online" ? "ok" : "x")),
      h("div", { class: "dim", style: { fontSize: "12px", marginTop: "6px" } }, n.kind, " · ", n.cost_per_hour ? fmt.usd(n.cost_per_hour) + "/h" : "free"),
      h("table", { style: { marginTop: "8px" } }, h("tbody", {}, Object.entries(n.specs || {}).map(([k, v]) => h("tr", {}, h("td", { class: "faint" }, k), h("td", { class: "mono" }, String(v)))))))));
    jobs.innerHTML = "";
    jobs.append(h("table", {}, h("thead", {}, h("tr", {}, ["#", "Job", "Kind", "Node", "Status", "Progress", ""].map((x) => h("th", {}, x)))), h("tbody", {}, c.jobs.map((j) => h("tr", {},
      h("td", {}, j.id), h("td", {}, j.title), h("td", { class: "mono" }, j.kind), h("td", {}, j.node_id || "-"), h("td", {}, tag(j.status)),
      h("td", {}, h("div", { class: "bar", style: { width: "100px" } }, h("i", { style: { width: (j.progress || 0) * 100 + "%" } }))),
      h("td", {}, j.status === "running" ? h("button", { class: "btn sm", onclick: () => safe(() => api(`/api/jobs/${j.id}/cancel`, {}), "Cancel requested") }, "Cancel") : (j.finished ? fmt.num(j.finished - j.created, 1) + "s" : "")))))));
  }
  let pend; const off = bus.on((ev) => { if (ev.dept === "compute") { clearTimeout(pend); pend = setTimeout(load, 300); } });
  put(root, h("h1", {}, "Compute Center"), h("p", { class: "sub" }, "Machines available to ATLAS and the work running on them. Free local hardware is always used first."),
    learn("adding your other computers", "Copy the ATLAS folder to your Windows PC or another Mac, install Python + numpy, then run:<br><code>python worker.py --server http://&lt;this-mac-ip&gt;:8600 --token &lt;token&gt;</code><br>Start ATLAS with <code>python3 run.py --lan</code> to get the token. The worker claims neural-network training jobs (tick “Prefer a remote worker” in Ground-Up AI).",
      "Free GPU options: Google Colab and Kaggle notebooks give free GPU time. They can run worker.py if they can reach your computer (needs a tunnel such as Tailscale). Registering a cloud node here only records it; it is not connected until a worker heartbeats."),
    h("div", { class: "card", style: { marginBottom: "14px" } }, h("h3", {}, "Nodes"), nodes,
      h("div", { class: "row", style: { marginTop: "12px" } }, name, h("label", {}, "Cost per hour (USD)", cph), h("button", { class: "btn", onclick: () => safe(async () => { await api("/api/compute/nodes", { name: name.value, cost_per_hour: +cph.value }); load(); }) }, "Register resource"))),
    h("div", { class: "card" }, h("h3", {}, "Jobs"), jobs));
  load();
  const iv = setInterval(load, 5000);
  return () => { off(); clearInterval(iv); };
}
