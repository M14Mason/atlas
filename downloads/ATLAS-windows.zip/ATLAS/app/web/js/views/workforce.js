import { put, api, bus, drawer, fmt, h, learn, micButton, safe, tag, toast, waitJob } from "../core.js";

const SPEC_COLOR = { general: "#5b8cff", math: "#ffbe3d", code: "#3ddc97", research: "#3ee0ff", verification: "#ff6bd5",
  analysis: "#a27bff", writing: "#7fd4ff", finance: "#b8f36b" };

export async function render(root) {
  let agents = await api("/api/agents");
  let currentTask = null;
  const world = h("canvas", { style: { height: "380px", cursor: "pointer" } });
  const diagram = h("div", { style: { minHeight: "260px", overflow: "auto" } });
  const convo = h("div", { class: "feed", style: { maxHeight: "380px" } });
  const table = h("div");
  const text = h("textarea", { placeholder: "e.g. Research why the 2008 crash happened, then calculate 2475 * 0.37, then write a 3 sentence summary" });
  const target = h("select", {});
  const diff = h("select", {}, ["easy", "medium", "hard"].map((d) => h("option", { selected: d === "medium" }, d)));
  const imp = h("input", { type: "checkbox" });
  const rev = h("input", { type: "checkbox", checked: true });
  const run = h("button", { class: "btn primary" }, "Assign task");
  const fillTargets = () => { target.innerHTML = ""; agents.filter((a) => a.config.can_delegate || a.role === "director").forEach((a) => target.append(h("option", { value: a.id }, a.name))); agents.filter((a) => !a.config.can_delegate && a.role !== "director").forEach((a) => target.append(h("option", { value: a.id }, a.name + " (direct)"))); };
  fillTargets();
  run.onclick = () => safe(async () => {
    if (!text.value.trim()) throw new Error("describe the task");
    run.disabled = true;
    const { job } = await api("/api/tasks", { text: text.value, agent_id: +target.value, important: imp.checked, difficulty: diff.value, review: rev.checked });
    toast("Task queued as job #" + job);
    try { const r = await waitJob(job); currentTask = r.task_id; loadTask(); } finally { run.disabled = false; }
  });

  // ---------- (a) organisational world, animated from real events
  const nodes = new Map(); const packets = []; const pulses = []; let refreshT;
  function layout() {
    const W = world.clientWidth || 900, H = 380;
    const byParent = {}; agents.forEach((a) => (byParent[a.parent_id || 0] ||= []).push(a));
    const roots = byParent[0] || [];
    const place = (list, y, x0, x1, depth) => {
      const step = (x1 - x0) / Math.max(1, list.length);
      list.forEach((a, i) => {
        const x = x0 + step * (i + 0.5);
        const n = nodes.get(a.id) || { x, y, bx: x, by: y, born: performance.now() };
        Object.assign(n, { a, tx: x, ty: y, depth, span: step });
        nodes.set(a.id, n);
        const kids = byParent[a.id] || [];
        if (kids.length) place(kids, y + (depth === 0 ? 95 : 105), x0 + step * i, x0 + step * (i + 1), depth + 1);
      });
    };
    place(roots, 50, 20, W - 20, 0);
    for (const id of [...nodes.keys()]) if (!agents.find((a) => a.id === id)) nodes.delete(id);
  }
  layout();
  const byName = (n) => [...nodes.values()].find((x) => x.a.name === n);
  const offBus = bus.on((ev) => {
    if (ev.dept !== "workforce") return;
    const d = ev.data;
    if (ev.kind === "message" || ev.kind === "delegated") {
      const a = byName(ev.actor), b = byName(ev.kind === "delegated" ? d.to : d.recipient);
      if (a && b) packets.push({ a, b, t: 0, color: ev.kind === "delegated" ? "#ffbe3d" : "#3ee0ff" });
    }
    if (ev.kind === "agent_working") { const n = nodes.get(d.agent_id); if (n) { n.working = performance.now(); n.model = d.model; } }
    if (ev.kind === "task_done") { const n = byName(ev.actor); if (n) { n.working = 0; pulses.push({ n, t: 0, ok: d.ok !== false }); } }
    if (ev.kind === "tool_use") { const n = byName(ev.actor); if (n) pulses.push({ n, t: 0, tool: d.tool }); }
    if (["agent_created", "agent_updated", "evaluation", "evolution", "task_done"].includes(ev.kind)) { clearTimeout(refreshT); refreshT = setTimeout(refreshAgents, 500); }
    if (ev.kind === "message" && currentTask && d.thread?.startsWith("task-")) addMsg({ sender: ev.actor, recipient: d.recipient, content: d.preview, live: true });
    if ((ev.kind === "task_started" && !d.parent_task) ) { currentTask = d.task_id; convo.innerHTML = ""; }
    if (["task_started", "task_done", "delegated"].includes(ev.kind) && currentTask) loadTaskSoon();
  });
  let raf;
  function draw(now) {
    const dpr = devicePixelRatio || 1, W = world.clientWidth, H = 380;
    if (world.width !== W * dpr) { world.width = W * dpr; world.height = H * dpr; layout(); }
    const x = world.getContext("2d"); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, W, H);
    // grid floor
    x.strokeStyle = "rgba(62,224,255,.05)"; for (let i = 0; i < W; i += 32) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i, H); x.stroke(); } for (let j = 0; j < H; j += 32) { x.beginPath(); x.moveTo(0, j); x.lineTo(W, j); x.stroke(); }
    for (const n of nodes.values()) { n.x += (n.tx - n.x) * 0.08; n.y += (n.ty - n.y) * 0.08; }
    // reporting lines
    for (const n of nodes.values()) { const p = nodes.get(n.a.parent_id); if (!p) continue; x.strokeStyle = "rgba(91,140,255,.22)"; x.lineWidth = 1; x.beginPath(); x.moveTo(p.x, p.y); x.bezierCurveTo(p.x, (p.y + n.y) / 2, n.x, (p.y + n.y) / 2, n.x, n.y); x.stroke(); }
    // packets (real messages/delegations)
    for (let i = packets.length - 1; i >= 0; i--) {
      const p = packets[i]; p.t += 0.025; if (p.t >= 1) { packets.splice(i, 1); continue; }
      const px = p.a.x + (p.b.x - p.a.x) * p.t, py = p.a.y + (p.b.y - p.a.y) * p.t - Math.sin(p.t * Math.PI) * 30;
      x.fillStyle = p.color; x.shadowColor = p.color; x.shadowBlur = 12; x.beginPath(); x.arc(px, py, 4, 0, 7); x.fill(); x.shadowBlur = 0;
    }
    for (const n of nodes.values()) {
      const a = n.a, col = SPEC_COLOR[a.specialty] || "#5b8cff";
      const r = a.role === "director" ? 20 : a.role === "manager" ? 16 : 11;
      const s = Math.max(0.05, Math.min(1, (now - n.born) / 600));
      const working = n.working && now - n.working < 120000;
      if (working) { const k = (now / 300) % (Math.PI * 2); x.strokeStyle = col; x.lineWidth = 2; x.beginPath(); x.arc(n.x, n.y, r + 7 + Math.sin(k) * 2, 0, 7); x.stroke(); x.fillStyle = "#fff"; x.beginPath(); x.arc(n.x + Math.cos(k * 2) * (r + 10), n.y + Math.sin(k * 2) * (r + 10), 2.5, 0, 7); x.fill(); }
      const g = x.createRadialGradient(n.x - r / 3, n.y - r / 3, 1, n.x, n.y, r * s);
      g.addColorStop(0, "#fff"); g.addColorStop(0.25, col); g.addColorStop(1, "rgba(0,0,0,.2)");
      x.globalAlpha = a.status === "probation" ? 0.6 : a.status === "paused" ? 0.3 : 1;
      x.fillStyle = g; x.shadowColor = col; x.shadowBlur = working ? 24 : 10; x.beginPath(); x.arc(n.x, n.y, r * s, 0, 7); x.fill(); x.shadowBlur = 0;
      if (a.status === "probation") { x.setLineDash([3, 3]); x.strokeStyle = "#ffbe3d"; x.lineWidth = 1.2; x.beginPath(); x.arc(n.x, n.y, r + 3, 0, 7); x.stroke(); x.setLineDash([]); }
      x.globalAlpha = 1; x.fillStyle = "#cfd8ea"; x.font = "11px Inter,sans-serif"; x.textAlign = "center";
      const maxc = Math.max(5, Math.floor((n.span || 120) / 6.5));
      x.fillText(a.name.length > maxc ? a.name.slice(0, maxc - 1) + "…" : a.name, n.x, n.y + r + 14);
      x.fillStyle = "#5b6782"; x.font = "10px ui-monospace,monospace"; if (W > 600 || working) x.fillText((working ? n.model || "" : a.model).slice(0, maxc), n.x, n.y + r + 26);
    }
    for (let i = pulses.length - 1; i >= 0; i--) { const p = pulses[i]; p.t += 0.03; if (p.t > 1) { pulses.splice(i, 1); continue; } x.strokeStyle = p.tool ? "#a27bff" : p.ok ? "#3ddc97" : "#ff5d73"; x.globalAlpha = 1 - p.t; x.lineWidth = 2; x.beginPath(); x.arc(p.n.x, p.n.y, 14 + p.t * 30, 0, 7); x.stroke(); x.globalAlpha = 1; }
    x.textAlign = "left";
    raf = requestAnimationFrame(draw);
  }
  raf = requestAnimationFrame(draw);
  world.onclick = (e) => {
    const r = world.getBoundingClientRect(); const mx = e.clientX - r.left, my = e.clientY - r.top;
    for (const n of nodes.values()) if (Math.hypot(n.x - mx, n.y - my) < 22) return inspect(n.a.id);
  };
  async function refreshAgents() { agents = await api("/api/agents"); layout(); fillTable(); fillTargets(); }

  // ---------- (b) delegation diagram
  let pend = null;
  function loadTaskSoon() { clearTimeout(pend); pend = setTimeout(loadTask, 400); }
  async function loadTask() {
    if (!currentTask) return;
    const t = await api("/api/tasks/" + currentTask);
    diagram.innerHTML = "";
    const rows = [];
    const walk = (n, depth) => { rows.push([n, depth]); (n.children || []).forEach((c) => walk(c, depth + 1)); };
    walk(t.tree, 0);
    const W = 700, rowH = 46, H = rows.length * rowH + 20;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("width", "100%");
    const pos = new Map();
    rows.forEach(([n, d], i) => pos.set(n.id, [20 + d * 60, 20 + i * rowH]));
    let s = "";
    rows.forEach(([n]) => { if (n.parent_id && pos.get(n.parent_id)) { const [x1, y1] = pos.get(n.parent_id), [x2, y2] = pos.get(n.id); s += `<path d="M${x1 + 8} ${y1 + 16} V${y2 + 16} H${x2}" fill="none" stroke="#2a3854" stroke-width="1.5"/>`; } });
    rows.forEach(([n]) => {
      const [x0, y0] = pos.get(n.id);
      const col = n.status === "done" ? "#3ddc97" : n.status === "failed" ? "#ff5d73" : "#ffbe3d";
      const title = (n.title || "").replace(/[<>&]/g, "").slice(0, 60);
      s += `<g><rect x="${x0}" y="${y0}" rx="8" width="${W - x0 - 20}" height="34" fill="#101726" stroke="${col}" stroke-opacity=".6"/>
        <circle cx="${x0 + 14}" cy="${y0 + 17}" r="4" fill="${col}"/>
        <text x="${x0 + 26}" y="${y0 + 14}" fill="#e6ecf7" font-size="12">${title}</text>
        <text x="${x0 + 26}" y="${y0 + 28}" fill="#8a97b0" font-size="10" font-family="monospace">#${n.id} ${(n.agent || "").replace(/[<>&]/g, "")} · ${n.status}${n.quality != null ? " · q " + (+n.quality).toFixed(2) : ""} · ${fmt.usd(n.cost)}</text></g>`;
    });
    svg.innerHTML = s;
    diagram.append(svg);
    convo.innerHTML = "";
    t.messages.forEach(addMsg);
  }
  function addMsg(m) {
    convo.append(h("div", { class: "msg" + (m.sender === "You" ? " user" : "") }, h("div", { class: "who" }, m.sender, " ", h("span", { class: "to" }, "→ " + m.recipient)), m.content));
    convo.scrollTop = convo.scrollHeight;
  }

  // ---------- agents table + inspector
  function fillTable() {
    table.innerHTML = "";
    table.append(h("table", {}, h("thead", {}, h("tr", {}, ["Agent", "Specialty", "Model", "Status", "Tasks", "Quality", "v"].map((c) => h("th", {}, c)))),
      h("tbody", {}, agents.map((a) => h("tr", { class: "click", onclick: () => inspect(a.id) },
        h("td", {}, h("span", { style: { color: SPEC_COLOR[a.specialty] } }, "● "), a.name), h("td", {}, a.specialty), h("td", { class: "mono" }, a.model),
        h("td", {}, tag(a.status)), h("td", {}, a.stats.tasks), h("td", {}, a.quality == null ? "-" : a.quality.toFixed(2)), h("td", { class: "faint" }, a.version))))));
  }
  fillTable();

  async function inspect(id) {
    const a = await api("/api/agents/" + id);
    const sys = h("textarea", {}, a.config.system);
    const model = h("input", { value: a.model });
    const tools = ["knowledge", "calculator", "remember"].map((t) => h("label", { class: "inline" }, h("input", { type: "checkbox", value: t, checked: a.config.tools.includes(t) }), t));
    const save = h("button", { class: "btn primary" }, "Save as new version");
    save.onclick = () => safe(async () => { await api(`/api/agents/${id}/update`, { system: sys.value, model: model.value, tools: tools.map((l) => l.querySelector("input")).filter((i) => i.checked).map((i) => i.value) }); inspect(id); refreshAgents(); }, "Saved");
    const pause = h("button", { class: "btn" }, a.status === "paused" ? "Resume" : "Pause");
    pause.onclick = () => safe(async () => { await api(`/api/agents/${id}/update`, { status: a.status === "paused" ? "trusted" : "paused", note: a.status === "paused" ? "resumed" : "paused by you" }); inspect(id); refreshAgents(); });
    const exam = h("button", { class: "btn" }, "Run evaluation");
    exam.onclick = () => safe(async () => { exam.disabled = true; const { job } = await api(`/api/agents/${id}/evaluate`, {}); const r = await waitJob(job); toast(`Exam ${r.score == null ? "n/a" : r.score.toFixed(2)} → ${r.status}`); inspect(id); refreshAgents(); });
    const retire = h("button", { class: "btn danger" }, "Retire");
    retire.onclick = () => safe(async () => {
      const c = await api(`/api/agents/${id}/retire`, {});
      if (!confirm(c.message)) return;
      if (!confirm("Second confirmation: retire this agent?")) return;
      await api(`/api/agents/${id}/retire`, { confirm_token: c.confirm_token }); refreshAgents();
    }, "Retired");
    drawer(h("div", {},
      h("h2", {}, a.name), h("div", { class: "row" }, tag(a.status), tag(a.role, "x"), tag(a.specialty, "x"), h("span", { class: "faint" }, "v" + a.version)),
      h("p", { class: "dim" }, `${a.stats.tasks} tasks · ${a.stats.ok} ok · graded ${a.stats.graded} · spend ${fmt.usd(a.spend.c)} over ${a.spend.n} model calls`),
      h("div", { class: "row" }, pause, exam, retire),
      h("h3", { style: { marginTop: "16px" } }, "Instructions (intervene here)"), sys,
      h("label", {}, "Model (\"auto\" lets the economy route by cost and proven skill)", model), h("div", { class: "row" }, tools), h("div", { style: { marginTop: "8px" } }, save),
      h("h3", { style: { marginTop: "16px" } }, "Team"), a.team.length ? a.team.map((t) => h("div", {}, h("a", { href: "javascript:void 0", onclick: () => inspect(t.id) }, t.name), " ", tag(t.status))) : h("div", { class: "faint" }, "no subordinates"),
      h("h3", { style: { marginTop: "16px" } }, "Performance by category"),
      h("table", {}, h("tbody", {}, Object.entries(a.stats.by_category).map(([c, v]) => h("tr", {}, h("td", {}, c), h("td", {}, v.n + " tasks"), h("td", {}, v.graded ? (v.q / v.graded).toFixed(2) : "ungraded"))))),
      h("h3", { style: { marginTop: "16px" } }, "Version history"),
      h("table", {}, h("tbody", {}, a.versions.map((v) => h("tr", {}, h("td", {}, "v" + v.version), h("td", { class: "dim" }, v.note), h("td", { class: "faint" }, fmt.ago(v.ts)),
        h("td", {}, v.version !== a.version ? h("button", { class: "btn sm", onclick: () => safe(async () => { await api(`/api/agents/${id}/rollback`, { version: v.version }); inspect(id); refreshAgents(); }, "Rolled back") }, "Roll back") : "current"))))),
      h("h3", { style: { marginTop: "16px" } }, "Recent work"),
      h("table", {}, h("tbody", {}, a.tasks.map((t) => h("tr", { class: "click", onclick: () => { currentTask = t.id; loadTask(); } }, h("td", {}, "#" + t.id), h("td", {}, t.title), h("td", {}, tag(t.status)), h("td", {}, t.quality == null ? "-" : t.quality.toFixed(2))))))));
  }

  // new agent form
  const nName = h("input", { placeholder: "Name" }), nSpec = h("select", {}, Object.keys(SPEC_COLOR).map((s) => h("option", {}, s)));
  const nParent = h("select", {}, h("option", { value: "" }, "no manager"), agents.map((a) => h("option", { value: a.id }, a.name)));
  const nCreate = h("button", { class: "btn" }, "Create agent");
  nCreate.onclick = () => safe(async () => { if (!nName.value) throw new Error("name it"); await api("/api/agents", { name: nName.value, specialty: nSpec.value, parent_id: nParent.value ? +nParent.value : null }); refreshAgents(); }, "Agent created on probation");

  put(root, h("h1", {}, "AI Workforce"),
    h("p", { class: "sub" }, "A real hierarchy. Managers split work, create specialists when none exist, grade results and route by cost. Three synchronized views below are all driven by the same live events."),
    learn("how delegation and trust work", "The Director hands a task to the best-performing team lead. The lead breaks it into subtasks, classifies each (math, code, research...), and gives it to a specialist. If none exists it creates one <b>on probation</b> (dashed amber ring).",
      "Specialists must pass an Arena exam before they are <b>trusted</b>. Tasks marked important never go to probation agents. When a trusted specialist keeps doing well on repetitive work, ATLAS spawns a cheaper copy to test (evolution). Every config change is versioned and can be rolled back."),
    h("div", { class: "card", style: { marginBottom: "14px" } }, h("div", { class: "row", style: { alignItems: "flex-start" } }, text, micButton(text)),
      h("div", { class: "row", style: { marginTop: "10px" } }, h("span", { class: "dim" }, "Assign to"), target, h("span", { class: "dim" }, "Difficulty"), diff,
        h("label", { class: "inline" }, imp, "Important (trusted agents only)"), h("label", { class: "inline", title: "A verification agent checks the answer before it comes back" }, rev, "Peer review"), run)),
    h("div", { class: "grid g2" },
      h("div", { class: "card spanall" }, h("div", { class: "row between" }, h("h3", {}, "Organization (live)"),
        h("div", { class: "legend" }, Object.entries(SPEC_COLOR).map(([k, c]) => h("span", {}, h("i", { style: { background: c } }), k)), h("span", {}, h("i", { style: { background: "#ffbe3d" } }), "delegation"), h("span", {}, h("i", { style: { background: "#3ee0ff" } }), "message"))),
        h("div", { class: "canvas-wrap" }, world), h("div", { class: "faint", style: { fontSize: "12px", marginTop: "6px" } }, "Click an agent to inspect, edit, evaluate, pause or roll back.")),
      h("div", { class: "card" }, h("h3", {}, "Delegation diagram"), diagram.childElementCount ? diagram : (diagram.append(h("div", { class: "empty" }, "Assign a task to see its delegation tree.")), diagram)),
      h("div", { class: "card" }, h("h3", {}, "Conversation"), convo)),
    h("div", { class: "grid g3", style: { marginTop: "14px" } },
      h("div", { class: "card span2" }, h("h3", {}, "Agents"), table),
      h("div", { class: "card" }, h("h3", {}, "Agent Builder (quick)"), h("div", { class: "col" }, nName, nSpec, nParent, nCreate), h("p", { class: "faint", style: { fontSize: "12px" } }, "Full builder with tools and prompts is in Build → Agent Builder."))));
  const recent = (await api("/api/tasks")).find((t) => !t.parent_id);
  if (recent) { currentTask = recent.id; loadTask(); }
  return () => { cancelAnimationFrame(raf); offBus(); };
}
