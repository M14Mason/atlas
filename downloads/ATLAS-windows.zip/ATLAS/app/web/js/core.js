// Shared UI toolkit: DOM helpers, API client, live event bus, charts.
// Every live visual in ATLAS subscribes to `bus`, which carries the
// server's real event stream. No visual invents its own activity.

export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];

export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat(Infinity)) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
}

const TOKEN = new URLSearchParams(location.search).get("token") || localStorage.getItem("atlas_token") || "";
if (TOKEN) try { localStorage.setItem("atlas_token", TOKEN); } catch {}

export async function api(path, body) {
  const opt = { headers: { "content-type": "application/json", "x-atlas-token": TOKEN } };
  if (body !== undefined) { opt.method = "POST"; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({ error: "bad response" }));
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}

export function toast(msg, err = false) {
  const t = h("div", { class: "toast" + (err ? " err" : "") }, msg);
  document.body.append(t);
  setTimeout(() => t.remove(), err ? 6000 : 3000);
}

export async function safe(fn, okMsg) {
  try { const r = await fn(); if (okMsg) toast(okMsg); return r; }
  catch (e) { toast(e.message, true); throw e; }
}

// ---------- live bus (SSE)
export const bus = {
  subs: new Set(),
  on(fn) { this.subs.add(fn); return () => this.subs.delete(fn); },
  emit(ev) { for (const f of this.subs) try { f(ev); } catch (e) { console.error(e); } },
};
export function connectStream(onState) {
  const es = new EventSource("/api/stream" + (TOKEN ? "?token=" + TOKEN : ""));
  es.onopen = () => onState(true);
  es.onerror = () => onState(false);
  es.onmessage = (m) => bus.emit(JSON.parse(m.data));
}

// Wait for a background job, reporting progress.
export async function waitJob(id, onProgress) {
  for (;;) {
    const j = await api("/api/jobs/" + id);
    onProgress && onProgress(j);
    if (["done", "error", "cancelled"].includes(j.status)) {
      if (j.status === "error") throw new Error(j.result?.error || "job failed");
      return j.result;
    }
    await new Promise((r) => setTimeout(r, 700));
  }
}

// ---------- formatting
export const fmt = {
  usd: (v) => v == null ? "-" : v < 0.01 && v > 0 ? "$" + v.toFixed(5) : "$" + v.toFixed(v < 1 ? 4 : 2),
  pct: (v, d = 1) => v == null ? "-" : (v * 100).toFixed(d) + "%",
  num: (v, d = 3) => v == null ? "-" : (+v).toFixed(d),
  time: (ts) => new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
  ago: (ts) => { const s = Date.now() / 1000 - ts; return s < 60 ? Math.round(s) + "s ago" : s < 3600 ? Math.round(s / 60) + "m ago" : Math.round(s / 3600) + "h ago"; },
};
export const DEPT_COLOR = { workforce: "#3ee0ff", council: "#a27bff", arena: "#ffbe3d", architect: "#ff6bd5", research: "#5b8cff",
  market: "#3ddc97", knowledge: "#7fd4ff", economy: "#ffd27f", compute: "#9aa7c7", control: "#ff5d73", builder: "#ff9f6b", system: "#5b6782", workspace: "#b8f36b", automations: "#7ee0c3", web: "#6fb7ff", chat: "#c59bff" };

export function describe(ev) {
  const d = ev.data || {};
  switch (ev.kind) {
    case "agent_created": return `${ev.actor} joined (${d.specialty}, ${d.status})`;
    case "delegated": return `${ev.actor} → ${d.to}${d.category ? " [" + d.category + "]" : ""}`;
    case "agent_working": return `${ev.actor} working on ${d.model} (${d.why})`;
    case "task_done": return `${ev.actor} finished task #${d.task_id}${d.quality != null ? " · quality " + (+d.quality).toFixed(2) : ""}`;
    case "message": return `${ev.actor} → ${d.recipient}: ${d.preview?.slice(0, 80)}`;
    case "model_call": return `${ev.actor} ${d.tokens_in}+${d.tokens_out} tok ${fmt.usd(d.cost)} ${d.latency}s (${d.purpose})`;
    case "stage": return `[${d.stage}] ${d.msg?.slice(0, 120)}`;
    case "generation": return `gen ${d.gen} ${d.env}: best ${fmt.pct(d.best_return)}, out-of-sample ${fmt.pct(d.oos_return)}`;
    case "epoch": return `epoch ${d.epoch} loss ${d.loss} val ${d.val_metric}`;
    case "statement": return `${ev.actor} (${d.phase}) ${d.preview?.slice(0, 80)}`;
    case "evaluation": return `${ev.actor} exam ${fmt.num(d.score, 2)} → ${d.status}`;
    case "item_scored": return `${ev.actor} ${d.category} #${d.i}: ${d.score}`;
    default: return `${ev.kind.replace(/_/g, " ")} ${ev.actor !== "system" ? "· " + ev.actor : ""}`;
  }
}

// ---------- charts (canvas, hi-dpi)
export function canvas(height = 220) {
  const c = h("canvas", { style: { height: height + "px" } });
  return c;
}
function prep(c) {
  const dpr = window.devicePixelRatio || 1;
  const w = c.clientWidth || 600, hh = c.clientHeight || 200;
  if (c.width !== w * dpr || c.height !== hh * dpr) { c.width = w * dpr; c.height = hh * dpr; }
  const x = c.getContext("2d"); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
  return [x, w, hh];
}
// series: [{name, data:[y...] or [[x,y]...], color, dash}]
export function lineChart(c, series, opt = {}) {
  const [x, W, H] = prep(c);
  const pad = { l: 46, r: 10, t: 10, b: 22 };
  const pts = series.map((s) => s.data.map((d, i) => Array.isArray(d) ? d : [i, d]).filter((p) => p[1] != null && isFinite(p[1])));
  const all = pts.flat();
  if (!all.length) { x.fillStyle = "#5b6782"; x.fillText("no data yet", W / 2 - 25, H / 2); return; }
  let [x0, x1] = [Math.min(...all.map((p) => p[0])), Math.max(...all.map((p) => p[0]))];
  let [y0, y1] = opt.y || [Math.min(...all.map((p) => p[1])), Math.max(...all.map((p) => p[1]))];
  if (y0 === y1) { y0 -= 1; y1 += 1; } if (x0 === x1) x1 = x0 + 1;
  const sx = (v) => pad.l + (v - x0) / (x1 - x0) * (W - pad.l - pad.r);
  const sy = (v) => H - pad.b - (v - y0) / (y1 - y0) * (H - pad.t - pad.b);
  x.strokeStyle = "#1f2a40"; x.fillStyle = "#5b6782"; x.font = "10px ui-monospace,monospace"; x.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const v = y0 + (y1 - y0) * i / 4, yy = sy(v);
    x.beginPath(); x.moveTo(pad.l, yy); x.lineTo(W - pad.r, yy); x.stroke();
    x.fillText(opt.yfmt ? opt.yfmt(v) : (+v.toPrecision(3)).toString(), 2, yy + 3);
  }
  if (opt.xlabels) { x.fillText(opt.xlabels[0] ?? "", pad.l, H - 6); const l = opt.xlabels[1] ?? ""; x.fillText(l, W - pad.r - x.measureText(l).width, H - 6); }
  if (opt.zero && y0 < 0 && y1 > 0) { x.strokeStyle = "#2a3854"; x.setLineDash([3, 3]); x.beginPath(); x.moveTo(pad.l, sy(0)); x.lineTo(W - pad.r, sy(0)); x.stroke(); x.setLineDash([]); }
  series.forEach((s, k) => {
    const p = pts[k]; if (!p.length) return;
    x.strokeStyle = s.color || "#3ee0ff"; x.lineWidth = s.width || 1.8; x.setLineDash(s.dash || []);
    x.beginPath(); p.forEach(([a, b], i) => i ? x.lineTo(sx(a), sy(b)) : x.moveTo(sx(a), sy(b))); x.stroke(); x.setLineDash([]);
    if (s.fill) { x.lineTo(sx(p[p.length - 1][0]), sy(y0)); x.lineTo(sx(p[0][0]), sy(y0)); x.closePath(); x.fillStyle = s.fill; x.fill(); }
    if (s.dots) { x.fillStyle = s.color; p.forEach(([a, b]) => { x.beginPath(); x.arc(sx(a), sy(b), 2.5, 0, 7); x.fill(); }); }
  });
}
export function barChart(c, values, opt = {}) {
  const [x, W, H] = prep(c);
  const max = Math.max(...values, 1e-9), n = values.length, bw = (W - 10) / n;
  values.forEach((v, i) => {
    const hh = (v / max) * (H - 24);
    const col = typeof opt.color === "function" ? opt.color(i, v) : opt.color || "#5b8cff";
    x.fillStyle = col; x.fillRect(5 + i * bw + 1, H - 16 - hh, Math.max(1, bw - 2), hh);
  });
  x.fillStyle = "#5b6782"; x.font = "10px ui-monospace,monospace";
  if (opt.labels) { x.fillText(opt.labels[0], 4, H - 3); const l = opt.labels[1]; x.fillText(l, W - x.measureText(l).width - 4, H - 3); }
}
export function legend(items) {
  return h("div", { class: "legend" }, items.map(([c, t]) => h("span", {}, h("i", { style: { background: c } }), t)));
}
export function learn(title, ...paras) {
  return h("details", { class: "learn" }, h("summary", {}, "Learn: " + title), paras.map((p) => h("p", { html: p })));
}
export function tag(t, cls) { return h("span", { class: "tag " + (cls || t) }, t); }
export function kpi(label, value, sub) { return h("div", { class: "card kpi" }, h("div", { class: "l" }, label), h("div", { class: "v" }, value), sub ? h("div", { class: "s" }, sub) : null); }

// ---------- drawer
export function drawer(content) {
  const d = $("#drawer"); const b = $("#drawerBody"); b.innerHTML = ""; b.append(content); d.classList.add("open");
}
export function closeDrawer() { $("#drawer").classList.remove("open"); }

// ---------- voice dictation (Web Speech API, where the browser supports it)
export function micButton(target) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return h("span");
  const b = h("button", { class: "btn mic", title: "Dictate" }, "🎙");
  let rec = null;
  b.onclick = (e) => {
    e.preventDefault();
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.interimResults = true; rec.lang = navigator.language || "en-US";
    const base = target.value ? target.value + " " : "";
    rec.onresult = (ev) => { target.value = base + [...ev.results].map((r) => r[0].transcript).join(""); };
    rec.onend = () => { rec = null; b.classList.remove("rec"); };
    rec.start(); b.classList.add("rec");
  };
  return b;
}

export function fileToB64(file) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result.split(",")[1]); r.onerror = rej; r.readAsDataURL(file); });
}
export function fileToText(file) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsText(file); });
}

// Append children, skipping null/false (used for conditional sections).
export function put(el, ...kids) { el.append(...kids.flat().filter((k) => k != null && k !== false)); return el; }

// ---------- icons (simple stroke icons, drawn for ATLAS)
const ICONS = {
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 12l6-6"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  hex: '<path d="M12 2l8.5 5v10L12 22l-8.5-5V7z"/><circle cx="12" cy="12" r="3"/>',
  org: '<rect x="9" y="2" width="6" height="5" rx="1"/><rect x="2" y="17" width="6" height="5" rx="1"/><rect x="16" y="17" width="6" height="5" rx="1"/><path d="M12 7v5M5 17v-5h14v5"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 01-8 0zM8 6H4a3 3 0 003 4M16 6h4a3 3 0 01-3 4M12 13v4M8 21h8M9 17h6"/>',
  spark: '<path d="M12 2l2.2 6.8L21 11l-6.8 2.2L12 20l-2.2-6.8L3 11l6.8-2.2z"/>',
  flask: '<path d="M9 2h6M10 2v6L4 20h16L14 8V2M7 14h10"/>',
  dna: '<path d="M7 2c0 6 10 6 10 12s-10 6-10 8M17 2c0 6-10 6-10 12M17 22c0-2-1-3-2-4M9 6h6M8 11h8M9 17h6"/>',
  book: '<path d="M4 4h7a3 3 0 013 3v13a2 2 0 00-2-2H4zM20 4h-6M20 4v14h-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M15 9a3 2 0 00-6 0c0 3 6 1 6 4a3 2 0 01-6 0M12 6v12"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  pulse: '<path d="M2 12h4l3-8 4 16 3-8h6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  brain: '<path d="M9 4a3 3 0 00-3 3 3 3 0 00-2 5 3 3 0 002 5 3 3 0 006 1V5a3 3 0 00-3-1zM15 4a3 3 0 013 3 3 3 0 012 5 3 3 0 01-2 5 3 3 0 01-6 1"/>',
  send: '<path d="M3 11l18-8-8 18-2-8z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  check: '<path d="M4 12l5 5L20 6"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>',
  star: '<path d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
};
export function icon(name, size = 16) {
  const s = document.createElement("span");
  s.className = "i";
  s.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ""}</svg>`;
  return s;
}
export function hydrateIcons(root = document) {
  root.querySelectorAll("[data-i]").forEach((el) => { if (!el.firstChild) el.append(icon(el.dataset.i).firstChild); });
}

// ---------- modal
export function modal(content, { wide = false, onClose } = {}) {
  const bg = h("div", { class: "modal-bg" });
  const box = h("div", { class: "modal" + (wide ? " wide" : "") }, content);
  bg.append(box);
  const close = () => { bg.classList.add("out"); setTimeout(() => bg.remove(), 180); onClose && onClose(); document.removeEventListener("keydown", esc); };
  const esc = (e) => e.key === "Escape" && close();
  bg.addEventListener("mousedown", (e) => e.target === bg && close());
  document.addEventListener("keydown", esc);
  document.body.append(bg);
  return close;
}

// ---------- empty state & skeleton
export function emptyState(ic, title, text, action) {
  return h("div", { class: "empty-state" }, icon(ic, 34), h("b", {}, title), h("p", {}, text), action || null);
}
