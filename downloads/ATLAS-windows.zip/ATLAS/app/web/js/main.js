import { $, $$, api, bus, closeDrawer, connectStream, describe, DEPT_COLOR, fmt, h, hydrateIcons, icon, modal, safe, toast, waitJob } from "./core.js";

const VIEWS = { command: "Command Center", chat: "Ask ATLAS", council: "AI Council", workforce: "AI Workforce", arena: "Intelligence Arena",
  build: "Build & Architect", lab: "Research Lab", market: "Market Lab", knowledge: "Knowledge Universe", automations: "Automations",
  compute: "Compute Center", economy: "AI Economy", workspace: "Personal Workspace", health: "System Health", settings: "Settings" };
let cleanup = null;

// ---------- appearance (accent colour persisted per browser)
const ACCENTS = { cyan: ["#3ee0ff", "#5b6dff"], violet: ["#a27bff", "#ff6bd5"], green: ["#3ddc97", "#3ee0ff"], amber: ["#ffbe3d", "#ff6b6b"] };
export function setAccent(name) {
  const a = ACCENTS[name] || ACCENTS.cyan;
  document.documentElement.style.setProperty("--cyan", a[0]);
  document.documentElement.style.setProperty("--accent2", a[1]);
  try { localStorage.setItem("atlas_accent", name); } catch {}
}
window.atlasSetAccent = setAccent;
try { setAccent(localStorage.getItem("atlas_accent") || "cyan"); } catch { setAccent("cyan"); }

// ---------- client error reporting -> System Health logs
const report = (message, detail) => api("/api/system/logs", { level: "error", message, detail }).catch(() => {});
window.addEventListener("error", (e) => report(String(e.message), `${e.filename}:${e.lineno}`));
window.addEventListener("unhandledrejection", (e) => report("unhandled: " + (e.reason?.message || e.reason)));

async function show(name) {
  if (!VIEWS[name]) name = "command";
  $$("#nav button").forEach((b) => b.classList.toggle("active", b.dataset.v === name));
  $("#nav").classList.remove("open");
  document.title = `${VIEWS[name]} · ATLAS`;
  closeDrawer();
  if (cleanup) { try { cleanup(); } catch {} cleanup = null; }
  const main = $("#main");
  main.innerHTML = "";
  main.scrollTop = 0;
  const page = h("div", { class: "page" });
  main.append(page);
  try {
    const mod = await import(`./views/${name}.js`);
    cleanup = (await mod.render(page)) || null;
  } catch (e) {
    console.error(e);
    report(`view ${name} failed: ${e.message}`, e.stack);
    page.append(h("div", { class: "card" }, h("h2", {}, "This screen hit an error"), h("p", { class: "dim" }, "It has been logged in System Health."), h("pre", {}, String(e.stack || e))));
  }
}

$$("#nav button").forEach((b) => (b.onclick = () => { location.hash = b.dataset.v; }));
window.addEventListener("hashchange", () => show(location.hash.slice(1)));
$("#menu").onclick = () => $("#nav").classList.toggle("open");
$("#drawerX").onclick = closeDrawer;
hydrateIcons();

connectStream((on) => {
  $("#liveDot").className = "dot " + (on ? "on" : "err");
  $("#liveTxt").textContent = on ? "live" : "offline";
});

// ---------- ticker
const tick = $("#ticker");
const recent = [];
bus.on((ev) => {
  if (["epoch", "item_scored", "job_progress", "model_call"].includes(ev.kind)) return;
  recent.unshift(ev); recent.length = Math.min(recent.length, 6);
  tick.innerHTML = "";
  recent.forEach((e) => tick.append(h("span", { style: { marginRight: "28px", color: DEPT_COLOR[e.dept] || "#8a97b0" } }, "● ", h("span", { class: "dim" }, describe(e)))));
});

// ---------- header stats + job tray
async function header() {
  try {
    const o = await api("/api/overview");
    $("#hModels").textContent = `${o.models_available.length}`;
    $("#hCost").textContent = fmt.usd(o.cost.today);
  } catch {}
}
async function jobs() {
  try {
    const j = await api("/api/jobs");
    const running = j.filter((x) => x.status === "running" || x.status === "queued");
    $("#hJobs").textContent = running.length;
    $("#jobsBtn").classList.toggle("busy", running.length > 0);
    const tray = $("#jobTray");
    if (tray.classList.contains("open")) {
      tray.innerHTML = "";
      tray.append(h("div", { class: "row between" }, h("b", {}, "Background jobs"), h("a", { href: "#compute" }, "All →")),
        j.slice(0, 10).map((x) => h("div", { class: "tray-row" }, h("div", { class: "row between" }, h("span", {}, x.title), h("span", { class: "tag " + x.status }, x.status)),
          h("div", { class: "bar" }, h("i", { style: { width: (x.progress || 0) * 100 + "%" } })))));
    }
  } catch {}
}
$("#jobsBtn").onclick = () => { $("#jobTray").classList.toggle("open"); jobs(); };
header(); jobs();
setInterval(header, 10000);
let jt; bus.on((ev) => {
  if (ev.dept === "compute") { clearTimeout(jt); jt = setTimeout(jobs, 250); }
  if (ev.kind === "job_done" || ev.kind === "job_error") header();
  if (ev.kind === "job_error") toast("A background job failed. Details in System Health.", true);
  if ((ev.kind === "job_done" || ev.kind === "job_error") && document.hidden && "Notification" in window && Notification.permission === "granted") {
    api("/api/jobs/" + ev.data.job_id).then((j) => { if (j.finished - j.created > 8) new Notification("ATLAS", { body: `${j.title}: ${j.status === "done" ? "finished" : "failed"}`, icon: "/icon-512.png" }); }).catch(() => {});
  }
  if (ev.kind === "model_installed") toast(`Model ${ev.data.model} installed`);
});

// ---------- command palette
const ACTIONS = [
  ...Object.entries(VIEWS).map(([k, v]) => ({ label: v, hint: "Go to", run: () => (location.hash = k), ic: "radar" })),
  { label: "New chat with ATLAS", hint: "Action", run: () => (location.hash = "chat"), ic: "chat" },
  { label: "Build a new AI with the Architect", hint: "Action", run: () => (location.hash = "build"), ic: "spark" },
  { label: "Start a Market Lab evolution", hint: "Action", run: () => (location.hash = "market"), ic: "dna" },
  { label: "Run system diagnostics", hint: "Action", run: () => (location.hash = "health"), ic: "pulse" },
  { label: "Download a free AI model", hint: "Action", run: () => (location.hash = "settings"), ic: "download" },
  { label: "Open setup wizard", hint: "Action", run: () => onboarding(true), ic: "star" },
];
function palette() {
  const inp = h("input", { placeholder: "Type a page, action, agent, system, document or chat…", class: "pal-in" });
  const list = h("div", { class: "pal-list" });
  let items = [], sel = 0;
  const render = () => {
    list.innerHTML = "";
    items.forEach((it, i) => list.append(h("div", { class: "pal-item" + (i === sel ? " sel" : ""), onmousedown: () => go(i) }, icon(it.ic || "search"), h("span", {}, it.label), h("span", { class: "faint" }, it.hint))));
  };
  const go = (i) => { const it = items[i]; if (!it) return; close(); it.run(); };
  let t;
  inp.oninput = () => {
    const q = inp.value.toLowerCase();
    items = ACTIONS.filter((a) => a.label.toLowerCase().includes(q)).slice(0, 8);
    sel = 0; render();
    clearTimeout(t);
    if (q.length > 1) t = setTimeout(async () => {
      const r = await api("/api/search?q=" + encodeURIComponent(q)).catch(() => []);
      items = items.concat(r.map((x) => ({ label: x.label, hint: x.type, ic: { agent: "org", system: "spark", doc: "book", chat: "chat", task: "org" }[x.type], run: () => (location.hash = x.href.slice(1)) })));
      render();
    }, 150);
  };
  inp.onkeydown = (e) => {
    if (e.key === "ArrowDown") { sel = Math.min(items.length - 1, sel + 1); render(); e.preventDefault(); }
    if (e.key === "ArrowUp") { sel = Math.max(0, sel - 1); render(); e.preventDefault(); }
    if (e.key === "Enter") go(sel);
  };
  const close = modal(h("div", {}, inp, list));
  inp.oninput(); setTimeout(() => inp.focus(), 20);
}
$("#paletteBtn").onclick = palette;
document.addEventListener("keydown", (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); palette(); }
});

// ---------- first-run setup wizard
async function onboarding(force = false) {
  const st = await api("/api/onboarding").catch(() => null);
  if (!st || (st.done && !force)) return;
  let step = 0;
  const body = h("div");
  const steps = [
    () => h("div", {}, h("div", { class: "wiz-hero" }, h("div", { class: "mark big" })), h("h1", {}, "Welcome to ATLAS"),
      h("p", { class: "dim" }, "Your AI command center. Everything runs on your computer. Here's what you can do:"),
      h("div", { class: "wiz-grid" }, [["spark", "Build AIs", "Describe an AI. The Architect designs, trains, tests and packages it."],
        ["dna", "Evolve traders", "500 trading bots evolve on real market data. Virtual money only."],
        ["org", "Run an AI team", "Agents split work, create specialists and check each other."],
        ["chat", "Ask anything", "Chat with AI models grounded in your notes and the web."]].map(([i, t, d]) => h("div", { class: "wiz-card" }, icon(i, 22), h("b", {}, t), h("span", { class: "dim" }, d))))),
    async () => {
      const o = await api("/api/ollama").catch(() => ({ running: false, recommended: [] }));
      const box = h("div", {}, h("h2", {}, "Step 1: free AI models"),
        h("p", { class: "dim" }, "ATLAS works offline already. For chat, the Council and smart agents it needs an AI model. The free way is Ollama, which runs models on your own computer."));
      if (!o.running) {
        box.append(h("div", { class: "card", style: { marginTop: "10px" } }, h("ol", { class: "steps-list" },
          h("li", {}, "Download Ollama: ", h("a", { href: "https://ollama.com/download", target: "_blank" }, "ollama.com/download")),
          h("li", {}, "Open the Ollama app once (it lives in your menu bar / system tray)."),
          h("li", {}, "Come back here and press Check again. ATLAS will download models for you.")),
          h("button", { class: "btn", onclick: () => { step = 1; draw(); } }, "Check again")),
          h("p", { class: "faint", style: { marginTop: "10px" } }, "You can skip this and do it later from Settings."));
      } else {
        box.append(h("p", { class: "green" }, "✓ Ollama is running."), h("div", { class: "col" }, o.recommended.slice(0, 3).map((r) => {
          const b = h("button", { class: "btn sm" + (r.installed ? "" : " primary"), disabled: r.installed }, r.installed ? "Installed" : `Download (${r.size_gb} GB)`);
          const bar = h("div", { class: "bar", style: { width: "120px" } }, h("i", { style: { width: r.installed ? "100%" : "0%" } }));
          b.onclick = () => safe(async () => { b.disabled = true; const { job } = await api("/api/ollama/pull", { model: r.name }); await waitJob(job, (j) => (bar.firstChild.style.width = j.progress * 100 + "%")); b.textContent = "Installed"; });
          return h("div", { class: "row between wiz-model" }, h("div", {}, h("b", {}, r.name), h("div", { class: "faint" }, r.why)), h("div", { class: "row" }, bar, b));
        })));
      }
      return box;
    },
    () => h("div", {}, h("h2", {}, "Step 2: safety limits"), h("p", { class: "dim" }, "These protect you while ATLAS works on its own."),
      h("ul", { class: "steps-list" }, h("li", {}, "Paid AI models can never spend more than ", h("b", {}, "$1 a day"), " unless you raise it in Settings."),
        h("li", {}, "Deleting anything asks you to confirm."), h("li", {}, "Market Lab uses ", h("b", {}, "virtual money only"), ". It never touches a broker."),
        h("li", {}, "New agents start on probation and must pass a test before they're trusted."))),
    () => h("div", {}, h("h2", {}, "Step 3: try something"), h("p", { class: "dim" }, "Pick one to start. Each takes under a minute."),
      h("div", { class: "wiz-grid" }, [["spark", "Build a spam detector", "build"], ["dna", "Evolve 500 traders", "market"], ["chat", "Ask ATLAS a question", "chat"], ["flask", "Watch a neural net learn", "build"]].map(([i, t, v]) =>
        h("button", { class: "wiz-card click", onclick: () => { finish(); location.hash = v; } }, icon(i, 22), h("b", {}, t))))),
  ];
  const nav = h("div", { class: "row between", style: { marginTop: "18px" } });
  const finish = () => { api("/api/onboarding", { done: true }); close(); };
  async function draw() {
    body.innerHTML = ""; body.append(await steps[step]());
    nav.innerHTML = "";
    nav.append(h("div", { class: "row" }, steps.map((_, i) => h("span", { class: "wiz-dot" + (i === step ? " on" : "") }))),
      h("div", { class: "row" }, h("button", { class: "btn", onclick: finish }, "Skip"),
        step > 0 ? h("button", { class: "btn", onclick: () => { step--; draw(); } }, "Back") : null,
        step < steps.length - 1 ? h("button", { class: "btn primary", onclick: () => { step++; draw(); } }, "Next") : h("button", { class: "btn primary", onclick: finish }, "Finish")));
  }
  const close = modal(h("div", {}, body, nav), { wide: true });
  draw();
}
window.atlasOnboarding = () => onboarding(true);

$("#quitBtn").onclick = () => safe(async () => {
  if (!confirm("Quit ATLAS? Running jobs and automations will stop until you open it again.")) return;
  const r = await api("/api/system/quit", {});
  if (!r.ok) return toast(r.message);
  document.body.innerHTML = '<div style="display:grid;place-items:center;height:100vh;color:#8a97b0;font:15px Inter,sans-serif">ATLAS has stopped. You can close this window.</div>';
});
api("/api/system/info").then((i) => {
  $("#ver").textContent = "ATLAS v" + i.version;
  api("/api/system/update").then((u) => {
    if (!u.available) return;
    const t = h("div", { class: "toast" }, `ATLAS v${u.latest} is available. `, h("a", { href: u.url, target: "_blank" }, "Download →"));
    document.body.append(t); setTimeout(() => t.remove(), 15000);
  }).catch(() => {});
}).catch(() => {});
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
show(location.hash.slice(1) || "command");
onboarding();
// ask once, after the user's first click, so long jobs can notify when ATLAS is in the background
document.addEventListener("click", () => { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); }, { once: true });
