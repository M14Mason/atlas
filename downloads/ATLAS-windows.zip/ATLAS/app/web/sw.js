// Minimal service worker so ATLAS can be installed as an app on a phone.
// It does not cache API data: ATLAS always shows live state.
self.addEventListener("install", (e) => self.skipWaiting());
self.addEventListener("fetch", () => {});
