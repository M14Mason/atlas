@echo off
REM Runs ATLAS with a visible console so you can see errors.
set ATLAS_APP=1
"%~dp0runtime\python.exe" "%~dp0app\launcher.py"
pause
