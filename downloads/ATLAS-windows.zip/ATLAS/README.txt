ATLAS for Windows

1. Right-click ATLAS-windows.zip > Extract All. Put the extracted ATLAS folder anywhere (for example Documents).
2. Open the folder and double-click ATLAS.exe.
   Windows SmartScreen may say "Windows protected your PC" because the app isn't signed with a paid certificate.
   Click "More info" > "Run anyway". You only do this once.
3. ATLAS opens in its own window (Microsoft Edge app mode, which every Windows 10/11 PC has). Python is included; nothing to install.
4. Tip: right-click ATLAS.exe > Send to > Desktop (create shortcut).

Your data lives in %APPDATA%\ATLAS.
Free AI models: install Ollama from https://ollama.com/download, open it, then use Settings in ATLAS to download models with one click.
Problems? Double-click "ATLAS (debug).bat" to see errors, or open System Health inside ATLAS and press "Copy debug report".
